package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class InvoiceTrueUpSearch extends Pagination{
	private Long ceid;
	private String startPeriod;
	private String endPeriod;
	private Long phGroupid;
	private Long phid;
}
