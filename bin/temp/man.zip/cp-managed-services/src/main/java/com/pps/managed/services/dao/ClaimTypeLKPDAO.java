package com.pps.managed.services.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pps.managed.services.model.ClaimTypeLKP;

public interface ClaimTypeLKPDAO extends JpaRepository<ClaimTypeLKP, Long> {

}
