package com.pps.managed.services.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pps.managed.services.dto.ClaimsManagementSearch;
import com.pps.managed.services.dto.GetRxNumberDetailsSearch;
import com.pps.managed.services.dto.PatientFirstNameSearch;
import com.pps.managed.services.dto.PatientLastNameSearch;
import com.pps.managed.services.dto.PatientMRNSearch;
import com.pps.managed.services.dto.Result;
import com.pps.managed.services.dto.RxNumberSearch;
import com.pps.managed.services.service.ClaimsManagementService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/claimsManagement")
@SecurityRequirement(name = "bearerAuth")
@Slf4j
public class ClaimsManagementController {

	@Autowired
	private ClaimsManagementService claimsManagementService;

	/**
	 * Gets the claim type.
	 *
	 * @return the claim type
	 */
	@GetMapping("/claimType")
	public ResponseEntity<?> getClaimType() {
		return ResponseEntity.ok(claimsManagementService.getClaimType());
	}

	/**
	 * Gets the bin.
	 *
	 * @return the bin
	 */
	@GetMapping("/bin")
	public ResponseEntity<?> getBIN() {
		return ResponseEntity.ok(claimsManagementService.getBIN());
	}

	/**
	 * Gets the fallout reason.
	 *
	 * @return the fallout reason
	 */
	@GetMapping("/falloutReason")
	public ResponseEntity<?> getFalloutReason() {
		return ResponseEntity.ok(claimsManagementService.getFalloutReason());
	}

	/**
	 * Gets the claim status.
	 *
	 * @return the claim status
	 */
	@GetMapping("/claimsStatuslkp")
	public ResponseEntity<?> getClaimStatus() {
		return ResponseEntity.ok(claimsManagementService.getClaimStatus());
	}

	@PostMapping("/search")
	public ResponseEntity<?> getClaimsManagement(
			@RequestHeader(required = false, value = "Authorization") String authorization,
			@RequestBody ClaimsManagementSearch claimsManagementSearch) {
		log.debug("in side claims search");
		return ResponseEntity.ok(claimsManagementService.searchClaimsManagement(claimsManagementSearch));
	}
	
	/**
	 * Gets the rx number.
	 *
	 * @param rxNumber Search
	 * @return the rx number
	 */
	@PostMapping("/RxNumber")
	public ResponseEntity<?> getRxNumber(@RequestBody RxNumberSearch rxNumberSearch) {
		return ResponseEntity.ok(claimsManagementService.getRxNumberByCEID(rxNumberSearch));
	}

	/**
	 * Gets the patient MRN.
	 *
	 * @param PatientMRNSearch patientMRNSearch
	 * @return the patient MRN
	 */
	@PostMapping("/PatientMRN")
	public ResponseEntity<?> getPatientMRN(@RequestBody PatientMRNSearch patientMRNSearch) {
		return ResponseEntity.ok(claimsManagementService.getPatientMRNByCEID(patientMRNSearch));

	}
	
	/**
	 * Gets the patient FirstName.
	 *
	 * @param PatientFirstNameSearch  patientFirstNameSearch 
	 * @return the patient FirstName by CEID
	 */
	@PostMapping("/patientFirstName")
	public ResponseEntity<?> getPatientFirstName(@RequestBody PatientFirstNameSearch patientFirstNameSearch) {
		return ResponseEntity.ok(claimsManagementService.getPatientFirstName(patientFirstNameSearch));

	}
	
	/**
	 * Gets the patient LastName.
	 *
	 * @param PatientLastNameSearch  patientLastNameSearch 
	 * @return the patient LastName by CEID
	 */
	@PostMapping("/patientLastName")
	public ResponseEntity<?> getPatientLastName(@RequestBody PatientLastNameSearch patientLastNameSearch) {
		return ResponseEntity.ok(claimsManagementService.getPatientLastName(patientLastNameSearch));

	}
	
	
	/**
	 * Gets the rx number details search.
	 *
	 * @param authorization the authorization
	 * @param getRxNumberDetailsSearch the get rx number details search
	 * @return the rx number details search
	 */
	@PostMapping("/getRxDetails")
	  public ResponseEntity<?> getRxNumberDetailsSearch(
	      @RequestHeader(required = false, value = "Authorization") String authorization,
	      @RequestBody GetRxNumberDetailsSearch getRxNumberDetailsSearch) {
	    Result result = claimsManagementService.getRxDetails(getRxNumberDetailsSearch);
	    return ResponseEntity.ok(result);
	  }
}
