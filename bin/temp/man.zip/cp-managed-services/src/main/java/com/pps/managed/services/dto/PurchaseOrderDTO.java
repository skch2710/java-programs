package com.pps.managed.services.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrderDTO {

	private Long poID;

	private String ceName;

	private String pharmacy;

	private String wholesaler;

	private String poDate;

	private String poStatus;

	private String totalOrderAmount;

	private String totalBilledAmount;

	private String orderType;

	private Long poStatusID;

	private Long ceID;

	private Long phID;

	private Long phGroupID;

	private Long wholesalerAccountID;

	private Long totalRows;

	private Integer wholesalerID;
	
	private String hrsaID;
}