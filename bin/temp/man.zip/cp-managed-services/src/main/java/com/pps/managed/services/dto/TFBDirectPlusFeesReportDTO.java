package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TFBDirectPlusFeesReportDTO {

	private Long id;
	private Long ceid;
	private Long phid;
	private Long phGroupId;
	private String ceName;
	private String adminHrsaId;
	private String tfbDirectPlusFees;
	private String dueDate;
	private String billingPeriod;

}