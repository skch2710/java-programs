package com.pps.managed.services.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name ="VwPurchaseOrderItem_mvp",schema = "Plus")
public class PurchaseOrdersInnerGrid {

	@Column(name = "[POID]")
	public Long poID;

	@Column(name = "[PO Item Value]")
	public String poItemValue;

	@Column(name = "[NDC]")
	public String ndc;

	@Column(name = "[Drug Name]")
	public String drugName;

	@Column(name = "[Item Status]")
	public String itemStatus;

	@Column(name = "[Drug ID]")
	public Long drugID;

	@Id
	@Column(name = "[POItemID]")
	public Long poItemID;

	@Column(name = "[Ordered Qty]")
	public BigDecimal orderedQty;

	@Column(name = "[Acknowledged Qty]")
	public BigDecimal acknowledgedQty;

	@Column(name = "[Invoiced Qty]")
	public BigDecimal invoicedQty;

	@Column(name = "[Ordered Package Cost]")
	public BigDecimal orderedPackageCost;

	@Column(name = "[Acknowledged Package Cost]")
	public BigDecimal acknowledgedPackageCost;

	@Column(name = "[Invoiced Package Cost]")
	public BigDecimal invoicedPackageCost;
}
