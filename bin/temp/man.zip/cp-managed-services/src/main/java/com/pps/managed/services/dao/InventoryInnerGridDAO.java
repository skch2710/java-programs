package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pps.managed.services.model.InventoryInnerGrid;

public interface InventoryInnerGridDAO extends JpaRepository<InventoryInnerGrid, Long> {

	Page<InventoryInnerGrid> findAll(Specification<InventoryInnerGrid> spec, Pageable pageable);

	List<InventoryInnerGrid> findAll(Specification<InventoryInnerGrid> spec, Sort sort);
	
	@Query(value= "  EXEC [plus].GetInventoryInnerGrid2 @aCEID=:ceId,@RxNumber=:rxNumber"
			+ " ,@DispensedDate=:dispensedDate,@ndc=:ndc,@phid=:phid,@WholeSalerID=:wholeSalerId, @PageNumber=:pageNumber,@PageSize=:pageSize,"
			+ "@SortBy=:sortBy,@SortOrder=:sortOrder,@Export=:export "
			
			+ ", @ActionDate=:actionDate, @Action=:action, @CaptureDate=:captureDate, @RefNo=:refNo, @DispenseQty=:dispenseQty, @ReplenishedQty=:replenishedQty "
			+ ",  @TrueUpQty=:trueUpQty, @ReplenishedPerc=:replenishedPerc, @TotalPrice=:totalPrice, @WholesalerName=:wholesalerName, @Status=:status  ", nativeQuery = true)
	List<InventoryInnerGrid> getPODetails(@Param("ceId") Long ceId, @Param("rxNumber") String rxNumber, @Param("dispensedDate") String dispensedDate,
			@Param("ndc") String ndc,@Param("phid") Long phid, @Param("wholeSalerId") Long wholeSalerId,@Param("pageNumber") int pageNumber,@Param("pageSize") int pageSize,
			@Param("sortBy") String sortBy,@Param("sortOrder") String sortOrder,@Param("export") String export
			
			, @Param("actionDate") String actionDate,@Param("action") String action,@Param("captureDate") String captureDate
			, @Param("refNo") String refNo,@Param("dispenseQty") String dispenseQty,@Param("replenishedQty") String replenishedQty
			, @Param("trueUpQty") String trueUpQty,@Param("replenishedPerc") String replenishedPerc,@Param("totalPrice") String totalPrice
			, @Param("wholesalerName") String wholesalerName,@Param("status") String status
			);
	
}
