package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class InventoryInnerGridSearch extends Pagination {

	private Long ceID;
	private String rxNumber;
	private String dispensedDate;
	private String ndc;
	private Long phID;
	private Long wholesalerID;
}
