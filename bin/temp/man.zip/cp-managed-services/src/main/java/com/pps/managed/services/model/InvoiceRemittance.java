package com.pps.managed.services.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceRemittance {
	
	@Id
	@Column(name = "[id]", nullable = false)
	private Long id;
	
	@Column(name = "[CENAME]", nullable = false)
	private String ceName;
	
	@Column(name = "[PHGroupName]", nullable = false)
	private String phGroupName;
	
	@Column(name = "[PHName]", nullable = false)
	private String phName;
	
	@Column(name = "[PharmacyNPI]", nullable = false)
	private String pharmacyNPI;
	
	@Column(name = "[BillingCycle]", nullable = false)
	private Date billingCycle;
	
	@Column(name = "[340Claims]", nullable = false)
	private Long claims340;
	
	@Column(name = "[TotalInvoiced]", nullable = false)
	private Long totalInvoiced;
	
	@Column(name = "[DispensingFee]", nullable = false)
	private Long dispensingFee;
	
	@Column(name = "[PharmacyConnectionFee]", nullable = false)
	private Long pharmacyConnectionFee;

	@Column(name = "[340BDirectPlusFlatFee]", nullable = false)
	private Long direct340BFlatFee;
	
	@Column(name = "[Direct340BTrxnFee]", nullable = false)
	private Long direct340BTrxnFee;
	
	@Column(name = "[PharmacyMinOrMax]", nullable = false)
	private Long pharmacyMinOrMax;
	
	@Column(name = "[Adjustments]", nullable = false)
	private Long adjustments;
	
	@Column(name = "[Trueup]", nullable = false)
	private Long trueUp;
	
	@Column(name = "[CETotalReceivedAmount]", nullable = false)
	private Long ceTotalReceivedAmount;
	
	@Column(name = "[CEThreshold]", nullable = false)
	private Long ceThreshold;
	
	@Column(name = "[InvoiceNumber]", nullable = false)
	private Long invoiceNumber;
	
	@Column(name = "[totalRows]", nullable = false)
	private Long totalRows;
}
