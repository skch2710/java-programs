package com.pps.managed.services.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.VwRxNumDetailsVisitHistory;

@Repository
public interface VwRxNumDetailsVisitHistoryDAO extends JpaRepository<VwRxNumDetailsVisitHistory, Long>  {
		VwRxNumDetailsVisitHistory findAllByClaimIdAndRxNumber(Long Claimid, String RxNumber);
}
