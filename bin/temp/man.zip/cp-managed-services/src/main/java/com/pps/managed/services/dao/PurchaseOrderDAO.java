package com.pps.managed.services.dao;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.PurchaseOrder;

@Repository
public interface PurchaseOrderDAO extends JpaRepository<PurchaseOrder, Long> {

	/**
	 * Find all.
	 *
	 * @param spec     the spec
	 * @param pageable the pageable
	 * @return the page
	 */
	Page<PurchaseOrder> findAll(Specification<PurchaseOrder> spec, Pageable pageable);

	List<PurchaseOrder> findAll(Specification<PurchaseOrder> spec, Sort sort);

	@Query(value = "EXEC plus.GetPurchaseOrderDetails_MVP @CEID=:ceID, @PHId=:phID, @PHGroupID=:phGroupID, @WholesalerID=:wholeSalerID,@DrugManufacturerID=:drugManufacturerID,"
			+ "@POStatusID=:poStatusID,@RetailPOID=:retailPOID,@PONumber=:poNumber,@POcatergoryId=:pocatergoryId,@Invoice_CreditInvoiceNum=:invoiceCreditInvoiceNum,"
			+ "@NDC=:ndc,@ScheduleType=:scheduleType, @POSearchCriteria=:poSearchCriteria,@Year=:year,@POStartDate=:poStartDate,@POEndDate=:poEndDate,@NotOrderFlag=:notOrderFlag,"
			+ "@StalledOrderFlag=:stalledOrderFlag,@ProductReturnFlag=:productReturnFlag,@ManualOrdersFlag=:manualOrdersFlag,@Quarter=:quarter,"
			+ "@Month=:month,@AddDateFilter=:addDateFilter,@PageNumber=:pageNumber,@PageSize=:pageSize,@SortBy=:sortBy,@SortOrder=:sortOrder,@Export=:export "
			
			+ ", @AddPONumber=:addPONumber,@PODate=:poDate,@PharmacyName=:phName,@wholesalerAccNo=:wholesalerAccNo,@wholesalerName=:wholesalerName,@poStatus=:poStatus,@poTotalOrderAmount=:poTotalOrderAmount"
			+ ", @poTotalBilledAmount=:poTotalBilledAmount", nativeQuery = true)
	List<PurchaseOrder> getPODetails(@Param("ceID") String ceID, @Param("phID") Long phID,
			@Param("phGroupID") Long phGroupID, @Param("wholeSalerID") Long wholeSalerID,
			@Param("drugManufacturerID") String drugManufacturerID, @Param("poStatusID") Long poStatusID,
			@Param("retailPOID") Long retailPOID, @Param("poNumber") String poNumber,
			@Param("pocatergoryId") Integer pocatergoryId,
			@Param("invoiceCreditInvoiceNum") String invoiceCreditInvoiceNum, @Param("ndc") String ndc,
			@Param("scheduleType") String scheduleType, @Param("poSearchCriteria") String poSearchCriteria,
			@Param("year") Integer integer, @Param("poStartDate") String poStartDate,
			@Param("poEndDate") String poEndDate, @Param("notOrderFlag") String notOrderFlag,
			@Param("stalledOrderFlag") String stalledOrderFlag, @Param("productReturnFlag") String productReturnFlag,
			@Param("manualOrdersFlag") String manualOrdersFlag, @Param("quarter") Integer quarter,
			@Param("month") Integer month, @Param("addDateFilter") String addDateFilter,
			@Param("pageNumber") Integer pageNumber, @Param("pageSize") Integer pageSize,
			@Param("sortBy") String sortBy, @Param("sortOrder") String sortOrder, @Param("export") String export
			
			, @Param("addPONumber") String addPONumber, @Param("poDate") String poDate, @Param("phName") String phName
			, @Param("wholesalerAccNo") String wholesalerAccNo, @Param("wholesalerName") String wholesalerName, @Param("poStatus") String poStatus
			, @Param("poTotalOrderAmount") String poTotalOrderAmount, @Param("poTotalBilledAmount") String poTotalBilledAmount
			);

}