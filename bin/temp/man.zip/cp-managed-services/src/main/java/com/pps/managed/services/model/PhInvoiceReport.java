package com.pps.managed.services.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "vw_total_ce_receivable_report", schema = "plus")
public class PhInvoiceReport {

	@Id
	@Column(name = "[ClaimID]")
	private Long claimId;

	@Column(name = "[ProcessedDate]")
	private Date processedDate;

	@Column(name = "[RxNumber]")
	private String  rxNumber;

	@Column(name = "[RxWrittenDate]")
	private Date rxWrittenDate;

	@Column(name = "[Refill#]")
	 private String refillHash;

	@Column(name = "[DateOfService]")
	private Date dateOfService;

	@Column(name = "[340BID]")
	private String tfbId;

	@Column(name = "[CoveredEntity]")
	private String coveredEntity;

	@Column(name = "[MemberFirstName]")
	private String memberFirstName;

	@Column(name = "[MemberLastName]")
	private String memberLastName;

	@Column(name = "[MemberID]")
	private String memberId;

	@Column(name = "[PatientVisitDate]")
	private Date patientVisitDate;

	@Column(name = "[PatientSlidingScale]")
	private String patientSlidingScale;

	@Column(name = "[PhysicianFirstName]")
	private String physicianFirstName;

	@Column(name = "[PhysicianLastName]")
	private String physicianLastName;

	@Column(name = "[PrescriberID]")
	private Long prescriberId;

	@Column(name = "[Store]")
	private String store;

	@Column(name = "[NCPDP]")
	private String ncpdp;

	@Column(name = "[NPI]")
	private String npi;

	@Column(name = "[NDC11]")
	private String ndc11;

	@Column(name = "[Drug Name]")
	private String drugName;

	@Column(name = "[Indicator]")
	private String indicator;

	@Column(name = "[QtyDisp]")
	private BigDecimal qtyDisp;

	@Column(name = "[DaysSupply]")
	private BigDecimal daysSupply;

	@Column(name = "[Bin]")
	private String bin;

	@Column(name = "[PCN]")
	private String pcn;

	@Column(name = "[GroupNumber]")
	private String groupNumber;

	@Column(name = "[PersonType]")
	private Long personType;

	@Column(name = "[PatientPay]")
	private BigDecimal patientPay;

	@Column(name = "[ThirdPartPayment]")
	private Long thirdPartPayment;

	@Column(name = "[CEPlanSubsidy]")
	private BigDecimal cePlanSubsidy;

	@Column(name = "[TotalPayment]")
	private Long totalPayment;

	@Column(name = "[InsuredPatientCost]")
	private Long insuredPatientCost;
	
	@Column(name = "[UninsuredPatientCost]")
	private Long unInsuredPatientCost;

	@Column(name = "[GrossDispensingFee]")
	private String grossDispensingFee;

	@Column(name = "[ProgramAdminFee]")
	private BigDecimal programAdminFee;

	@Column(name = "[340BIngredientCost]")
	private BigDecimal tfbIngredientCost;

	@Column(name = "[TotalClaimCost]")
	private Long totalClaimCost;

	@Column(name = "[TotalCEReceivable]")
	private BigDecimal totalCeReceivable;

	@Column(name = "[ClaimProfitLoss]")
	private BigDecimal claimProfitOrLoss;

	@Column(name = "[Reversed]")
	private Date reversed;

	@Column(name = "[PONumber]")
	private Long poNumber;

	@Column(name = "[CarveInClaimID]")
	private Long carveInClaimId;

	@Column(name = "[CEReimbursementModel]")
	private String cEReimbursementModel;

	@Column(name = "[EAC]")
	private BigDecimal eac;

	@Column(name = "[MemberDateOfBirth]")
	private String memberDateOfBirth;

	@Column(name = "[Startdate]")
	private Date startDate;

	@Column(name = "[enddate]")
	private Date endDate;

	@Column(name = "[CEID]")
	private Long ceid;

	@Column(name = "[PHGroupId]")
	private Long phGroupId;

	@Column(name = "[PHID]")
	private Long phid;
	
	@Column(name="BillingPeriod")
	private Date billingPeriod;

}
