package com.pps.managed.services.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CERemittanceTotalsDTO {
	
	private Long ceid;
	private String totalInvoiced;
	private String dispensingFee;
	private String pharmacyConnectionFee;
	private String trueUp;
	private BigDecimal adjustments;
	private BigDecimal totalPharmacyInvoiced;
	private String direct340BPlusFee;
	private String direct340BPlusVariableTransactionFee;
	private BigDecimal direct340BPlusFlatFee;
	private BigDecimal direct340BTrxnFee;
	private String contractPharmacyMinorMax;
	private BigDecimal total340BDirectPlusFees;
	private String ceTotalReceivedAmount;
	private String ceThresholdMinOrMax;
	private String netDuetoCoveredEntity;
}
