package com.pps.managed.services.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "Person", schema = "dbo")
public class PatientMRNLKP {

	@Id
	@Column(name = "[PersonID]")
	private Long personID;

	@Column(name = "[CEID]")
	private Long ceID;

	@Column(name = "[FirstName]")
	private String firstName;

	@Column(name = "[LastName]")
	private String lastName;

}
