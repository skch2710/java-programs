package com.pps.managed.services.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class InventorySearch extends Pagination {
  
  private List<Long> ceID;
  private Long phID;
  private Long wholesalerID;
  private String ndc;
  private String drugName;
  private Long drugManufacturerID; 
  private Long drugDEAClassID;
  private String inventoryFilter;
}