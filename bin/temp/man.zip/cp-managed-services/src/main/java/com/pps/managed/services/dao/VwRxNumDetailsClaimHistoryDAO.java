package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.VwRxNumDetailsClaimHistory;

@Repository
public interface VwRxNumDetailsClaimHistoryDAO  extends JpaRepository<VwRxNumDetailsClaimHistory, Long>  {
	List<VwRxNumDetailsClaimHistory> findAllByClaimIdAndRxNumber(Long Claimid, String RxNumber);
}
