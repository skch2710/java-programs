package com.pps.managed.services.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClaimDispenseInnerGridDTO {
  
  private Long id; 

  public String claimRx;
  
  public String dispensedDate;  

  public String dispensedQty;  

  public String replenishmentPercentage;  

  public String latestStatus; 
  
  public String ndc;

  private String pharmacyName;  
  
  private String pharmacyNPI;
  
  private Integer openingUnits;  
  
  private Integer unitsDispensed;  
  
  private Integer unitsReplenished;
  
  private Integer inventory340B;
  
  private BigDecimal inventoryCost340B;  
  
  private Integer returnedUnits;  
  
  private Long phID;

  private Long ceID;
  
  private String drugName;  
  
  private Long wholesalerID;
}