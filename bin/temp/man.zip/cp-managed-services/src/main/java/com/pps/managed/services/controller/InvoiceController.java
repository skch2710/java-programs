package com.pps.managed.services.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pps.managed.services.dto.CERemittanceTotalsSearch;
import com.pps.managed.services.dto.InvoiceClaimSearch;
import com.pps.managed.services.dto.InvoiceRemittanceSearch;
import com.pps.managed.services.dto.InvoiceReportSearch;
import com.pps.managed.services.dto.InvoiceSearch;
import com.pps.managed.services.dto.InvoiceTrueUpSearch;
import com.pps.managed.services.dto.Result;
import com.pps.managed.services.service.InvoiceService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/invoice")
@SecurityRequirement(name = "bearerAuth")
@Slf4j
public class InvoiceController {

	/** The invoice service impl. */
	@Autowired
	private InvoiceService invoiceService;

	/**
	 * Gets the PharmacyInvoiceDetails
	 *
	 * @param InvoiceReportSearch invoiceReportSearch
	 * @return the phInvoiceReport
	 */
	@PostMapping("/pharmacyInvoiceDetails")
	public ResponseEntity<?> getPharmacyInvoiceDetails(@RequestBody InvoiceReportSearch invoiceReportSearch) {
		Result result = invoiceService.getPharmacyInvoiceDetails(invoiceReportSearch);
		return ResponseEntity.ok(result);
	}

	/**
	 * Gets the TrueUpReportPopupDetails
	 *
	 * @param InvoiceReportSearch invoiceReportSearch
	 * @return the TrueUpReportPopupDetails
	 */
	@PostMapping("/TrueUpReportPopupDetails")
	public ResponseEntity<?> getTrueUpReportPopupDetails(@RequestBody InvoiceReportSearch invoiceReportSearch) {
		Result result = invoiceService.getTrueUpReportPopupDetails(invoiceReportSearch);
		return ResponseEntity.ok(result);
	}
	
	/**
	 * Get the 340BDirect+ Fees Report
	 * 
	 * @param InvoiceReportSearch invoiceReportSearch
	 * @return Result result
	 */
	@PostMapping("/tfbDirectPlusFeesReport")
	public ResponseEntity<?> getTFBDirectPlusFeesReport(
			@RequestBody InvoiceReportSearch invoiceReportSearch) {
		Result result = invoiceService.getTFBDirectPlusFeesReport(invoiceReportSearch);
		return ResponseEntity.ok(result);
	}
	
	/**
	 * Search invoices.
	 *
	 * @param authorization the authorization
	 * @param InvoiceSearch invoiceSearch
	 * @return the response entity
	 */
	@PostMapping("/searchInvoices")
	public ResponseEntity<?> searchInvoices(
			@RequestHeader(required = false, value = "Authorization") String authorization,
			@RequestBody InvoiceSearch invoiceSearch) {
		Result result = invoiceService.searchInvoicesMainGrid(invoiceSearch);
		return ResponseEntity.ok(result);
	}
	
	/**
	 * Search Pharmacy Invoice Details.
	 *
	 * @param InvoiceSearch the Invoice Search
	 * @return the response entity
	 */
	@PostMapping("/searchPharmacyInvoiceDetails")
	public ResponseEntity<?> searchPharmacyInvoiceDetails(@RequestBody InvoiceSearch invoiceSearch) {
		Result result = invoiceService.searchPharmacyInvoiceDetails(invoiceSearch);
		return ResponseEntity.ok(result);
	}
	
	/**
	 * Search Pharmacy Group Invoice Details.
	 *
	 * @param InvoiceSearch the Invoice Search
	 * @return the response entity
	 */
	@PostMapping("/searchPharmacyGroupInvoiceDetails")
	public ResponseEntity<?> searchPharmacyGroupInvoiceDetails(@RequestBody InvoiceSearch invoiceSearch) {
		Result result = invoiceService.searchPharmacyGroupInvoicedetails(invoiceSearch);
		return ResponseEntity.ok(result);
	}
	
	@PostMapping("/searchInvoiceClaims")
	public ResponseEntity<?> searchIncvoiceClaims(@RequestBody InvoiceClaimSearch invoiceClaimSearch) {
		Result result = invoiceService.invoiceClaim(invoiceClaimSearch);
		return ResponseEntity.ok(result);
	}
	/**
	 * Search invoice remittance details.
	 *
	 * @param invoiceRemittanceSearch the invoice remittance search
	 * @return the response entity
	 */
	@PostMapping("/searchInvoiceRemittance")
	public ResponseEntity<?> searchInvoiceRemittanceDetails(
			@RequestBody InvoiceRemittanceSearch invoiceRemittanceSearch) {
		Result result = invoiceService.searchInvoiceRemittancedetails(invoiceRemittanceSearch);
		return ResponseEntity.ok(result);
	}
	
	@PostMapping("/TrueUpDetails")
	public ResponseEntity<?> searchIncvoiceTrueUp(@RequestBody InvoiceTrueUpSearch InvoiceTrueUpSearch) {
		Result result = invoiceService.searchInvoiceTrueUp(InvoiceTrueUpSearch);
		return ResponseEntity.ok(result);
	}
	
	@PostMapping("/searchCERemittanceTotal")
	public ResponseEntity<?> searchCERemittanceTotalDetails(
			@RequestBody CERemittanceTotalsSearch ceRemittanceTotalsSearch) {
		Result result = invoiceService.searchCERemittanceTotalsdetails(ceRemittanceTotalsSearch);
		return ResponseEntity.ok(result);
	}

} 
