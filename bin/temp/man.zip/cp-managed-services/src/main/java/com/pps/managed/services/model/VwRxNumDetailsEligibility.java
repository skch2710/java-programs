package com.pps.managed.services.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "VwRxNumDetailsEligibility", schema = "plus")
public class VwRxNumDetailsEligibility {
	@Id
	@Column(name = "[id]")
	private Long id;
	
	@Column(name = "[RxNumber]")
	private String rxNumber;
	
	@Column(name = "[Claimid]")
	private Long claimId;
	
	@Column(name = "[EligibilityRule]")
	private String eligibilityRule;
	
	@Column(name = "[EligibilityRuleStatus]")
	private String eligibilityRuleStatus;
}
