package com.pps.managed.services.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pps.managed.services.model.PurchaseOrderStatusLKP;

public interface PurchaseOrderStatusDAO extends JpaRepository<PurchaseOrderStatusLKP, Long> {

}
