package com.pps.managed.services.service;


import com.pps.managed.services.dto.ClaimsManagementSearch;
import com.pps.managed.services.dto.GetRxNumberDetailsSearch;
import com.pps.managed.services.dto.PatientFirstNameSearch;
import com.pps.managed.services.dto.PatientLastNameSearch;
import com.pps.managed.services.dto.PatientMRNSearch;
import com.pps.managed.services.dto.Result;
import com.pps.managed.services.dto.RxNumberSearch;

public interface ClaimsManagementService {

	Result getClaimType();

	Result getBIN();

	Result getFalloutReason();
	
	Result getClaimStatus();

	Result searchClaimsManagement(ClaimsManagementSearch claimsManagementSearch);

	Result getRxNumberByCEID(RxNumberSearch rxNumberSearch);

	Result getPatientMRNByCEID(PatientMRNSearch patientMRNSearch);
	
	Result getPatientFirstName(PatientFirstNameSearch patientFirstNameSearch);

	Result getPatientLastName(PatientLastNameSearch patientLastNameSearch);

	Result getRxDetails(GetRxNumberDetailsSearch getRxNumberDetailsSearch);

}
