package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetRxNumberDetailsSearch {
	
	private Long ceId;
	private Long claimId;
	private String rxNumber;

}
