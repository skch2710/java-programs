package com.pps.managed.services.model;


import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetRxNumberDetails {

	@Id
	private String RxNumber;
	private Long CEID;
	private String PatientName;
	private String ClaimStatus;
	private String CoveredEntity;
	private String Pharmacy;
	private String Prescriber;
	private String EntityLocation;
	private Date RxDateWritten;
	private Date DataFilled;
	private Date VisitDate;
	private Long RefillNumber;
	private BigDecimal DispensedQuantity;
	private String BrandGeneric;
	private String NDC;
	private String DrugName;
	private BigDecimal savings;
	private BigDecimal drugCost;
	private BigDecimal dispensingFee;
	private BigDecimal adminFee;
	private Date PODate;
	private Date InvoiceDate;
	private Long PersonID;
	private Long PHID;
	private Long ClaimID;
	private String Action;
	private Date ActionDate;
	private String Notes;
}
