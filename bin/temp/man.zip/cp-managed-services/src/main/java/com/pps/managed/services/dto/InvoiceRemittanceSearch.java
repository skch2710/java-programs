package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceRemittanceSearch extends Pagination{
	
	private Long ceid;
	private Long phGroupId;
	private Long phId;
	private String startDate;
	private String endDate;

}
