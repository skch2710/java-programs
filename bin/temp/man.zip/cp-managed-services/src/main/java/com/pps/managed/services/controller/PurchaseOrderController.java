package com.pps.managed.services.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pps.managed.services.dto.PurchaseOrderPXClaimSearch;
import com.pps.managed.services.dto.PurchaseOrderSearch;
import com.pps.managed.services.dto.PurchaseOrdersInnerGridSearch;
import com.pps.managed.services.dto.PurchaseOrdersItemHistorySearch;
import com.pps.managed.services.dto.Result;
import com.pps.managed.services.service.PurchaseOrderService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/PurchaseOrder")
@SecurityRequirement(name = "bearerAuth")
@Slf4j
public class PurchaseOrderController {

	@Autowired
	private PurchaseOrderService purchaseOrderService;

	/**
	 * Gets the order status.
	 *
	 * 
	 * @return the order status
	 */
	@GetMapping("/OrderStatus")

	public ResponseEntity<?> getOrderStatus() {
		log.debug("Getting PurchaseOrder Status");
		return ResponseEntity.ok(purchaseOrderService.getPurchseOrderStatus());
	}
	
	
	@PostMapping("/PurchaseOrderPXClaims")
	public ResponseEntity<?> getPurchaseOrderPXClaims(
	    @RequestHeader(required = false, value = "Authorization") String authorization,
	    @RequestBody PurchaseOrderPXClaimSearch purchaseOrderPXClaimSearch) {
	  Result result = purchaseOrderService.getPurchaseOrderPXClaims(purchaseOrderPXClaimSearch);
	  log.info("inside controller");
	  return ResponseEntity.ok(result);
	}

	/**
	 * Gets the Purchase order category by Purchase order category.
	 *
	 * @return the Purchase order category by Purchase order category
	 */
	@GetMapping("/purchaseordercategorylkp")
	public ResponseEntity<?> getPOorderCriteria() {
		return ResponseEntity.ok(purchaseOrderService.getPOorderCriteria());
	}
	
	@PostMapping("/PurchaseOrderItemHistory")
	public ResponseEntity<?> getPurchaseOrderItemHistory(
	    @RequestHeader(required = false, value = "Authorization") String authorization,
	    @RequestBody PurchaseOrdersItemHistorySearch purchaseOrdersItemHistorySearch) {
	  Result result = purchaseOrderService.searchPurchaseOrdersItemHistory(purchaseOrdersItemHistorySearch);
	  return ResponseEntity.ok(result);
	}
	
	/**
	 * Gets the purchase orders inner grid.
	 *
	 * @param purchaseOrdersInnerGridSearch the purchase orders inner grid search
	 * @return the purchase orders inner grid
	 */
	@PostMapping("/POItemInfoSearch")
	public ResponseEntity<?> getPOItemInfoSearch(
			@RequestBody PurchaseOrdersInnerGridSearch purchaseOrdersInnerGridSearch) {
		Result result = purchaseOrderService.searchPurchaseOrdersInnerGrid(purchaseOrdersInnerGridSearch);
		return ResponseEntity.ok(result);
	}

	@PostMapping("/search")
	  public ResponseEntity<Result> searchPurchaseOrder(
	      @RequestHeader(required = false, value = "Authorization") String authorization,
	      @RequestBody PurchaseOrderSearch purchaseOrderSearch) {
	    log.debug("calling search purchase order");
	    Result result = purchaseOrderService.searchPurchaseOrder(purchaseOrderSearch);
	    return ResponseEntity.ok(result);
	  }
	
	@PostMapping("/PurchaseOrderHistory")
	public ResponseEntity<?> getPurchaseOrderHistory(
	    @RequestHeader(required = false, value = "Authorization") String authorization,
	    @RequestBody PurchaseOrdersInnerGridSearch purchaseOrdersInnerGridSearch) {
	  Result result = purchaseOrderService.getPurchseOrderHistory(purchaseOrdersInnerGridSearch);
	  return ResponseEntity.ok(result);
	}

}
