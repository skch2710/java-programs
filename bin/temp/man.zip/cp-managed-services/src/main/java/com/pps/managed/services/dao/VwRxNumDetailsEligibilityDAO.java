package com.pps.managed.services.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import com.pps.managed.services.model.VwRxNumDetailsEligibility;

@Repository
public interface VwRxNumDetailsEligibilityDAO extends JpaRepository<VwRxNumDetailsEligibility, Long>  {
		List<VwRxNumDetailsEligibility> findAllByClaimIdAndRxNumber(Long Claimid, String RxNumber);
}
