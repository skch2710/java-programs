package com.pps.managed.services.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClaimsManagementDTO {
	private String patientName;
	
	private String provider;
	
	private String pharmacy;
	
	private String providerNPI;
	
	private String dos;
	
	private String claimCaptured;
	
	private String status;
	
	private String pharmacyGroup;
	
	private String patientFirstName;
	
	private String patientLastName;
	
	private String patientDOB;
	
	private String claimType;
	
	private String location;
	
	private String providerLastName;
	
	private Long entityLocationID;
	
	private String speciality;
	
	private String eligibility;
	
	private String ceSavings;
	
	private String reasons;
	
	private String score;
	
	private String pharmacyNPI;
	
	private Long mrn;
	
	private String claimStatus;
	
	private Long brandGenericTypeID;
	
	private Long bothTypeID;
	
	private String actionTaken;
	
	private String actionDate;
	
	private String actionTakenBy;
	
	private String note;
	
	private String coveredEntity;
	
	private String hrsaid;
	
	private Long claimID;
	
	private String processedDate;
	
	private String rxNumber;
	
	private String rxWrittenDate;
	
	private String refill;
	
	private String dateofService;
	
	private String memberFirstName;
	
	private String memberLastName;
	
	private String memberID;
	
	private String patientSlidingScale;
	
	private String physicianFirstName;
	
	private String physicianLastName;
	
	private String prescriberID;
	
	private String store;
	
	private String ncpdp;
	
	private String npi;
	
	private String ndc;
	
	private String drugName;
	
	private String indicator;
	
	private String qtyDisp;
	
	private Long daysSupply;
	
	private String bin;
	
	private String pcn;
	
	private String groupNumber;
	
	private String patientType;
	
	private BigDecimal patientPay;
	
	private BigDecimal thirdPartyPayment;
	
	private BigDecimal cePlanSubsidy;
	
	private String totalPayment;
	
	private BigDecimal insuredPatientCost;
	
	private BigDecimal uninsuredPatientCost;
	
	private BigDecimal grossDispensingFee;
	
	private Long programAdminFee;
	
	private String tfBIngredientCost;
	
	private Long totalClaimCost;
	
	private String totalCEReceivable;
	
	private String claimProfitLoss;
	
	private String reversed;
	
	private Long replenishedQty;
	
	private Long totalClaimCostAdjustedforReplenishedQty;
	
	private Long claimProfitLossAdjustedforReplenishedQty;
	
	private Long replenishmentID;
	
	private Long ceReimbursementModelId;
	
	private Long eac;
	
	private String falloutReasons;
	
	private Long claimScore;
	
	private Long phID;
	
	private Long ceID;
	
	private Long personID;
	
	private Long phGroupID;
	
	private Long claimTypeId;
	
	private Long binID;
	
	private Long reasonID;
	
    private String savingsMin;
    
    private String savingsMax;
}
