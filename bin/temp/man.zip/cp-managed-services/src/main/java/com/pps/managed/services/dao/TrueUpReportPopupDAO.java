package com.pps.managed.services.dao;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import com.pps.managed.services.model.TrueUpReportPopup;

public interface TrueUpReportPopupDAO extends JpaRepository<TrueUpReportPopup, Long> {
	
	Page<TrueUpReportPopup> findAll(Specification<TrueUpReportPopup> spec, Pageable pageable);

	List<TrueUpReportPopup> findAll(Specification<TrueUpReportPopup> spec, Sort sort);

}
