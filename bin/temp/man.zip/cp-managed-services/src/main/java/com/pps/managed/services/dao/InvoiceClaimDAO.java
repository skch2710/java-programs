package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pps.managed.services.model.InvoiceClaim;

public interface InvoiceClaimDAO extends JpaRepository<InvoiceClaim, Long> {

	@Query(value = "EXEC Plus.UspInvoiceClaimDetails @In_Ceid = :ceid, @In_StartPeriod = :startPeriod,"
			+ " @In_EndPeriod = :endPeriod," + " @In_Phgroupid = :phgroupid, @In_PhId = :phid,"
			+ " @In_SortColumn = :sortColumn," + " @In_SortDirection = :sortDirection, @In_PageNumber = :pageNumber,"
			+ " @In_PageSize = :pageSize, @In_IsExport = :export,"
			+ " @In_AdminName = :adminName, @In_CEName = :ceName,"
			+ " @In_AdminHRSAID = :hrsaID, @In_CEReimbursementModel = :ceReimbursementModel,"
			+ " @In_CEReplenishmentModel = :ceReplenishmentModel, @In_PharmacyGroup = :pharmacyGroup,"
			+ " @In_PharmacyStoreName = :pharmacyStoreName, @In_PharmacyNPI = :pharmacyNPI,"
			+ " @In_PhysicianFirstName = :physicianFirstName, @In_PhysicianLastName = :physicianLastName,"
			+ " @In_PrescriberId = :prescriberId, @In_ReplenishmentType = :replenishmentType,"
			+ " @In_ClaimID = :claimID, @In_RefillCode = :refillCode,"
			+ " @In_RxNumber = :rxNumber, @In_PgmDateRxWritten = :pgmDateRxWritten,"
			+ " @In_ProcessedDate = :processedDate, @In_DateOfService = :dateOfService,"
			+ " @In_DateReversed = :dateReversed, @In_ClaimStatusCode =:claimStatusCode,"
			+ " @In_ClaimType = :claimType, @In_BIN = :bin," + " @In_PCN = :pcn, @In_GroupNumber = :groupNumber,"
			+ " @In_NDC = :ndc, @In_DrugName = :drugName,"
			+ " @In_BOrGIndicator = :borgIndicator, @In_QtyDisp = :qtyDisp,"
			+ " @In_ReplenishedQty = :replenishedQty, @In_ReplenishmentPercentage = :replenishmentPercentage,"
			+ " @In_PatientPay = :patientPay, @In_ThirdPartyPayment = :thirdPartyPayment,"
			+ " @In_CEPlanSubsidy = :cePlanSubsidy, @In_TotalCollected = :totalCollected,"
			+ " @In_EstimatedAcquisitionCost = :estimatedAcquisitionCost, @In_340BIngredientCost = :tfbIngredientCost,"
			+ " @In_ActualIngredientCost = :actualIngredientCost, @In_TotalInvoiced = :totalInvoiced,"
			+ " @In_DispensingFee = :dispensingFee, @In_GrossSavings = :grossSavings,"
			+ " @In_340BDirectplusFlatFee = :tfbDirectplusFlatFee, @In_340BDirectVariableTransactionFee = :tfbDirectVariableTransactionFee,"
			+ " @In_Total340BDirectplusFee  = :total340BDirectplusFee, @In_TotalCEReceivable = :totalCEReceivable,"
			+ " @In_810DebitInvoice# = :eightTenDebitInvoice, @In_InvoiceDate = :invoiceDate,"
			+ " @In_810CreditInvoice# = :eightTenCreditInvoice, @In_CreditInvoiceDate = :creditInvoiceDate", nativeQuery = true)
	List<InvoiceClaim> getInvoiceClaimDetails(@Param("ceid") Long ceid, @Param("startPeriod") String startPeriod,
			@Param("endPeriod") String endPeriod, @Param("phgroupid") Long phgroupid, @Param("phid") Long phid,
			@Param("sortColumn") String sortColumn, @Param("sortDirection") String sortDirection,
			@Param("pageNumber") int pageNumber, @Param("pageSize") int pageSize, @Param("export") int export,
			@Param("adminName") String adminName, @Param("ceName") String ceName, @Param("hrsaID") String hrsaID,
			@Param("ceReimbursementModel") String ceReimbursementModel,
			@Param("ceReplenishmentModel") String ceReplenishmentModel, @Param("pharmacyGroup") String pharmacyGroup,
			@Param("pharmacyStoreName") String pharmacyStoreName, @Param("pharmacyNPI") String pharmacyNPI,
			@Param("physicianFirstName") String physicianFirstName,
			@Param("physicianLastName") String physicianLastName, @Param("prescriberId") Long prescriberId,
			@Param("replenishmentType") String replenishmentType, @Param("claimID") Long claimID,
			@Param("refillCode") String refillCode, @Param("rxNumber") String rxNumber,
			@Param("pgmDateRxWritten") String pgmDateRxWritten, @Param("processedDate") String processedDate,
			@Param("dateOfService") String dateOfService, @Param("dateReversed") String dateReversed,
			@Param("claimStatusCode") Long claimStatusCode, @Param("claimType") String claimType,
			@Param("bin") String bin, @Param("pcn") String pcn, @Param("groupNumber") String groupNumber,
			@Param("ndc") String ndc, @Param("drugName") String drugName, @Param("borgIndicator") String borgIndicator,
			@Param("qtyDisp") Long qtyDisp, @Param("replenishedQty") Long replenishedQty,
			@Param("replenishmentPercentage") Long replenishmentPercentage, @Param("patientPay") String patientPay,
			@Param("thirdPartyPayment") String thirdPartyPayment, @Param("cePlanSubsidy") String cePlanSubsidy,
			@Param("totalCollected") String totalCollected,
			@Param("estimatedAcquisitionCost") String estimatedAcquisitionCost,
			@Param("tfbIngredientCost") String tfbIngredientCost,
			@Param("actualIngredientCost") String actualIngredientCost, @Param("totalInvoiced") String totalInvoiced,
			@Param("dispensingFee") String dispensingFee, @Param("grossSavings") String grossSavings,
			@Param("tfbDirectplusFlatFee") String tfbDirectplusFlatFee,
			@Param("tfbDirectVariableTransactionFee") String tfbDirectVariableTransactionFee,
			@Param("total340BDirectplusFee") String total340BDirectplusFee,
			@Param("totalCEReceivable") String totalCEReceivable,
			@Param("eightTenDebitInvoice") String eightTenDebitInvoice, @Param("invoiceDate") String invoiceDate,
			@Param("eightTenCreditInvoice") String eightTenCreditInvoice,
			@Param("creditInvoiceDate") String creditInvoiceDate);
}
