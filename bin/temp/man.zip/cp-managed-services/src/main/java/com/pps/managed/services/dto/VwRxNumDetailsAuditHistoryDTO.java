package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VwRxNumDetailsAuditHistoryDTO {
	private Long claimId;
	private String RxNumber;
	private String AuditedBy;
	private String AuditedDate;
}
