package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClaimTypeLKPDTO {

	private Long claimTypeId;
	private String claimTypeCode;
	private String claimType;
}
