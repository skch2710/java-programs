package com.pps.managed.services.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "Reason_LKP", schema = "dbo")
public class FalloutReasonLkp {

	@Id
	@Column(name = "[ReasonID]")
	private Long reasonID;

	@Column(name = "[ReasonCode]")
	private String reasonCode;

	@Column(name = "[ReasonDesc]")
	private String reasonDesc;

	@Column(name = "[ReasonTypeID]")
	private Long reasonTypeID;

	@Column(name = "[InActiveFlag]")
	private String inactiveFlag;

	@Column(name = "[DisplayName]")
	private String displayName;

	@Column(name = "[ReprocessFlag]")
	private String reprocessFlag;

	@Column(name = "[CreatedByID]")
	private Long createdByID;

	@Column(name = "[CreatedDate]")
	private Date createdDate;

	@Column(name = "[ModifiedByID]")
	private Long modifiedByID;

	@Column(name = "[ModifiedDate]")
	private Date modifiedDate;

}
