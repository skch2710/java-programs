package com.pps.managed.services.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceClaimDTO {
	private Long id;

	private String adminName;

	private String ceName;

	private String hrsaID;

	private String ceReimbursementModel;

	private String ceReplenishmentModel;

	private String pharmacyGroup;

	private String pharmacyStoreName;

	private String pharmacyNPI;

	private String physicianFirstName;

	private String physicianLastName;

	private Long prescriberId;

	private String replenishmentType;

	private Long claimID;

	private String refillCode;

	private String rxNumber;

	private String pgmDateRxWritten;

	private String processedDate;

	private String dateOfService;

	private String dateReversed;

	private Long claimStatusCode;

	private String claimType;

	private String bin;

	private String pcn;

	private String groupNumber;

	private String ndc;

	private String drugName;

	private String borGIndicator;

	private BigDecimal qtyDisp;

	private Long replenishedQty;

	private Long replenishmentPercentage;

	private String patientPay;

	private String thirdPartyPayment;

	private String cePlanSubsidy;

	private String totalCollected;

	private String estimatedAcquisitionCost;

	private String tfbIngredientCost;

	private String actualIngredientCost;

	private String totalInvoiced;

	private String dispensingFee;

	private String grossSavings;

	private String tfbDirectplusFlatFee;

	private String tfbDirectVariableTransactionFee;

	private String total340BDirectplusFee;

	private String totalCEReceivable;

	private String eightTenDebitInvoice;

	private String invoiceDate;

	private String eightTenCreditInvoice;

	private String creditInvoiceDate;

	private Long totalRows;
}
