package com.pps.managed.services.common;

public class Constant {
	
	 public final static String EQUALS = "=";
	  public final static String NOTEQUALS = "!=";
	  public final static String LIKE = "contains";
	  public final static String IN = "in";
	  public final static String STRING_IN = "stringIn";
	  public final static String BETWEEN = "between";
	  public final static String BETWEEN_TIME_STAMP = "between_timeStamp";
	  public final static String LESS_THAN = ">";
	  public final static String GREATER_THAN = "<";
	  public final static String LESS_THAN_OR_EQUAL = "<=";
	  public final static String GREATER_THAN_OR_EQUAL = ">=";
	  public final static String GREATER_THAN_EQUAL = "gte";

	  public final static String DATE_FORMAT = "MM/dd/yyyy";
	  public final static String TIME_STAMP_FORMAT = "MM/dd/yyyy HH:mm:ss.SSS";
	  // pharmacies
	  public final static String PHARMACY_NAME = "pharmacyName";
	  public final static String CEID = "ceID";
	  public final static String PHARMACY_GROUP = "pharmacyGroup";
	  public final static String PHARMACY = "pharmacy";
	  public final static String START_DATE = "startDate";
	  public final static String END_DATE = "endDate";
	  public final static String STATUS = "configStatus";
	  public final static String ADMIN_340B = "admin340B";

	  // Providers
	  public final static String EXCLUSIVE = "exclusive";
	  public final static String FIRST_NAME = "firstName";
	  public final static String LAST_NAME = "lastName";
	  public final static String PROVIDER_NPI = "providerNPI";
	  public final static String PROVIDER_ID = "prescriberID";

	  // Location
	  public final static String LOCATION_NAME = "locationName";
	  public final static String ENTITY_LOCATION_ID = "entityLocationID";
	  public final static String SITE_340_B= "site340B";

	  // Inventory
	  public final static String INVENTORY_ID = "inventoryID";
	  public final static String ORG_ID = "orgID";
	  public final static String PHGROUP_ID = "phGroupID";
	  public final static String PH_ID = "phID";
	  public final static String WHOLESALER_ID = "wholesalerID";
	  public final static String NDC = "ndc";
	  public final static String DRUG_NAME = "drugName";
	  public final static String DRUG_MANUFC_ID = "drugManufacturerID";
	  public final static String DRUG_DEACLASS_ID = "drugDEAClassID";
	  public final static String INVENTORY_FILTER = "inventoryFilter";
	  public final static String CE_OWNED_DRUGS = "ceOwnedDrugs";
	  public final static String CLAIMID = "claimId";
	  public final static String CAPTURED_DATE = "claimCaptured";
	  public final static String DRUG_MANU_FACT_NAME = "DrugManufacturerName";

	  // Patients
	  public final static String PATIENT_ID = "patientID";
	  public final static String MRN = "mrn";
	  public final static String EXCLUDE = "exclude";
	  public final static String DOB = "dob";
	  public final static String PATIENT_VISIT_INFO_ID = "patientVisitInfoID";

	  // User management
	  public final static String USERNAME = "userName";
	  public final static String USER_ID = "userID";
	  public final static String EMAIL_ID = "emailID";
	  public final static String USER_TYPE = "userType";
	  public final static String ENTITY_NAME= "entityName";
	  public final static String USER_STATUS_ID = "userStatusID";
	  public final static String ROLE_ID = "roleID";
	  // PurchaseOrder
	  public final static String POSTATUSID = "poStatusID";
	  public final static String PO = "po";
	  public final static String INVOICE_NUMBER = "invoiceNumber";
	  public final static String CREDIT_INVOICE_NUMBER = "creditInvoiceNumber";
	  public final static String PO_SEARCH_CRITERIA_ID = "poSearchCriteriaID";
	  public final static String YEAR = "year";
	  public final static String ADD_DATE_FILTER_ID = "addDateFilterID";
	  public final static String PO_LOG_ID = "poLogID";

	  public final static String GO_LIVE_DATE = "goLiveDate";

	  // PurchaseOrderInnerGrid
	  public final static String PO_ID = "poID";
	  public final static String PO_ITEM_ID = "poItemID";
	  
	  // InventoryInnerGrid
	  public final static String CLAIM_ID = "claimID";
	  public final static String REF_NO = "refNo";

	  // ClaimsManagement
	  public final static String RX_NUMBER = "rxNumber";
	  public final static String DOS = "dos";
	  public final static String PATIENT_FIRST_NAME = "patientFirstName";
	  public final static String PATIENT_LAST_NAME = "patientLastName";
	  public final static String PROVIDER = "provider";
	  public final static String LOCATION = "location";
	  public final static String SPECIALITY = "speciality";
	  public final static String SAVINGS_MIN = "savingsMin";
	  public final static String SAVINGS_MAX = "savingsMax";
	  public final static String ELIGIBILITY = "eligibility";
	  public final static String PATIENT_DOB = "patientDOB";
	  public final static String PERSON_ID = "personID";
	  public final static String CLAIM_TYPE_ID = "claimTypeId";
	  public final static String CLAIM_STATUS_ID = "claimStatusId";
	  public final static String BIN_ID = "binID";
	  public final static String PROVIDER_LAST_NAME = "providerLastName";
	  public final static String BRAND_GENERIC_TYPE_ID = "brandGenericTypeID";
	  public final static String BOTH_TYPE_ID = "bothTypeID";
	  public final static String REASON_ID = "reasonID";
	  public final static String CLAIM_STATUS = "status";
	  public final static String CLAIM_STATUS_CODE = "9";
	  
	  //Pharmacy config
	  public final static String PH_BASIC_DETAILS = "phBasicDetails";
	  public final static String PH_UPLOADED_DOC_BASIC_DETAILS = "phUploadedDocBasicDetails";
	  public final static String FILE_NAME = "fileName";
	  public final static String ASC = "asc";
	  public final static String PH_DISPENSING_FEES = "phDispensingFees";
	  public final static String PH_TRUE_UP_FEES_DETAILS = "phTrueUpFeesDetails";
	  public final static String PH_TRUE_UP_ADDED_FEES_DETAILS = "phTrueUpAddedFeesDetails";  
	  public final static String TRUE_UP_TYPE = "trueUpType";
	  public final static String PH_CLAIM_EXCLUSION_BASED_ON_FEES = "phClaimExclusionsBasedOnFees";
	  public final static String PH_CLIENT_ORDER_AND_REPLENISH_DETAILS = "phClientOrderAndReplenishDetails";
	  public final static String PH_GROUP_ORDER_AND_REPLENISH_DETAILS = "phGroupOrderAndReplenishDetails";
	  public final static String BIN = "bin";
	  public final static String PH_GLOBAL_BIN_BLOCKS_DETAILS = "phGlobalBINBlocksDetails";
	  public final static String BIN_BLOCKS_PH_NETWORK_ID = "binBlocksPHNetworkId";
	  public final static String PH_NETWORK_BIN_BLOCKS_DETAILS = "phNetworkBINBlocksDetails";
	  public final static String PH_GLOBAL_BIN_BLOCKS_ID = "globalBinBlocksID";
	  public final static String DISPENSING_FEE_TYPE = "dispensingFeeType";
	  public final static String PH_DISPENSING_ADDED_FEES_DETAILS = "phDispensingAddedFeesDetails";
	  public final static String PH_CE_BIN_BLOCKS_DETAILS = "phCEBINBlocksDetails";
	  public final static String PH_CLIENT_BIN_BLOCKS_DETAILS = "phClientBINBlocksDetails";
	  public final static String ADMIN_FEE_TYPE = "feeType";
	  public final static String PH_ADMIN_FEES_DETAILS = "phAdminFeesDetails";
	  
	  //Covered Entity config
	  public final static String CE_TERMS_DETAILS = "ceTermsDetails";
	  public final static String CE_BASIC_DETAILS = "ceBasicDetails";
	  public final static String CE_ACH_DETAILS = "ceACHDetails";
	  public final static String CE_BILLING_FEES_DETAILS = "ceBillingFeesDetails";
	  public final static String CE_SERVICE_AREA_CONFIG_DETAILS = "ceServiceAreaConfigDetails";
	  public final static String CE_VISIT_WINDOW_DETAILS = "ceVisitWindowDetails";
	  public static final String PH_ELIGIBILITY_DETAILS = "phEligibilityDetails";
	  
	  //Home Dashboard
	  public final static String CLAIM_SAVINGS = "claimSavings";
	  public final static String PHARMACY_SAVINGS = "pharmacySavings";
	  public final static String PROVIDER_SAVINGS = "providerSavings";
	  public final static String NDC_SAVINGS = "ndcSavings";
	  public final static String SAVINGS_BY_PHARMACY ="SavingsbyPharmacy";
	  
	  public final static String ID = "id";
	  
	  //Invoice constant
	  public final static String BILLING_PERIOD_INVOICE = "billingPeriod";
	  public final static String INVOICE_PERIOD_START_DATE = "invoicePeriodStartDate"; 
	  public final static String INVOICE_PERIOD_END_DATE = "invoicePeriodEndDate";
	  public final static String SAVINGS_INVOICE = "savings";
	  public final static String ADJUSTMENTS_INVOICE = "adjustments";
	  public final static String TRUE_UP_INVOICE = "trueup";
	  public final static String ADMIN_FEES_INVOICE = "adminFees";
	  public final static String CE_INVOICE = "ceInvoice";
	  public final static String PH_GROUP_ID = "phGroupId";
	  public final static String PHID = "phid";
	  public final static String CE_ID = "ceid";
	  public static final String BILLING_PERIOD = "billingPeriod";
	  
	  public static final String LATEST_STATUS = "latestStatus";
	  
		public final static String BETWEEN_DATE = "betweenDate";
		public final static String CREATED_DATE = "createdDate";
		public static final String PO_DATE = "poDate";
		public static final String PO_STATUS_DATE = "poStatusDate";
		public static final String TFB_DIRECT_INVOICEDATE = "invoiceDate340BDirect";
		public static final String DATE_OF_SERVICE = "dateOfService";
		public static final String ITEM_ORDERED_DATE = "itemOrderedDate";
		public static final String ITEM_ACKNOWLEDEGED_DATE = "itemAcknowledgedDate";
		public static final String ITEM_INVOICED_DATE = "itemInvoicedDate";
		public static final String ITEM_RECONCILED_DATE = "itemReconciledDate";
		
	// filter for purchase order search 	
	 public final static String PH_NAME = "pharmacy";
	 public final static String WHOLESALER_ACC_NO = "wholesalerAccountID";
	 public final static String WHOLESALER_NAME = "wholesaler";
	 public final static String PO_STATUS = "poStatus";
	 public final static String PO_TOTAL_ORDER_AMT = "totalOrderAmount";
	 public final static String PO_TOTAL_BILLER_AMT = "totalBilledAmount";
	 
	 // Claims
	 public final static String  NUMBER_MASK ="00000000";
	 public final static String NAME_MASK = "ABC";
	 public final static String DATE_MASK = "00/00/0000";
	 
	 //RxDatatimeLine
	 public final static String VISIT = "Visit";
	 public final static String RX_WRITTEN = "Rx Written";
	 public final static String RX_FILLED = "Rx Filled";
	 public final static String PURCHASE_ORDER = "Purchase Order";
	 public final static String INVOICES = "Invoices";
	public static final String CLAIM_CAPTURED = "claimCaptured";
	public final static String START_WITH = "startWith";
	
	 public final static String ACTION_DATE = "actionDate";	
	 public final static String ACTION = "action";	
	 public final static String INV_CAPTURED_DATE = "capturedDate";	
	 public final static String DISPENSED_QTY = "dispensedQty";	
	 public final static String REPLENISHED_QTY = "replenishedQty";	
	 public final static String TRUE_UP_QTY = "trueUpQty";	
	 public final static String REPLENISHED_PERC = "replenishedPerc";	
	 public final static String TOTAL_PRICE = "totalPrice";
	
	// filter for invoice search
	 public static final String CE_NAME = "ceName";
	 public static final String TOTAL_INVOICED = "totalInvoiced";
	 public static final String DISPENSING_FEE = "dispensingFee";
	 public static final String TRUE_UP = "trueUp";
	 public static final String STORE_FEES = "storeFees";
	 public static final String CE_TOTAL_RECEIVED_AMOUNT = "ceTotalReceivedAmount";
	 public static final String DIRECT340B_TRXN_FEE = "direct340BTrxnFee";
	 public static final String PH_GROUP_NAME = "phGroupName";
	 public static final String PHY_NAME = "phName";
	 public static final String EST_CE_SAVINGS = "estimatedCeSavings";
	 public static final String PH_PAYMENT_RECIVED = "pharmacyPaymentReceived";
	 public static final String TFB_DIRECT_PLUS_REMITTANCE = "tfbDirectPlusRemittance";
	 public static final String ADMIN_NAME = "adminName";
	 public static final String HRSA_ID = "hrsaID";
	 public static final String CE_REIMBURSEMENT_MODEL = "ceReimbursementModel";
	 public static final String CE_REPLENISHMENT_MODEL = "ceReplenishmentModel";
	 public static final String PHARMACY_STORE_NAME = "pharmacyStoreName";
	 public static final String PHARMACY_NPI = "pharmacyNPI";
	 public static final String PHYSICIAN_FIRST_NAME = "physicianFirstName";
	 public static final String PHYSICIAN_LAST_NAME = "physicianLastName";
	 public static final String PRESCRIBER_ID = "prescriberId";
	 public static final String REPLENISHMENT_TYPE = "replenishmentType";
	 public static final String REFILL_CODE = "refillCode";
	 public static final String PGM_DATE_RX_WRITTEN = "pgmDateRxWritten";

		public static final String PROCESSED_DATE = "processedDate";
		public static final String DATE_REVERSED = "dateReversed";
		public static final String CLAIM_TYPE = "claimType";
		public static final String PCN = "pcn";
		public static final String GROUP_NUMBER = "groupNumber";
		public static final String B_OR_G_INDICATOR = "BOrGIndicator";
		public static final String REPLENISHMENT_PERCENTAGE = "replenishmentPercentage";
		public static final String PATIENT_PAY = "patientPay";
		public static final String THIRD_PARTY_PAYMENT = "thirdPartyPayment";
		public static final String CE_PLAN_SUBSIDY = "cePlanSubsidy";
		public static final String TOTAL_COLLECTED = "totalCollected";
		public static final String ESTIMATED_ACQUISITION_COST = "estimatedAcquisitionCost";
		public static final String TFB_INGREDIENT_COST = "tfbIngredientCost";
		public static final String ACTUAL_INGREDIENT_COST = "actualIngredientCost";
		public static final String GROSS_SAVINGS = "grossSavings";
		public static final String TFB_DIRECTPLUS_FLAT_FEE = "tfbDirectplusFlatFee";
		public static final String TFB_DIRECT_VARIABLE_TRANSACTION_FEE = "tfbDirectVariableTransactionFee";
		public static final String TOTAL_340B_DIRECTPLUS_FEE = "total340BDirectplusFee";
		public static final String TOTAL_CE_RECEIVABLE = "totalCEReceivable";
		public static final String EIGHT_TEN_DEBIT_INVOICE = "eightTenDebitInvoice";
		public static final String INVOICE_DATE = "invoiceDate";
		public static final String EIGHT_TEN_CREDIT_INVOICE = "eightTenCreditInvoice";
		public static final String CREDIT_INVOICE_DATE = "creditInvoiceDate";
		public static final String QTY_DISP = "qtyDisp";
		
		
		public static final String BILLING_CYCLE = "billingCycle";
		public static final String TFB_ID = "tfbID";
		public static final String RX_WRITTEN_DATE = "rxWrittenDate";
		public static final String REFILL_NUMBER = "refillNumber";
		public static final String STORE = "store";
		public static final String DISPATCHING_STORE_NPI = "dispensingStoreNpi";
		public static final String BRAND_GENERIC_FLAG = "brandGenericFlag";
		public static final String REPLENISHED_PERCENTAGE = "replenishedPercentage";
		public static final String TRUE_UP_UNITS = "trueUpUnits";
		public static final String TRUE_UP_AMOUNT = "trueUpAmount";
		public static final String TRUE_UP_REASON = "trueUpReason";
		public static final String CE_SAVINGS = "ceSavings";
 
}