package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pps.managed.services.model.CERemittanceTotals;

public interface CERemittanceTotalsDAO extends JpaRepository<CERemittanceTotals, Long>{

	@Query(value = "Exec Plus.UspInvoiceCeRemittanceTotal @In_Ceid=:ceid,@In_phgroupid =:phGroupId,@In_PhId=:phId, @In_StartPeriod=:startDate,@In_EndPeriod=:endDate", nativeQuery = true)
	List<CERemittanceTotals> getCERemittanceTotalsDetails(@Param("ceid") Long ceid, @Param("phGroupId") Long phGroupId, @Param("phId") Long phId, @Param("startDate") String startDate,
			@Param("endDate") String endDate);
}
