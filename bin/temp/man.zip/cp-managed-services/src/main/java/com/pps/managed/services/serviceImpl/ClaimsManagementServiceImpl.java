package com.pps.managed.services.serviceImpl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.pps.managed.services.common.Constant;
import com.pps.managed.services.dao.BinLKPDAO;
import com.pps.managed.services.dao.ClaimTypeLKPDAO;
import com.pps.managed.services.dao.ClaimsManagementDAO;
import com.pps.managed.services.dao.ClaimsstatuslkpDAO;
import com.pps.managed.services.dao.FalloutReasonLkpDAO;
import com.pps.managed.services.dao.GetRxNumberDetailsDAO;
import com.pps.managed.services.dao.PatientMRNDAO;
import com.pps.managed.services.dao.RxNumberDAO;
import com.pps.managed.services.dao.VwRxNumDetailsAuditHistoryDAO;
import com.pps.managed.services.dao.VwRxNumDetailsClaimHistoryDAO;
import com.pps.managed.services.dao.VwRxNumDetailsEligibilityDAO;
import com.pps.managed.services.dao.VwRxNumDetailsVisitHistoryDAO;
import com.pps.managed.services.dto.BinLKPDTO;
import com.pps.managed.services.dto.ClaimTypeLKPDTO;
import com.pps.managed.services.dto.ClaimsManagementDTO;
import com.pps.managed.services.dto.ClaimsManagementSearch;
import com.pps.managed.services.dto.ClaimsstatuslkpDTO;
import com.pps.managed.services.dto.ColumnFilter;
import com.pps.managed.services.dto.FalloutReasonLkpDTO;
import com.pps.managed.services.dto.GetRxNumberDetailsDTO;
import com.pps.managed.services.dto.GetRxNumberDetailsSearch;
import com.pps.managed.services.dto.PatientFirstNameSearch;
import com.pps.managed.services.dto.PatientLastNameSearch;
import com.pps.managed.services.dto.PatientMRNDTO;
import com.pps.managed.services.dto.PatientMRNSearch;
import com.pps.managed.services.dto.Result;
import com.pps.managed.services.dto.RxNumberSearch;
import com.pps.managed.services.dto.RxNumberTimelineData;
import com.pps.managed.services.dto.SearchResult;
import com.pps.managed.services.dto.VwRxNumDetailsAuditHistoryDTO;
import com.pps.managed.services.dto.VwRxNumDetailsClaimHistoryDTO;
import com.pps.managed.services.dto.VwRxNumDetailsEligibilityDTO;
import com.pps.managed.services.dto.VwRxNumDetailsVisitHistoryDTO;
import com.pps.managed.services.exception.CustomException;
import com.pps.managed.services.mapper.ObjectMapper;
import com.pps.managed.services.model.ClaimsManagement;
import com.pps.managed.services.model.GetRxNumberDetails;
import com.pps.managed.services.model.RxNumberLkp;
import com.pps.managed.services.model.VwRxNumDetailsAuditHistory;
import com.pps.managed.services.model.VwRxNumDetailsClaimHistory;
import com.pps.managed.services.model.VwRxNumDetailsEligibility;
import com.pps.managed.services.model.VwRxNumDetailsVisitHistory;
import com.pps.managed.services.service.ClaimsManagementService;
import com.pps.managed.services.specs.GenericSpecification;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class ClaimsManagementServiceImpl.
 */
@Service

/** The Constant log. */
@Slf4j
public class ClaimsManagementServiceImpl implements ClaimsManagementService {

	/** The mapper. */
	private ObjectMapper MAPPER = ObjectMapper.INSTANCE;

	@Autowired
	private ClaimTypeLKPDAO claimTypeLKPDAO;

	@Autowired
	private BinLKPDAO binLKPDAO;

	@Autowired
	private FalloutReasonLkpDAO falloutReasonLkpDAO;
	
	@Autowired
	private ClaimsstatuslkpDAO claimsstatuslkpDAO;
	
	@Autowired

	private RxNumberDAO rxNumberDAO;

	@Autowired
	private ClaimsManagementDAO claimsManagementDAO;
    
	@Autowired
	private PatientMRNDAO patientMRNDAO;


	@Autowired
	private GetRxNumberDetailsDAO getRxNumberDetailsDAO;
	
	@Autowired
	private VwRxNumDetailsAuditHistoryDAO vwRxNumDetailsAuditHistoryDAO;
	
	@Autowired
	private VwRxNumDetailsClaimHistoryDAO vwRxNumDetailsClaimHistoryDAO;
	
	@Autowired
	private VwRxNumDetailsEligibilityDAO vwRxNumDetailsEligibilityDAO;
	
	@Autowired
	private VwRxNumDetailsVisitHistoryDAO vwRxNumDetailsVisitHistoryDAO;
	/**
	 * Gets the claim type.
	 *
	 * @return the claim type
	 */
	@Override
	public Result getClaimType() {
		Result result = null;
		try {
			List<ClaimTypeLKPDTO> claimTypeLKPDTOs = MAPPER.fromClaimTypeLKPModel(claimTypeLKPDAO.findAll());
			
			for (ClaimTypeLKPDTO claimTypeLKPDTO : claimTypeLKPDTOs) {
				if(claimTypeLKPDTO.getClaimTypeCode().trim().equalsIgnoreCase(Constant.CLAIM_STATUS_CODE)) {
					claimTypeLKPDTOs.remove(claimTypeLKPDTOs.indexOf(claimTypeLKPDTO));
					break;
				}
			}
			
			result = new Result(claimTypeLKPDTOs);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting all claim type LKP Data");

		} catch (Exception e) {
			log.error("Error in ClaimType :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Gets the bin.
	 *
	 * @return the bin
	 */
	@Override
	public Result getBIN() {
		Result result = null;
		try {
			List<BinLKPDTO> binLKPDTOs = MAPPER.fromBINModel(binLKPDAO.findAll());
			result = new Result(binLKPDTOs);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting all BIN Data");
		} catch (Exception e) {
			log.error("Error in BIN :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Gets the fallout reason.
	 *
	 * @return the fallout reason
	 */
	@Override
	public Result getFalloutReason() {
		Result result = null;
		try {
			List<FalloutReasonLkpDTO> falloutReasonLkpDTOs = MAPPER
					.fromFalloutReasonModel(falloutReasonLkpDAO.findAll());
			result = new Result(falloutReasonLkpDTOs);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting all fallout reason Data");

		} catch (Exception e) {
			log.error("Error in  FalloutReason:: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Gets the claim status by claim status ID.
	 *
	 * @return the claim status by claim status ID
	 */
	@Override
	public Result getClaimStatus() {
		Result result = null;
		try {
			List<ClaimsstatuslkpDTO> claimsstatuslkpDTOs = MAPPER.fromClaimsstatuslkp(claimsstatuslkpDAO.findAll());
			result = new Result(claimsstatuslkpDTOs);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting claimsstatus");
		} catch (Exception e) {
			log.error("Error in claimsstatus :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}


  /**
   * Search claims management.
   *
   * @param claimsManagementSearch the claims management search
   * @return the result
   */
	@Override
	public Result searchClaimsManagement(ClaimsManagementSearch claimsManagementSearch) {
		log.debug("inside searchClaimsManagement ");
		Result result = null;
		try {
			Map<String, Object> filters = null;
			Map<String, Map<String, Object>> dynamicFilters = new HashMap<String, Map<String, Object>>();
			Map<String, Map<String, Object>> addDynamicFilters = new HashMap<String, Map<String, Object>>();
			if (claimsManagementSearch.getSortBy() == null || "".equalsIgnoreCase(claimsManagementSearch.getSortBy())) {
				claimsManagementSearch.setSortBy(Constant.CEID);
			}
		
			if (claimsManagementSearch.getFilter() != null) {
				for (ColumnFilter filter : claimsManagementSearch.getFilter()) {
					if (filter.getColumn().getField().equalsIgnoreCase("ceSavings")) {
						filter.setValue(filter.getValue().replace("$", "").replace(",", ""));
					}
				}
				GenericSpecification.dynamicFilters(claimsManagementSearch.getFilter(), dynamicFilters);
				GenericSpecification.dynamicFilters(claimsManagementSearch.getFilter(), addDynamicFilters);
			}
		
			if (claimsManagementSearch.getCeID() != null && claimsManagementSearch.getCeID().size() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.IN, claimsManagementSearch.getCeID());
				dynamicFilters.put(Constant.CEID, filters);
			}

			if (claimsManagementSearch.getPhGroupID() != null && claimsManagementSearch.getPhGroupID().size() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.IN, claimsManagementSearch.getPhGroupID());
				dynamicFilters.put(Constant.PHGROUP_ID, filters);
			}

			if (claimsManagementSearch.getPhID() != null && claimsManagementSearch.getPhID().size() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.IN, claimsManagementSearch.getPhID());
				dynamicFilters.put(Constant.PH_ID, filters);
			}

			if (claimsManagementSearch.getEntityLocationID() != null
					&& claimsManagementSearch.getEntityLocationID().size() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.IN, claimsManagementSearch.getEntityLocationID());
				dynamicFilters.put(Constant.ENTITY_LOCATION_ID, filters);
			}

			if (claimsManagementSearch.getRxNumber() != null && claimsManagementSearch.getRxNumber().size() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.STRING_IN, claimsManagementSearch.getRxNumber());
				dynamicFilters.put(Constant.RX_NUMBER, filters);
			}

			if (claimsManagementSearch.getClaimTypeID() != null && claimsManagementSearch.getClaimTypeID().size() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.IN, claimsManagementSearch.getClaimTypeID());
				dynamicFilters.put(Constant.CLAIM_TYPE_ID, filters);
			}

			if (claimsManagementSearch.getStatus() != null && claimsManagementSearch.getStatus().size() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.STRING_IN, claimsManagementSearch.getStatus());
				dynamicFilters.put(Constant.CLAIM_STATUS, filters);
			}

			if (claimsManagementSearch.getBinID() != null && claimsManagementSearch.getBinID().size() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.IN, claimsManagementSearch.getBinID());
				dynamicFilters.put(Constant.BIN_ID, filters);
			}

			if (claimsManagementSearch.getBrandGenericTypeID() != null
					&& claimsManagementSearch.getBrandGenericTypeID() > 0
					&& claimsManagementSearch.getBrandGenericTypeID() < 3) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.START_WITH, claimsManagementSearch.getBrandGenericTypeID());
				dynamicFilters.put(Constant.BRAND_GENERIC_TYPE_ID, filters);
			}

			if (claimsManagementSearch.getBrandGenericTypeID() != null
					&& claimsManagementSearch.getBrandGenericTypeID() == 3) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.START_WITH, claimsManagementSearch.getBrandGenericTypeID());
				dynamicFilters.put(Constant.BOTH_TYPE_ID, filters);
			}

			if (claimsManagementSearch.getReasonID() != null && claimsManagementSearch.getReasonID().size() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.IN, claimsManagementSearch.getReasonID());
				dynamicFilters.put(Constant.REASON_ID, filters);
			}

			if (claimsManagementSearch.getProviderNPI() != null
					&& !"".equals(claimsManagementSearch.getProviderNPI())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.START_WITH, claimsManagementSearch.getProviderNPI());
				dynamicFilters.put(Constant.PROVIDER_NPI, filters);
			}

			if (claimsManagementSearch.getProviderLastName() != null
					&& !"".equals(claimsManagementSearch.getProviderLastName())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.START_WITH, claimsManagementSearch.getProviderLastName());
				dynamicFilters.put(Constant.PROVIDER_LAST_NAME, filters);
			}

			if (claimsManagementSearch.getSavingsMin() != null && !"".equals(claimsManagementSearch.getSavingsMin())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.GREATER_THAN_EQUAL, claimsManagementSearch.getSavingsMin());
				dynamicFilters.put(Constant.CE_SAVINGS, filters);
			}

			if (claimsManagementSearch.getSavingsMax() != null && !"".equals(claimsManagementSearch.getSavingsMax())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.LESS_THAN_OR_EQUAL, claimsManagementSearch.getSavingsMax());
				addDynamicFilters.put(Constant.CE_SAVINGS, filters);
			}

			if (claimsManagementSearch.getPatientFirstName() != null
					&& !"".equals(claimsManagementSearch.getPatientFirstName())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.START_WITH, claimsManagementSearch.getPatientFirstName());
				dynamicFilters.put(Constant.PATIENT_FIRST_NAME, filters);
			}
			if (claimsManagementSearch.getDosToDate() == null || "".equals(claimsManagementSearch.getDosToDate())) {
				LocalDate today = LocalDate.now();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
				String formattedDate = today.format(formatter);
				claimsManagementSearch.setDosToDate(formattedDate);
			}
			if (claimsManagementSearch.getDosFromDate() != null && !"".equals(claimsManagementSearch.getDosFromDate())
					&& claimsManagementSearch.getDosToDate() != null
					&& !"".equals(claimsManagementSearch.getDosToDate())) {
				filters = new HashMap<String, Object>();
				Map<String, String> dateMap = new HashMap<>();
				dateMap.put(Constant.START_DATE, claimsManagementSearch.getDosFromDate());
				dateMap.put(Constant.END_DATE, claimsManagementSearch.getDosToDate());
				filters.put(Constant.BETWEEN, dateMap);
				dynamicFilters.put(Constant.DOS, filters);
			}

			if (claimsManagementSearch.getCapturedFromDate() != null
					&& !"".equals(claimsManagementSearch.getCapturedFromDate())
					&& claimsManagementSearch.getCapturedToDate() != null
					&& !"".equals(claimsManagementSearch.getCapturedToDate())) {
				filters = new HashMap<String, Object>();
				Map<String, String> dateMap = new HashMap<>();
				dateMap.put(Constant.START_DATE, claimsManagementSearch.getCapturedFromDate().concat(" 00:00:00.000"));
				dateMap.put(Constant.END_DATE, claimsManagementSearch.getCapturedToDate().concat(" 23:59:00.000"));
				filters.put(Constant.BETWEEN_TIME_STAMP, dateMap);
				dynamicFilters.put(Constant.CAPTURED_DATE, filters);
			}

			if (claimsManagementSearch.getPatientLastName() != null
					&& !"".equals(claimsManagementSearch.getPatientLastName())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.START_WITH, claimsManagementSearch.getPatientLastName());
				dynamicFilters.put(Constant.PATIENT_LAST_NAME, filters);
			}

			if (claimsManagementSearch.getNdc() != null && !"".equals(claimsManagementSearch.getNdc())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.START_WITH, claimsManagementSearch.getNdc());
				dynamicFilters.put(Constant.NDC, filters);
			}

			if (claimsManagementSearch.getPatientDOB() != null && !"".equals(claimsManagementSearch.getPatientDOB())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, claimsManagementSearch.getPatientDOB());
				dynamicFilters.put(Constant.PATIENT_DOB, filters);
			}

			if (claimsManagementSearch.getMrn() != null && claimsManagementSearch.getMrn().size() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.IN, claimsManagementSearch.getMrn());
				dynamicFilters.put(Constant.MRN, filters);
			}

			result = new Result();
			if (!claimsManagementSearch.isExport()) {
				
				Specification<ClaimsManagement> specification = GenericSpecification.getSpecification(dynamicFilters);
				
				if (!addDynamicFilters.isEmpty()) {
					specification = GenericSpecification.additionalSpecification(specification, addDynamicFilters);
				}
				
				Page<ClaimsManagement> pageResult = claimsManagementDAO.findAll(specification,
						GenericSpecification.getPagination(claimsManagementSearch));

				SearchResult<ClaimsManagementDTO> searchResult = GenericSpecification.getPaginationDetails(pageResult,
						ClaimsManagementDTO.class);
				List<ClaimsManagementDTO> claimsManagementDTOs = MAPPER
						.fromClaimsManagementModel(pageResult.getContent());

				if (claimsManagementSearch.getPatientInfo() != null
						&& claimsManagementSearch.getPatientInfo().equalsIgnoreCase("no")) {
					for (ClaimsManagementDTO claimsManagementDTO : claimsManagementDTOs) {
						claimsManagementDTO.setRxNumber(Constant.NUMBER_MASK);
						claimsManagementDTO.setPatientFirstName(Constant. NAME_MASK);
						claimsManagementDTO.setPatientLastName(Constant. NAME_MASK);
						claimsManagementDTO.setPatientDOB(Constant.DATE_MASK);
						claimsManagementDTO.setPatientName(Constant. NAME_MASK +" "+Constant. NAME_MASK);
						claimsManagementDTO.setMemberFirstName(Constant. NAME_MASK);
						claimsManagementDTO.setMemberLastName(Constant. NAME_MASK);
					}
				}

				searchResult.setContent(claimsManagementDTOs);
				result.setData(searchResult);
				if (claimsManagementDTOs.size() == 0) {
					result.setStatusCode(HttpStatus.NOT_FOUND.value());
					result.setErrorMessage("No Result Found");
				} else {
					result.setStatusCode(HttpStatus.OK.value());
					result.setSuccessMessage("Fetching all claims management details based on the selected filters");
				}
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setData(exportData(claimsManagementSearch, dynamicFilters));
			}

		} catch (Exception e) {
			log.error("Error in searchClaimsManagement :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}


  /**
   * Export data.
   *
   * @param claimsManagementSearch the claims management search
   * @param dynamicFilters the dynamic filters
   * @return the search result
   */
  private SearchResult<ClaimsManagementDTO> exportData(
      ClaimsManagementSearch claimsManagementSearch,
      Map<String, Map<String, Object>> dynamicFilters) {
    SearchResult<ClaimsManagementDTO> searchResult = new SearchResult<>();
    try {
      List<ClaimsManagement> sortResult =
          this.claimsManagementDAO.findAll(GenericSpecification.getSpecification(dynamicFilters),
              GenericSpecification.getSort(claimsManagementSearch));

      List<ClaimsManagementDTO> claimsManagementDTOs = MAPPER.fromClaimsManagementModel(sortResult);
      searchResult.setContent(claimsManagementDTOs);
    } catch (Exception e) {
      log.error("Error in exportData :: ", e);
      throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
    return searchResult;
  }
  
	/**
	 * Gets the rx number by claim rx no ID.
	 *
	 * @param RxNumberSearch rxNumberSearch
	 * @return the rx number by claim rx no ID
	 */
	@Override
	public Result getRxNumberByCEID(RxNumberSearch rxNumberSearch) {
		Result result = null;
		try {
			List<RxNumberLkp> rxNumbers = rxNumberDAO.getRxNumberDetails(rxNumberSearch.getCeID().get(0), rxNumberSearch.getRxNumber());
			result = new Result(rxNumbers);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting all rxnumber Data");
		} catch (Exception e) {
			log.error("Error in rxNumber Data :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}


	/**
	 * Gets the patient MRN by CEID.
	 *
	 * @param PatientMRNSearch patientMRNSearch
	 * @return the patient MRN by CEID
	 */
	@Override
	public Result getPatientMRNByCEID(PatientMRNSearch patientMRNSearch) {
		Result result = null;
		try {
			List<PatientMRNDTO> patientMRNDTOs = MAPPER.fromPatientMRNModel(
					patientMRNDAO.getPatientMRNLKPDetails(patientMRNSearch.getCeID(), patientMRNSearch.getPersonId()));
			result = new Result(patientMRNDTOs);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting all petientMRN Data");
		} catch (Exception e) {
			log.error("Error in petientMRN :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}
	
	/**
	 * Gets the patient FirstName.
	 *
	 * @param PatientFirstNameSearch  patientFirstNameSearch 
	 * @return the patient FirstName by CEID
	 */
	@Override
	public Result getPatientFirstName(PatientFirstNameSearch patientFirstNameSearch) {
		
		Result result = null;
		try {
			List<PatientMRNDTO> patientMRNDTOs = MAPPER.fromPatientMRNModel(
					patientMRNDAO.getPatientFirstName(patientFirstNameSearch.getCeID(), patientFirstNameSearch.getFirstName()));
			result = new Result(patientMRNDTOs);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting all patient First Name");
		} catch (Exception e) {
			log.error("Error in patient First Name :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Gets the patient LastName.
	 *
	 * @param PatientLastNameSearch  patientLastNameSearch 
	 * @return the patient LastName by CEID
	 */
	@Override
	public Result getPatientLastName(PatientLastNameSearch patientLastNameSearch) {
		Result result = null;
		try {
			List<PatientMRNDTO> patientMRNDTOs = MAPPER.fromPatientMRNModel(
					patientMRNDAO.getPatientLastName(patientLastNameSearch.getCeID(), patientLastNameSearch.getLastName()));
			result = new Result(patientMRNDTOs);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting all patient Last Name");
		} catch (Exception e) {
			log.error("Error in patient Last Name :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	
	@Override
	public Result getRxDetails(GetRxNumberDetailsSearch getRxNumberDetailsSearch) {
		Result result = null;
		try {
			GetRxNumberDetailsDTO getRxNumberDetailsDTO = new GetRxNumberDetailsDTO();
			List<RxNumberTimelineData> resultTimeLine = new ArrayList<>();
			GetRxNumberDetails getRxNumberDetails = getRxNumberDetailsDAO.getRxNumberDetails(getRxNumberDetailsSearch.getRxNumber(),
					getRxNumberDetailsSearch.getClaimId(), getRxNumberDetailsSearch.getCeId());
			if( getRxNumberDetails != null) {
				getRxNumberDetailsDTO = MAPPER.fromRxNumberDetails(getRxNumberDetails);
			}
			getRxNumberDetailsDTO.setTimelineData(createTimeLineData(getRxNumberDetailsDTO,resultTimeLine));	
			getRxNumberDetailsDTO.setAuditHistory(getAuditHistoryDTO(getRxNumberDetailsSearch.getClaimId(), getRxNumberDetailsSearch.getRxNumber()) );
			getRxNumberDetailsDTO.setClaimHistory(getClaimHistoryDTO(getRxNumberDetailsSearch.getClaimId(), getRxNumberDetailsSearch.getRxNumber() ));
			getRxNumberDetailsDTO.setEligibility(getEligibility(getRxNumberDetailsSearch.getClaimId(), getRxNumberDetailsSearch.getRxNumber()));
			getRxNumberDetailsDTO.setVisitHistory(getVisitHistory( getRxNumberDetailsSearch.getClaimId(), getRxNumberDetailsSearch.getRxNumber()  ));
			if(getRxNumberDetailsDTO.getTimelineData().size() != 0   ) {
				getRxNumberDetailsDTO.getTimelineData().sort((o1, o2) -> o1.getDate().compareTo(o2.getDate()));
			}
			result = new Result(getRxNumberDetailsDTO);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting all RxNumber Details");
		}catch (Exception e) {
			log.error("Error in getRxDetails :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}
	
	private List<VwRxNumDetailsAuditHistoryDTO> getAuditHistoryDTO(Long claimId, String rxNumber){
		try {
			List<VwRxNumDetailsAuditHistory> resultEntity = vwRxNumDetailsAuditHistoryDAO.findAllByClaimIdAndRxNumber(claimId, rxNumber);
			return MAPPER.fromAuditHistory(resultEntity);
		}catch (Exception e) {
			log.error("Error in getAuditHistoryDTO :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	private List<VwRxNumDetailsClaimHistoryDTO> getClaimHistoryDTO(Long claimId, String rxNumber){
		try {
			List<VwRxNumDetailsClaimHistory> resultEntity = vwRxNumDetailsClaimHistoryDAO.findAllByClaimIdAndRxNumber(claimId, rxNumber);
			return MAPPER.fromClaimHistory(resultEntity);
		}catch (Exception e) {
			log.error("Error in getAuditHistoryDTO :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	private List<VwRxNumDetailsEligibilityDTO> getEligibility(Long claimId, String rxNumber){
		try {
			List<VwRxNumDetailsEligibility> resultEntity = vwRxNumDetailsEligibilityDAO.findAllByClaimIdAndRxNumber(claimId, rxNumber);
			return MAPPER.fromEligibility(resultEntity);
		}catch (Exception e) {
			log.error("Error in getAuditHistoryDTO :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	private VwRxNumDetailsVisitHistoryDTO getVisitHistory(Long claimId, String rxNumber){
		try {
			VwRxNumDetailsVisitHistory resultEntity = vwRxNumDetailsVisitHistoryDAO.findAllByClaimIdAndRxNumber(claimId, rxNumber);
			return MAPPER.fromVisitHistory(resultEntity);
		}catch (Exception e) {
			log.error("Error in getAuditHistoryDTO :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	private List<RxNumberTimelineData> createTimeLineData(GetRxNumberDetailsDTO getRxNumberDetails,List<RxNumberTimelineData> resultTimeLine){
		Gson gson = new Gson();
		final JsonObject jsonObject = gson.toJsonTree(getRxNumberDetails).getAsJsonObject();
		for(Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
		    if(entry.getKey().equalsIgnoreCase("RxDateWritten") &&  entry.getValue() != null) {
		    	if(resultTimeLine == null ||  resultTimeLine.size() ==0 ) {
		    		List<String> fieldValues = new ArrayList<>();
					fieldValues.add(Constant.RX_WRITTEN);
					resultTimeLine.add(addRxNumberTimeline(getRxNumberDetails.getRxDateWritten(),fieldValues));
		    	}else {
		    		int index = findIndexinList(resultTimeLine,getRxNumberDetails.getRxDateWritten());
		    		if(index != -1) {
		    			resultTimeLine.add(index,appendRxTimeLineData(resultTimeLine,index,Constant.RX_WRITTEN)); 
		    		}else {
		    			List<String> fieldValues = new ArrayList<>();
						fieldValues.add(Constant.RX_WRITTEN);
						resultTimeLine.add(addRxNumberTimeline(getRxNumberDetails.getRxDateWritten(),fieldValues));
		    		}
		    	}
		    } if(entry.getKey().equalsIgnoreCase("DataFilled") &&  entry.getValue() != null) {
		    	if(resultTimeLine == null ||  resultTimeLine.size() ==0 ) {
		    		List<String> fieldValues = new ArrayList<>();
					fieldValues.add(Constant.RX_FILLED);
					resultTimeLine.add(addRxNumberTimeline(getRxNumberDetails.getDataFilled(),fieldValues));
		    	}else {
		    		int index = findIndexinList(resultTimeLine,getRxNumberDetails.getDataFilled());
		    		if(index != -1) {
		    			resultTimeLine.add(index,appendRxTimeLineData(resultTimeLine,index,Constant.RX_FILLED)); 
		    		}else {
		    			List<String> fieldValues = new ArrayList<>();
						fieldValues.add(Constant.RX_FILLED);
						resultTimeLine.add(addRxNumberTimeline(getRxNumberDetails.getDataFilled(),fieldValues));
		    		}
		    	}
		    } if(entry.getKey().equalsIgnoreCase("PODate") &&  entry.getValue() != null) {
		    	if(resultTimeLine == null ||  resultTimeLine.size() ==0 ) {
		    		List<String> fieldValues = new ArrayList<>();
					fieldValues.add(Constant.PURCHASE_ORDER);
					resultTimeLine.add(addRxNumberTimeline(getRxNumberDetails.getPODate(),fieldValues));
		    	}else {
		    		int index = findIndexinList(resultTimeLine,getRxNumberDetails.getPODate());
		    		if(index != -1) {
		    			resultTimeLine.add(index,appendRxTimeLineData(resultTimeLine,index,Constant.PURCHASE_ORDER)); 
		    		}else {
		    			List<String> fieldValues = new ArrayList<>();
						fieldValues.add(Constant.PURCHASE_ORDER);
						resultTimeLine.add(addRxNumberTimeline(getRxNumberDetails.getPODate(),fieldValues));
		    		}
		    	}
		    } if(entry.getKey().equalsIgnoreCase("InvoiceDate") &&  entry.getValue() != null) {
		    	if(resultTimeLine == null ||  resultTimeLine.size() ==0 ) {
		    		List<String> fieldValues = new ArrayList<>();
					fieldValues.add(Constant.INVOICES);
					resultTimeLine.add(addRxNumberTimeline(getRxNumberDetails.getInvoiceDate(),fieldValues));
		    	}else {
		    		int index = findIndexinList(resultTimeLine,getRxNumberDetails.getInvoiceDate());
		    		if(index != -1) {
		    			resultTimeLine.add(index,appendRxTimeLineData(resultTimeLine,index,Constant.INVOICES)); 
		    		}else {
		    			List<String> fieldValues = new ArrayList<>();
						fieldValues.add(Constant.INVOICES);
						resultTimeLine.add(addRxNumberTimeline(getRxNumberDetails.getInvoiceDate(),fieldValues));
		    		}
		    	}
		    }if(entry.getKey().equalsIgnoreCase("VisitDate") &&  entry.getValue() != null) {
		    	if(resultTimeLine == null ||  resultTimeLine.size() ==0 ) {
		    		List<String> fieldValues = new ArrayList<>();
					fieldValues.add(Constant.VISIT);
					resultTimeLine.add(addRxNumberTimeline(getRxNumberDetails.getVisitDate(),fieldValues));
		    	}else {
		    		int index = findIndexinList(resultTimeLine,getRxNumberDetails.getVisitDate());
		    		if(index != -1) {
		    			resultTimeLine.add(index,appendRxTimeLineData(resultTimeLine,index,Constant.VISIT)); 
		    		}else {
		    			List<String> fieldValues = new ArrayList<>();
						fieldValues.add(Constant.VISIT);
						resultTimeLine.add(addRxNumberTimeline(getRxNumberDetails.getVisitDate(),fieldValues));
		    		}
		    	}
		    }
		}
	 return removeRedundentData(resultTimeLine);
	}

	
	private RxNumberTimelineData addRxNumberTimeline(String Date,List<String> fieldValues) {
		RxNumberTimelineData rxNumberTimelineData = new RxNumberTimelineData();
		rxNumberTimelineData.setDate(Date);
		rxNumberTimelineData.setFields(fieldValues);
		return rxNumberTimelineData;
		
	}
	private int findIndexinList(List<RxNumberTimelineData> resultTimeLine,String value) {
		int index = IntStream.range(0, resultTimeLine.size())
			     .filter(i -> resultTimeLine.get(i).getDate().equals(value))
			     .findFirst()
			     .orElse(-1);
		return index;
	}
	
	private RxNumberTimelineData appendRxTimeLineData(List<RxNumberTimelineData> resultTimeLine,int index,String fieldValue) {
		RxNumberTimelineData rxNumberTimelineData = new RxNumberTimelineData();
			rxNumberTimelineData = resultTimeLine.get(index);
			rxNumberTimelineData.getFields().add(fieldValue);
			return rxNumberTimelineData;
	}
	private List<RxNumberTimelineData> removeRedundentData( List<RxNumberTimelineData> resultTimeLine  ) {
		resultTimeLine.forEach(res->{
			Set<String> fieldNames = new HashSet<String>(res.getFields());
			List<String> fieldList = new ArrayList<String>(fieldNames);
			res.setFields(fieldList);
		});
		Set<RxNumberTimelineData> resultSet = new HashSet<RxNumberTimelineData>(resultTimeLine);
		List<RxNumberTimelineData> resultList = new ArrayList<RxNumberTimelineData>(resultSet);
		return resultList;
	}
	
}
