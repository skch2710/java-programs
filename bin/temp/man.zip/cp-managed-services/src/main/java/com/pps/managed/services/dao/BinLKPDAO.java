package com.pps.managed.services.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pps.managed.services.model.BinLKP;

public interface BinLKPDAO extends JpaRepository<BinLKP, Long> {

}
