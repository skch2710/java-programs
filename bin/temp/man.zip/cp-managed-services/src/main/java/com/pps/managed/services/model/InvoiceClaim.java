package com.pps.managed.services.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class InvoiceClaim {

	@Id
	@Column(name = "id")
	private Long id;

	@Column(name = "AdminName")
	private String adminName;

	@Column(name = "CEName")
	private String ceName;

	@Column(name = "AdminHRSAID")
	private String hrsaID;

	@Column(name = "CEReimbursementModel")
	private String ceReimbursementModel;

	@Column(name = "CEReplenishmentModel")
	private String ceReplenishmentModel;

	@Column(name = "PharmacyGroup")
	private String pharmacyGroup;

	@Column(name = "PharmacyStoreName")
	private String pharmacyStoreName;

	@Column(name = "PharmacyNPI")
	private String pharmacyNPI;

	@Column(name = "PhysicianFirstName")
	private String physicianFirstName;

	@Column(name = "PhysicianLastName")
	private String physicianLastName;

	@Column(name = "PrescriberId")
	private Long prescriberId;

	@Column(name = "ReplenishmentType")
	private String replenishmentType;

	@Column(name = "ClaimID")
	private Long claimID;

	@Column(name = "RefillCode")
	private String refillCode;

	@Column(name = "RxNumber")
	private String rxNumber;

	@Column(name = "PgmDateRxWritten")
	private Date pgmDateRxWritten;

	@Column(name = "ProcessedDate")
	private Date processedDate;

	@Column(name = "DateOfService")
	private Date dateOfService;

	@Column(name = "DateReversed")
	private Date dateReversed;

	@Column(name = "ClaimStatusCode")
	private Long claimStatusCode;

	@Column(name = "ClaimType")
	private String claimType;

	@Column(name = "BIN")
	private String bin;

	@Column(name = "PCN")
	private String pcn;

	@Column(name = "GroupNumber")
	private String groupNumber;

	@Column(name = "NDC")
	private String ndc;

	@Column(name = "DrugName")
	private String drugName;

	@Column(name = "BOrGIndicator")
	private String BOrGIndicator;

	@Column(name = "QtyDisp")
	private BigDecimal qtyDisp;

	@Column(name = "ReplenishedQty")
	private Long replenishedQty;

	@Column(name = "ReplenishmentPercentage")
	private Long replenishmentPercentage;

	@Column(name = "PatientPay")
	private BigDecimal patientPay;

	@Column(name = "ThirdPartyPayment")
	private BigDecimal thirdPartyPayment;

	@Column(name = "CEPlanSubsidy")
	private BigDecimal cePlanSubsidy;

	@Column(name = "TotalCollected")
	private BigDecimal totalCollected;

	@Column(name = "EstimatedAcquisitionCost")
	private BigDecimal estimatedAcquisitionCost;

	@Column(name = "340BIngredientCost")
	private BigDecimal tfbIngredientCost;

	@Column(name = "ActualIngredientCost")
	private BigDecimal actualIngredientCost;

	@Column(name = "TotalInvoiced")
	private BigDecimal totalInvoiced;

	@Column(name = "DispensingFee")
	private String dispensingFee;

	@Column(name = "GrossSavings")
	private BigDecimal grossSavings;

	@Column(name = "340BDirectplusFlatFee")
	private BigDecimal tfbDirectplusFlatFee;

	@Column(name = "340BDirectVariableTransactionFee")
	private BigDecimal tfbDirectVariableTransactionFee;

	@Column(name = "Total340BDirectplusFee")
	private BigDecimal total340BDirectplusFee;

	@Column(name = "TotalCEReceivable")
	private BigDecimal totalCEReceivable;

	@Column(name = "810DebitInvoice#")
	private String eightTenDebitInvoice;

	@Column(name = "InvoiceDate")
	private Date invoiceDate;

	@Column(name = "810CreditInvoice#")
	private String eightTenCreditInvoice;

	@Column(name = "CreditInvoiceDate")
	private Date creditInvoiceDate;

	@Column(name = "totalRows")
	private Long totalRows;
}
