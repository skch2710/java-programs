package com.pps.managed.services.service;

import com.pps.managed.services.dto.CERemittanceTotalsSearch;
import com.pps.managed.services.dto.InvoiceClaimSearch;
import com.pps.managed.services.dto.InvoiceRemittanceSearch;
import com.pps.managed.services.dto.InvoiceReportSearch;
import com.pps.managed.services.dto.InvoiceSearch;
import com.pps.managed.services.dto.InvoiceTrueUpSearch;
import com.pps.managed.services.dto.Result;

public interface InvoiceService {

	Result getPharmacyInvoiceDetails(InvoiceReportSearch invoiceReportSearch);

	Result getTrueUpReportPopupDetails(InvoiceReportSearch invoiceReportSearch);

	Result getTFBDirectPlusFeesReport(InvoiceReportSearch invoiceReportSearch);

	Result searchInvoicesMainGrid(InvoiceSearch invoiceSearch);

	Result searchPharmacyInvoiceDetails(InvoiceSearch invoiceSearch);

	Result searchPharmacyGroupInvoicedetails(InvoiceSearch invoiceSearch);

	Result invoiceClaim(InvoiceClaimSearch invoiceClaimSearch);

	Result searchInvoiceRemittancedetails(InvoiceRemittanceSearch invoiceRemittanceSearch);

	Result searchInvoiceTrueUp(InvoiceTrueUpSearch invoiceTrueUpSearch);
	

	Result searchCERemittanceTotalsdetails(CERemittanceTotalsSearch ceRemittanceTotalsSearch);

}
