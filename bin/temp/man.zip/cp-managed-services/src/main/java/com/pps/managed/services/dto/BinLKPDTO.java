package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BinLKPDTO {

	private Long binID;
	private String binNumber;
	private String binName;
	private String inactiveFlag;
	private String createdByID;
	private String createdDate;
	private Long modifiedByID;
	private String modifiedDate;
}
