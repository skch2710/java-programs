package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class PurchaseOrderStatusDTO {

	private Long poStatusID;
	private String poStatusCode;
	private String poStatus;
	private String inactiveFlag;
	private Long createdByID;
	private String createdDate;
	private Long modifiedByID;
	private String modifiedDate;
}
