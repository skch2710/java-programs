package com.pps.managed.services.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.pps.managed.services.dto.BinLKPDTO;
import com.pps.managed.services.dto.CERemittanceTotalsDTO;
import com.pps.managed.services.dto.ClaimDispenseInnerGridDTO;
import com.pps.managed.services.dto.ClaimTypeLKPDTO;
import com.pps.managed.services.dto.ClaimsManagementDTO;
import com.pps.managed.services.dto.ClaimsstatuslkpDTO;
import com.pps.managed.services.dto.FalloutReasonLkpDTO;
import com.pps.managed.services.dto.GetRxNumberDetailsDTO;
import com.pps.managed.services.dto.InventoryDTO;
import com.pps.managed.services.dto.InventoryInnerGridDTO;
import com.pps.managed.services.dto.InvoiceClaimDTO;
import com.pps.managed.services.dto.InvoiceRemittanceDTO;
import com.pps.managed.services.dto.InvoiceTrueUpDTO;
import com.pps.managed.services.dto.InvoicesMainGridDTO;
import com.pps.managed.services.dto.PatientMRNDTO;
import com.pps.managed.services.dto.PhInvoiceReportDTO;
import com.pps.managed.services.dto.PharmacyGroupInvoiceDetailsDTO;
import com.pps.managed.services.dto.PharmacyInvoiceDetailsDTO;
import com.pps.managed.services.dto.PurchaseOrderCategorylkpDTO;
import com.pps.managed.services.dto.PurchaseOrderDTO;
import com.pps.managed.services.dto.PurchaseOrderHistoryDTO;
import com.pps.managed.services.dto.PurchaseOrderPXClaimDTO;
import com.pps.managed.services.dto.PurchaseOrderStatusDTO;
import com.pps.managed.services.dto.PurchaseOrdersInnerGridDTO;
import com.pps.managed.services.dto.PurchaseOrdersItemHistoryDTO;
import com.pps.managed.services.dto.TFBDirectPlusFeesReportDTO;
import com.pps.managed.services.dto.TrueUpReportPopupDTO;
import com.pps.managed.services.dto.VwRxNumDetailsAuditHistoryDTO;
import com.pps.managed.services.dto.VwRxNumDetailsClaimHistoryDTO;
import com.pps.managed.services.dto.VwRxNumDetailsEligibilityDTO;
import com.pps.managed.services.dto.VwRxNumDetailsVisitHistoryDTO;
import com.pps.managed.services.model.BinLKP;
import com.pps.managed.services.model.CERemittanceTotals;
import com.pps.managed.services.model.ClaimDispense;
import com.pps.managed.services.model.ClaimTypeLKP;
import com.pps.managed.services.model.ClaimsManagement;
import com.pps.managed.services.model.Claimsstatuslkp;
import com.pps.managed.services.model.FalloutReasonLkp;
import com.pps.managed.services.model.GetRxNumberDetails;
import com.pps.managed.services.model.Inventory;
import com.pps.managed.services.model.InventoryInnerGrid;
import com.pps.managed.services.model.InvoiceClaim;
import com.pps.managed.services.model.InvoiceRemittance;
import com.pps.managed.services.model.InvoiceTrueUp;
import com.pps.managed.services.model.InvoicesMainGrid;
import com.pps.managed.services.model.PatientMRNLKP;
import com.pps.managed.services.model.PhInvoiceReport;
import com.pps.managed.services.model.PharmacyGroupInvoiceDetails;
import com.pps.managed.services.model.PharmacyInvoiceDetails;
import com.pps.managed.services.model.PurchaseOrder;
import com.pps.managed.services.model.PurchaseOrderCategorylkp;
import com.pps.managed.services.model.PurchaseOrderHistory;
import com.pps.managed.services.model.PurchaseOrderPxClaim;
import com.pps.managed.services.model.PurchaseOrderStatusLKP;
import com.pps.managed.services.model.PurchaseOrdersInnerGrid;
import com.pps.managed.services.model.PurchaseOrdersItemHistory;
import com.pps.managed.services.model.TFBDirectPlusFeesReport;
import com.pps.managed.services.model.TrueUpReportPopup;
import com.pps.managed.services.model.VwRxNumDetailsAuditHistory;
import com.pps.managed.services.model.VwRxNumDetailsClaimHistory;
import com.pps.managed.services.model.VwRxNumDetailsEligibility;
import com.pps.managed.services.model.VwRxNumDetailsVisitHistory;


@Mapper(config = IgnoreUnMapperConfig.class)
public interface ObjectMapper {

	ObjectMapper INSTANCE = Mappers.getMapper(ObjectMapper.class);

	@Mapping(source = "three40BInventoryCost", target = "three40BInventoryCost", numberFormat = "$#,##0.00")
	@Mapping(source = "packageSize", target = "packageSize", numberFormat = "#,##0.00")
	InventoryDTO fromInventoryModel(Inventory inventory);

	List<InventoryDTO> fromInventoryModel(List<Inventory> inventory);

	@Mapping(source = "dispensedDate", target = "dispensedDate", dateFormat = "MM/dd/yyyy")
	ClaimDispenseInnerGridDTO fromClaimDispenseInnerGridModel(ClaimDispense claimDispense);

	List<ClaimDispenseInnerGridDTO> fromClaimDispenseInnerGridModel(List<ClaimDispense> claimDispense);

		
		
		@Mapping(source = "itemOrderedDate", target = "itemOrderedDate", dateFormat = "MM/dd/yyyy")
		@Mapping(source = "itemAcknowledgedDate", target = "itemAcknowledgedDate", dateFormat = "MM/dd/yyyy")
		@Mapping(source = "itemInvoicedDate", target = "itemInvoicedDate", dateFormat = "MM/dd/yyyy")
		@Mapping(source = "itemReconciledDate", target = "itemReconciledDate", dateFormat = "MM/dd/yyyy")
		@Mapping(source = "createdDate", target = "createdDate", dateFormat = "MM/dd/yyyy")
		PurchaseOrdersItemHistoryDTO fromPurchaseOrdersItemHistoryModel(
				PurchaseOrdersItemHistory purchaseOrdersItemHistory);

		List<PurchaseOrdersItemHistoryDTO> fromPurchaseOrdersItemHistoryModel(
				List<PurchaseOrdersItemHistory> purchaseOrdersItemHistoryList);
	PurchaseOrderStatusDTO fromPurchaseOrderStatusModel(PurchaseOrderStatusLKP purchaseOrderStatus);

	List<PurchaseOrderStatusDTO> fromPurchaseOrderStatusModel(List<PurchaseOrderStatusLKP> purchaseOrderStatus);

	List<ClaimTypeLKPDTO> fromClaimTypeLKPModel(List<ClaimTypeLKP> claimTypeLKP);

	List<BinLKPDTO> fromBINModel(List<BinLKP> binLKP);

	List<FalloutReasonLkpDTO> fromFalloutReasonModel(List<FalloutReasonLkp> falloutReasonLkp);

	List<ClaimsstatuslkpDTO> fromClaimsstatuslkp(List<Claimsstatuslkp> claimsstatuslkps);

	@Mapping(source = "actionDate", target = "actionDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "capturedDate", target = "capturedDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "dispensedQty", target = "dispensedQty", numberFormat = "0")
	@Mapping(source = "replenishedQty", target = "replenishedQty", numberFormat = "0")
	@Mapping(source = "returnedQty", target = "returnedQty", numberFormat = "0")
	@Mapping(source = "trueUpQty", target = "trueUpQty", numberFormat = "0")
	@Mapping(source = "totalPrice", target = "totalPrice", numberFormat = "$#,##0.00")
	InventoryInnerGridDTO fromInventoryInnerGridModel(InventoryInnerGrid inventoryInnerGrid);
	List<InventoryInnerGridDTO> fromInventoryInnerGridModel(List<InventoryInnerGrid> inventoryInnerGrid);

	List<PurchaseOrderCategorylkpDTO> frompurchasecategory(List<PurchaseOrderCategorylkp> purchaseOrderCategorylkps);

	@Mapping(source = "poDate", target = "poDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "dateOfService", target = "dateOfService", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "invoiceDate340BDirect", target = "invoiceDate340BDirect", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "itemInvoicedDate", target = "itemInvoicedDate", dateFormat = "MM/dd/yyyy")
	PurchaseOrderPXClaimDTO fromPurchaseOrderPXClaimModel(PurchaseOrderPxClaim purchaseOrderPxClaim);

	List<PurchaseOrderPXClaimDTO> fromPurchaseOrderPXClaimModel(List<PurchaseOrderPxClaim> purchaseOrderPxClaims);

	
	@Mapping(source = "totalOrderAmount", target = "totalOrderAmount", numberFormat = "$#,##0.00")
	@Mapping(source = "totalBilledAmount", target = "totalBilledAmount", numberFormat = "$#,##0.00")
	@Mapping(source = "poDate", target = "poDate", dateFormat = "MM/dd/yyyy")
	PurchaseOrderDTO fromPurchaseOrderModel(PurchaseOrder purchaseOrder);

	List<PurchaseOrderDTO> fromPurchaseOrderModel(List<PurchaseOrder> purchaseOrder);
	
	
	
	@Mapping(source = "dos", target = "dos", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "claimCaptured", target = "claimCaptured", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "patientDOB", target = "patientDOB", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "actionDate", target = "actionDate", dateFormat = "MM/dd/yyyy")
    @Mapping(source = "savingsMin", target = "savingsMin", numberFormat = "$#,##0.00")
    @Mapping(source = "savingsMax", target = "savingsMax", numberFormat = "$#,##0.00")
	@Mapping(source = "processedDate", target = "processedDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "rxWrittenDate", target = "rxWrittenDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "dateofService", target = "dateofService", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "ceSavings", target = "ceSavings", numberFormat = "$#,##0.00")
	@Mapping(source = "totalPayment", target = "totalPayment", numberFormat = "$#,##0.00")
	@Mapping(source = "grossDispensingFee", target = "grossDispensingFee", numberFormat = "$#,##0.00")
	@Mapping(source = "tfBIngredientCost", target = "tfBIngredientCost", numberFormat = "$#,##0.00")
	@Mapping(source = "totalCEReceivable", target = "totalCEReceivable", numberFormat = "$#,##0.00")
	@Mapping(source = "claimProfitLoss", target = "claimProfitLoss", numberFormat = "$#,##0.00")
	ClaimsManagementDTO fromClaimsManagementModel(ClaimsManagement claimsManagement);

	List<ClaimsManagementDTO> fromClaimsManagementModel(List<ClaimsManagement> claimsManagement);

	List<PatientMRNDTO> fromPatientMRNModel(List<PatientMRNLKP> patientMRNLKP);
	

	@Mapping(source = "orderedPackageCost", target = "orderedPackageCost", numberFormat = "$#,##0.00")
	@Mapping(source = "acknowledgedPackageCost", target = "acknowledgedPackageCost", numberFormat = "$#,##0.00")
	@Mapping(source = "invoicedPackageCost", target = "invoicedPackageCost", numberFormat = "$#,##0.00")
	PurchaseOrdersInnerGridDTO fromPurchaseOrdersInnerGridModel(PurchaseOrdersInnerGrid purchaseOrdersInnerGrid);

	List<PurchaseOrdersInnerGridDTO> fromPurchaseOrdersInnerGridModel(
			List<PurchaseOrdersInnerGrid> purchaseOrdersInnerGrid);

	@Mapping(source = "processedDate", target = "processedDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "rxWrittenDate", target = "rxWrittenDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "dateOfService", target = "dateOfService", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "memberDateOfBirth", target = "memberDateOfBirth", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "startDate", target = "startDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "endDate", target = "endDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "patientVisitDate", target = "patientVisitDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "billingPeriod", target = "billingPeriod", dateFormat = "MM/dd/yyyy")
	PhInvoiceReportDTO fromPhInvoiceReportModel(PhInvoiceReport phInvoiceReport);

	List<PhInvoiceReportDTO> fromPhInvoiceReportModel(List<PhInvoiceReport> phInvoiceReport);

	@Mapping(source = "rxDateWritten", target = "rxDateWritten", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "dataFilled", target = "dataFilled", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "visitDate", target = "visitDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "PODate", target = "PODate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "invoiceDate", target = "invoiceDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "actionDate", target = "actionDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "savings", target = "savings", numberFormat = "$#,##0.00")
	@Mapping(source = "drugCost", target = "drugCost", numberFormat = "$#,##0.00")
	@Mapping(source = "dispensingFee", target = "dispensingFee", numberFormat = "$#,##0.00")
	@Mapping(source = "adminFee", target = "adminFee", numberFormat = "$#,##0.00")
	GetRxNumberDetailsDTO fromRxNumberDetails( GetRxNumberDetails  getRxNumberDetails);
	
	List<GetRxNumberDetailsDTO> fromRxNumberDetails(  List<GetRxNumberDetails> getRxNumberDetails);
	

	
	  @Mapping(source = "poDate", target = "poDate", dateFormat = "MM/dd/yyyy")
	  @Mapping(source = "poStatusDate", target = "poStatusDate", dateFormat = "MM/dd/yyyy")
	  @Mapping(source = "createdDate", target = "createdDate", dateFormat = "MM/dd/yyyy")
	  PurchaseOrderHistoryDTO fromPurchaseOrderHistoryModel(PurchaseOrderHistory purchaseOrderHistory);
	  List<PurchaseOrderHistoryDTO> fromPurchaseOrderHistoryModel(List<PurchaseOrderHistory> purchaseOrderHistories);

	@Mapping(source = "billingPeriod", target = "billingPeriod", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "processedDate", target = "processedDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "rxWrittenDate", target = "rxWrittenDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "dateOfService", target = "dateOfService", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "patientVisitDate", target = "patientVisitDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "memberDateOfBirth", target = "memberDateOfBirth", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "startDate", target = "startDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "endDate", target = "endDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "trueUpDate", target = "trueUpDate", dateFormat = "MM/dd/yyyy")
	TrueUpReportPopupDTO fromTrueUpReportingModel(TrueUpReportPopup trueUpReportPopup);
	List<TrueUpReportPopupDTO> fromTrueUpReportingModel(List<TrueUpReportPopup> trueUpReportPopup);

	@Mapping(source = "billingPeriod", target = "billingPeriod", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "dueDate", target = "dueDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "tfbDirectPlusFees", target = "tfbDirectPlusFees", numberFormat = "$#,##0.00")
	TFBDirectPlusFeesReportDTO fromTFBDirectPlusFeesReportModel(TFBDirectPlusFeesReport tFBDirectPlusFeesReport);
	List<TFBDirectPlusFeesReportDTO> fromTFBDirectPlusFeesReportModel(List<TFBDirectPlusFeesReport> tFBDirectPlusFeesReport);
	
	@Mapping(source = "invoicePeriodStartDate", target = "invoicePeriodStartDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "invoicePeriodEndDate", target = "invoicePeriodEndDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "billingPeriod", target = "billingPeriod", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "totalInvoiced", target = "totalInvoiced", numberFormat = "$#,##0.00")
	@Mapping(source = "dispensingFee", target = "dispensingFee", numberFormat = "$#,##0.00")
	@Mapping(source = "trueUp", target = "trueUp", numberFormat = "$#,##0.00")
	@Mapping(source = "storeFees", target = "storeFees", numberFormat = "$#,##0.00")
	@Mapping(source = "ceTotalReceivedAmount", target = "ceTotalReceivedAmount", numberFormat = "$#,##0.00")
	@Mapping(source = "direct340BTrxnFee", target = "direct340BTrxnFee", numberFormat = "$#,##0.00")
	InvoicesMainGridDTO fromInvoiceMainGridModel(InvoicesMainGrid invoiceMainGrid);
	List<InvoicesMainGridDTO> fromInvoiceMainGridModel(List<InvoicesMainGrid> invoiceMainGrid);

	@Mapping(source = "billingPeriod", target = "billingPeriod", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "invoicePeriodStartDate", target = "invoicePeriodStartDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "invoicePeriodEndDate", target = "invoicePeriodEndDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "totalInvoiced", target = "totalInvoiced", numberFormat = "$#,##0.00")
	@Mapping(source = "dispensingFee", target = "dispensingFee", numberFormat = "$#,##0.00")
	@Mapping(source = "trueUp", target = "trueUp", numberFormat = "$#,##0.00")
	@Mapping(source = "storeFees", target = "storeFees", numberFormat = "$#,##0.00")
	@Mapping(source = "ceTotalReceivedAmount", target = "ceTotalReceivedAmount", numberFormat = "$#,##0.00")
	@Mapping(source = "direct340BTrxnFee", target = "direct340BTrxnFee", numberFormat = "$#,##0.00")
	@Mapping(source = "estimatedCeSavings", target = "estimatedCeSavings", numberFormat = "$#,##0.00")
	@Mapping(source = "pharmacyPaymentReceived", target = "pharmacyPaymentReceived", numberFormat = "$#,##0.00")
	@Mapping(source = "tfbDirectPlusRemittance", target = "tfbDirectPlusRemittance", numberFormat = "$#,##0.00")
	PharmacyInvoiceDetailsDTO fromPharmacyInvoiceDetailsModel(PharmacyInvoiceDetails pharmacyInvoiceDetail);
	List<PharmacyInvoiceDetailsDTO> fromPharmacyInvoiceDetailsModel(List<PharmacyInvoiceDetails> pharmacyInvoiceDetails);
	
	@Mapping(source = "billingPeriod", target = "billingPeriod", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "invoicePeriodStartDate", target = "invoicePeriodStartDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "invoicePeriodEndDate", target = "invoicePeriodEndDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "totalInvoiced", target = "totalInvoiced", numberFormat = "$#,##0.00")
	@Mapping(source = "dispensingFee", target = "dispensingFee", numberFormat = "$#,##0.00")
	@Mapping(source = "trueUp", target = "trueUp", numberFormat = "$#,##0.00")
	@Mapping(source = "storeFees", target = "storeFees", numberFormat = "$#,##0.00")
	@Mapping(source = "ceTotalReceivedAmount", target = "ceTotalReceivedAmount", numberFormat = "$#,##0.00")
	@Mapping(source = "direct340BTrxnFee", target = "direct340BTrxnFee", numberFormat = "$#,##0.00")
	PharmacyGroupInvoiceDetailsDTO fromInvoiceInnerGridmodel(PharmacyGroupInvoiceDetails pharmacyGroupDetails);
	List<PharmacyGroupInvoiceDetailsDTO> fromInvoiceInnerGridmodel(List<PharmacyGroupInvoiceDetails> pharmacyGroupDetails);
	
	@Mapping(source = "auditedDate", target = "auditedDate", dateFormat = "MM/dd/yyyy HH:MM a")
	VwRxNumDetailsAuditHistoryDTO fromAuditHistory(VwRxNumDetailsAuditHistory vwRxNumDetailsAuditHistoryDTO );
	List<VwRxNumDetailsAuditHistoryDTO> fromAuditHistory(List<VwRxNumDetailsAuditHistory> vwRxNumDetailsAuditHistoryDTO );
	
	@Mapping(source = "refillDate", target = "refillDate", dateFormat = "MM/dd/yyyy")
	VwRxNumDetailsClaimHistoryDTO fromClaimHistory( VwRxNumDetailsClaimHistory vwRxNumDetailsClaimHistory);
	List<VwRxNumDetailsClaimHistoryDTO> fromClaimHistory( List<VwRxNumDetailsClaimHistory> vwRxNumDetailsClaimHistory);
	
	VwRxNumDetailsEligibilityDTO fromEligibility(VwRxNumDetailsEligibility vwRxNumDetailsEligibility);
	List<VwRxNumDetailsEligibilityDTO> fromEligibility(List<VwRxNumDetailsEligibility> vwRxNumDetailsEligibility);
	
	@Mapping(source = "visitDate", target = "visitDate", dateFormat = "MM/dd/yyyy")
	VwRxNumDetailsVisitHistoryDTO fromVisitHistory(VwRxNumDetailsVisitHistory vwRxNumDetailsEligibility);
	List<VwRxNumDetailsVisitHistoryDTO> fromVisitHistory(List<VwRxNumDetailsVisitHistory> vwRxNumDetailsEligibility);
	
	
	@Mapping(source = "pgmDateRxWritten", target = "pgmDateRxWritten", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "processedDate", target = "processedDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "dateOfService", target = "dateOfService", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "dateReversed", target = "dateReversed", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "invoiceDate", target = "invoiceDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "creditInvoiceDate", target = "creditInvoiceDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "patientPay", target = "patientPay", numberFormat = "$#,##0.00")
	@Mapping(source = "thirdPartyPayment", target = "thirdPartyPayment", numberFormat = "$#,##0.00")
	@Mapping(source = "cePlanSubsidy", target = "cePlanSubsidy", numberFormat = "$#,##0.00")
	@Mapping(source = "totalCollected", target = "totalCollected", numberFormat = "$#,##0.00")
	@Mapping(source = "estimatedAcquisitionCost", target = "estimatedAcquisitionCost", numberFormat = "$#,##0.00")
	@Mapping(source = "tfbIngredientCost", target = "tfbIngredientCost", numberFormat = "$#,##0.00")
	@Mapping(source = "actualIngredientCost", target = "actualIngredientCost", numberFormat = "$#,##0.00")
	@Mapping(source = "totalInvoiced", target = "totalInvoiced", numberFormat = "$#,##0.00")
	@Mapping(source = "dispensingFee", target = "dispensingFee", numberFormat = "$#,##0.00")
	@Mapping(source = "grossSavings", target = "grossSavings", numberFormat = "$#,##0.00")
	@Mapping(source = "tfbDirectplusFlatFee", target = "tfbDirectplusFlatFee", numberFormat = "$#,##0.00")
	@Mapping(source = "tfbDirectVariableTransactionFee", target = "tfbDirectVariableTransactionFee", numberFormat = "$#,##0.00")
	@Mapping(source = "total340BDirectplusFee", target = "total340BDirectplusFee", numberFormat = "$#,##0.00")
	@Mapping(source = "totalCEReceivable", target = "totalCEReceivable", numberFormat = "$#,##0.00")
	InvoiceClaimDTO fromInvoiceClaimModel( InvoiceClaim invoiceClaim);
	List<InvoiceClaimDTO> fromInvoiceClaimModel( List<InvoiceClaim> invoiceClaim);
	
	@Mapping(source = "billingCycle", target = "billingCycle", dateFormat = "MM/dd/yyyy")
	InvoiceRemittanceDTO fromInvoiceRemittanceModel(InvoiceRemittance invoiceRemittance);
	List<InvoiceRemittanceDTO> fromInvoiceRemittanceModel(List<InvoiceRemittance> invoiceRemittance);
	
	@Mapping(source = "billingCycle", target = "billingCycle", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "processedDate", target = "processedDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "rxWrittenDate", target = "rxWrittenDate", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "dateOfService", target = "dateOfService", dateFormat = "MM/dd/yyyy")
	@Mapping(source = "trueUpAmount", target = "trueUpAmount", numberFormat = "$#,##0.00")
	@Mapping(source = "trueUpUnits", target = "trueUpUnits")
	InvoiceTrueUpDTO fromInvoiceTrueUpModel( InvoiceTrueUp invoiceTrueUp);
	List<InvoiceTrueUpDTO> fromInvoiceTrueUpModel( List<InvoiceTrueUp> invoiceTrueUp);

	@Mapping(source = "totalInvoiced", target = "totalInvoiced", numberFormat = "$#,##0.00")
	@Mapping(source = "dispensingFee", target = "dispensingFee", numberFormat = "$#,##0.00")
	@Mapping(source = "pharmacyConnectionFee", target = "pharmacyConnectionFee", numberFormat = "$#,##0.00")
	@Mapping(source = "trueUp", target = "trueUp", numberFormat = "$#,##0.00")
	@Mapping(source = "direct340BPlusFee", target = "direct340BPlusFee", numberFormat = "$#,##0.00")
	@Mapping(source = "direct340BPlusVariableTransactionFee", target = "direct340BPlusVariableTransactionFee", numberFormat = "$#,##0.00")
	@Mapping(source = "contractPharmacyMinorMax", target = "contractPharmacyMinorMax", numberFormat = "$#,##0.00")
	@Mapping(source = "ceTotalReceivedAmount", target = "ceTotalReceivedAmount", numberFormat = "$#,##0.00")
	@Mapping(source = "ceThresholdMinOrMax", target = "ceThresholdMinOrMax", numberFormat = "$#,##0.00")
	@Mapping(source = "netDuetoCoveredEntity", target = "netDuetoCoveredEntity", numberFormat = "$#,##0.00")
	CERemittanceTotalsDTO fromCERemittanceTotalsModel(CERemittanceTotals ceRemittanceTotals);
	List<CERemittanceTotalsDTO> fromCERemittanceTotalsModel(List<CERemittanceTotals> ceRemittanceTotals);

}
