package com.pps.managed.services.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "PurchaseOrder_Category", schema = "dbo")
public class PurchaseOrderCategorylkp {

	@Id
	@Column(name = "[POCategoryID]")
	private Long POCategoryID;

	@Column(name = "[POCategoryCode]")
	private String POCategoryCode;

	@Column(name = "[POCategory]")
	private String POCategory;

	@Column(name = "[InActiveFlag]")
	private String InActiveFlag;

	@Column(name = "[CreatedByID]")
	private String CreatedByID;

	@Column(name = "[CreatedDate]")
	private Date CreatedDate;

	@Column(name = "[ModifiedByID]")
	private Long ModifiedByID;

	@Column(name = "[ModifiedDate]")
	private Date ModifiedDate;
}
