package com.pps.managed.services.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pps.managed.services.model.PurchaseOrderCategorylkp;

public interface PurchaseOrderCategorylkpDAO extends JpaRepository<PurchaseOrderCategorylkp, Long> {

}
