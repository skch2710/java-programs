package com.pps.managed.services.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CERemittanceTotals {
	
	@Id
	@Column(name = "[Ceid]", nullable = false)
	private Long ceid;
	
	@Column(name = "[TotalInvoiced]", nullable = false)
	private BigDecimal totalInvoiced;
	
	@Column(name = "[DispensingFee]", nullable = false)
	private BigDecimal dispensingFee;
	
	@Column(name = "[PharmacyConnectionFee]", nullable = false)
	private BigDecimal pharmacyConnectionFee;
	
	@Column(name = "[TrueUp]", nullable = false)
	private BigDecimal trueUp;
	
	@Column(name = "[Adjustments]", nullable = false)
	private BigDecimal adjustments;
	
	@Column(name = "[TotalPharmacyInvoiced]", nullable = false)
	private BigDecimal totalPharmacyInvoiced;
	
	@Column(name = "[340BDirectPlusFee]", nullable = false)
	private BigDecimal direct340BPlusFee;
	
	@Column(name = "[340BDirectPlusVariableTransactionFee]", nullable = false)
	private BigDecimal direct340BPlusVariableTransactionFee;
	
	@Column(name = "[340BDirectPlusFlatFee]", nullable = false)
	private BigDecimal direct340BPlusFlatFee;
	
	@Column(name = "[Direct340BTrxnFee]", nullable = false)
	private BigDecimal direct340BTrxnFee;
	
	@Column(name = "[ContractPharmacyMinorMax]", nullable = false)
	private BigDecimal contractPharmacyMinorMax;
	
	@Column(name = "[Total340BDirectPlusFees]", nullable = false)
	private BigDecimal total340BDirectPlusFees;
	
	@Column(name = "[CETotalReceivedAmount]", nullable = false)
	private BigDecimal ceTotalReceivedAmount;
	
	@Column(name = "[CEThresholdMinOrMax]", nullable = false)
	private BigDecimal ceThresholdMinOrMax;
	
	@Column(name = "[NetDuetoCoveredEntity]", nullable = false)
	private BigDecimal netDuetoCoveredEntity;	
}
