package com.pps.managed.services.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "Drug_Manufacturer_LKP", schema = "dbo")
public class DrugManufacture {

	@Id
	@Column(name="DrugManufacturerID")
	private Long drugManufacturerID;
	
	@Column(name="DrugManufacturerName")
	private String drugManufacturerName;
}
