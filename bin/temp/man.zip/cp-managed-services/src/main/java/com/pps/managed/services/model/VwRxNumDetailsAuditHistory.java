package com.pps.managed.services.model;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Entity
@Data
@Table(name = "VwRxNumDetailsAuditHistory", schema = "plus")
public class VwRxNumDetailsAuditHistory {
	@Id
	@Column(name = "[id]")
	private Long id;
	
	@Column(name = "[Claimid]")
	private Long claimId;
	
	@Column(name = "[RxNumber]")
	private String rxNumber;
	
	@Column(name = "[AuditedBy]")
	private String auditedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "[AuditedDate]")
	private Date auditedDate;
}
