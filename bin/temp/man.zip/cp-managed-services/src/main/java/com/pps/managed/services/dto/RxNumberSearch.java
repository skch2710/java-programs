package com.pps.managed.services.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RxNumberSearch {

	private List<Long> ceID;
	private String rxNumber;

}
