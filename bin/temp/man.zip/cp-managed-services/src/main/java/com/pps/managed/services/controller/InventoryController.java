package com.pps.managed.services.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.pps.managed.services.dto.ClaimDispenseInnerGridSearch;
import com.pps.managed.services.dto.DrugManufacturerSearch;
import com.pps.managed.services.dto.InventoryInnerGridSearch;
import com.pps.managed.services.dto.InventorySearch;
import com.pps.managed.services.dto.Result;
import com.pps.managed.services.service.InventoryService;

import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/inventory")
@SecurityRequirement(name = "bearerAuth")
@Slf4j
public class InventoryController {
	
	/** The inventory service impl. */
	  @Autowired
	  InventoryService inventoryService;

	
	/**
	   * Search patients.
	   *
	   * @param authorization the authorization
	   * @param inventorySearch the inventory search
	   * @return the response entity
	   */
	  @PostMapping("/search")
	  public ResponseEntity<Result> searchPatients(
	      @RequestHeader(required = false, value = "Authorization") String authorization,
	      @RequestBody InventorySearch inventorySearch) {
	    log.debug("inside search for Inventory");
	    Result result = inventoryService.searchInventory(inventorySearch);
	    return ResponseEntity.ok(result);
	  }
	
	 /**
	   * Gets the claim dispense details.
	   *
	   * @param authorization the authorization
	   * @param claimDispenseInnerGridSearch the claim dispense inner grid search
	   * @return the claim dispense details
	   */
	  @PostMapping("/claimDispenseGrid")
	  public ResponseEntity<?> getClaimDispenseDetails(
	      @RequestHeader(required = false, value = "Authorization") String authorization,
	      @RequestBody ClaimDispenseInnerGridSearch claimDispenseInnerGridSearch) {
	    Result result = inventoryService.getClaimDispenseDetails(claimDispenseInnerGridSearch);

	    return ResponseEntity.ok(result);
	  }
	  
	  @GetMapping("/scheduletypelkp")
	  public Result getScheduleType() {
		  return inventoryService.getScheduleType();
	  }
		/**
		 * Gets the inventory inner grid.
		 *
		 * @param authorization            the authorization
		 * @param inventoryInnerGridSearch the inventory inner grid search
		 * @return the inventory inner grid
		 */
		@PostMapping("/InventoryInnerGrid")
		public ResponseEntity<?> getInventoryInnerGrid(
				@RequestHeader(required = false, value = "Authorization") String authorization,
				@RequestBody InventoryInnerGridSearch inventoryInnerGridSearch) {
			Result result = inventoryService.searchInventoryInnerGrid(inventoryInnerGridSearch);
			return ResponseEntity.ok(result);
		}

		/**
		 * getting DrugManufacturer
		 *
		 * @return the DrugManufacturer
		 */
		@PostMapping("/drugManufacturer")
		public ResponseEntity<?> getDrugManufacturer(@RequestBody DrugManufacturerSearch drugManufacturerDTO) {
			Result result = inventoryService.getDrugManufacturer(drugManufacturerDTO);
			return ResponseEntity.ok(result);
		}
	}
