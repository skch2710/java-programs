package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryDTO {

  private Long inventoryID;
  private String drugName;
  private String openingUnits;
  private String wholesalerName;
  private String returnedUnits;
  private String packageSize;
  private String unitsDispensed;
  private String unitsReplenished;
  private String ndc;
  private String npi;
  private String phName;
  private String three40BInventoryCost;
  private String three40BInventory;
  private String pxOwedInventory;
  private String ceOwnedInventory;
  private String drugManufacturerName;
  private Long ceID;
  private Long phID;
  private Long drugID;
  private Long drugManufacturerID;
  private Long wholesalerID;
  private Long drugDEAClassID;
  private String scheduleType;
}