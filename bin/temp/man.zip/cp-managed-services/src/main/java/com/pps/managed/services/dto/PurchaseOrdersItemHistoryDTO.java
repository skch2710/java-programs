package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrdersItemHistoryDTO {
  private Long poID;
  private Long poItemID;
  private Long poItemSeqID;
  private String filePoItemNumber;
  private String itemInvoiceNumber;
  private Long poItemStatusID;
  private Long packageOrdered;
  private Long packageAcknowledged;
  private Long packageInvoiced;
  private Long packageReconciled;
  private String fileItemStatusCode;
  private String itemOrderedDate;
  private String itemAcknowledgedDate;
  private String itemInvoicedDate;
  private String itemReconciledDate;
  private String acknowledgedNDC;
  private String inVoicedNDC;
  private Long substitutedParentpoItemId;
  private Long pgmPackageSize;
  private Long createdByID;
  private String createdDate;
}
