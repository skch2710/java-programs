package com.pps.managed.services.serviceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.pps.managed.services.common.Constant;
import com.pps.managed.services.dao.ClaimDispenseDetailsDAO;
import com.pps.managed.services.dao.DrugManufacturerDAO;
import com.pps.managed.services.dao.InventoryDAO;
import com.pps.managed.services.dao.InventoryInnerGridDAO;
import com.pps.managed.services.dao.ScheduleTypeDAO;
import com.pps.managed.services.dto.ClaimDispenseInnerGridDTO;
import com.pps.managed.services.dto.ClaimDispenseInnerGridSearch;
import com.pps.managed.services.dto.ColumnFilter;
import com.pps.managed.services.dto.DrugManufacturerSearch;
import com.pps.managed.services.dto.InventoryDTO;
import com.pps.managed.services.dto.InventoryInnerGridDTO;
import com.pps.managed.services.dto.InventoryInnerGridSearch;
import com.pps.managed.services.dto.InventorySearch;
import com.pps.managed.services.dto.Result;
import com.pps.managed.services.dto.SearchResult;
import com.pps.managed.services.exception.CustomException;
import com.pps.managed.services.mapper.ObjectMapper;
import com.pps.managed.services.model.ClaimDispense;
import com.pps.managed.services.model.DrugManufacture;
import com.pps.managed.services.model.Inventory;
import com.pps.managed.services.model.InventoryInnerGrid;
import com.pps.managed.services.service.InventoryService;
import com.pps.managed.services.specs.GenericSpecification;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class InventoryServiceImpl.
 */
@Service

/** The Constant log. */
@Slf4j
public class InventoryServiceImpl implements InventoryService {

	/** The mapper. */
	  private ObjectMapper MAPPER = ObjectMapper.INSTANCE;
	  
	  @Autowired
	  private ClaimDispenseDetailsDAO claimDispenseDetailsDAO;

	  /** The patient DAO. */
	  @Autowired
	  private InventoryDAO inventoryDAO;
	  
	  @Autowired
	  private ScheduleTypeDAO scheduleTypeDAO;
		/** The inventory inner grid DAO. */
		@Autowired
		private InventoryInnerGridDAO inventoryInnerGridDAO;
	  
		@Autowired
		private DrugManufacturerDAO drugManufacturerDAO;
	  /**
	   * Search inventory.
	   * 
	   * /** Fetching the inventory details based on the selected filters.
	   *
	   * @param inventorySearch the inventory search
	   * @return the result
	   */
	  @Override
	  public Result searchInventory(InventorySearch inventorySearch) {
	    log.debug("inside searchInventory ");
	    Result result = null;
	    try {
	      Map<String, Object> filters = null;
	      Map<String, Map<String, Object>> dynamicFilters = new HashMap<String, Map<String, Object>>();
	      if (inventorySearch.getSortBy() == null || "".equalsIgnoreCase(inventorySearch.getSortBy())) {
	        inventorySearch.setSortBy(Constant.INVENTORY_ID);
	      }

	      if (inventorySearch.getCeID() != null && inventorySearch.getCeID().size() > 0) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.IN, inventorySearch.getCeID());
	        dynamicFilters.put(Constant.CEID, filters);
	      }

	      if (inventorySearch.getPhID() != null && inventorySearch.getPhID() > 0) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, inventorySearch.getPhID());
	        dynamicFilters.put(Constant.PH_ID, filters);
	      }

	      if (inventorySearch.getWholesalerID() != null && inventorySearch.getWholesalerID() > 0) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, inventorySearch.getWholesalerID());
	        dynamicFilters.put(Constant.WHOLESALER_ID, filters);
	      }
	      if (inventorySearch.getNdc() != null && !"".equals(inventorySearch.getNdc())) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.START_WITH, inventorySearch.getNdc());
	        dynamicFilters.put(Constant.NDC, filters);
	      }
	      if (inventorySearch.getDrugName() != null && !"".equals(inventorySearch.getDrugName())) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.START_WITH, inventorySearch.getDrugName());
	        dynamicFilters.put(Constant.DRUG_NAME, filters);
	      }
	      if (inventorySearch.getDrugDEAClassID() != null && inventorySearch.getDrugDEAClassID() > 0) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, inventorySearch.getDrugDEAClassID());
	        dynamicFilters.put(Constant.DRUG_DEACLASS_ID, filters);
	      }
	      if (inventorySearch.getDrugManufacturerID() != null
	          && inventorySearch.getDrugManufacturerID() > 0) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, inventorySearch.getDrugManufacturerID());
	        dynamicFilters.put(Constant.DRUG_MANUFC_ID, filters);
	      }
	      if (inventorySearch.getInventoryFilter() != null
	          && "F".equals(inventorySearch.getInventoryFilter())) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, "Full");
	        dynamicFilters.put(Constant.INVENTORY_FILTER, filters);
	      } else if (inventorySearch.getInventoryFilter() != null
	          && "P".equals(inventorySearch.getInventoryFilter())) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, "Partial");
	        dynamicFilters.put(Constant.INVENTORY_FILTER, filters);
	      } else if (inventorySearch.getInventoryFilter() != null
	          && "C".equals(inventorySearch.getInventoryFilter())) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, "1");
	        dynamicFilters.put(Constant.CE_OWNED_DRUGS, filters);
	      }
	      if (inventorySearch.getFilter() != null) {
	        GenericSpecification.dynamicFilters(inventorySearch.getFilter(), dynamicFilters);
	      }

	      result = new Result();
	      if (!inventorySearch.isExport()) {
	        Page<Inventory> pageResult =
	            inventoryDAO.findAll(GenericSpecification.getSpecification(dynamicFilters),
	                GenericSpecification.getPagination(inventorySearch));

	        SearchResult<InventoryDTO> searchResult =
	            GenericSpecification.getPaginationDetails(pageResult, InventoryDTO.class);
	        List<InventoryDTO> inventoryDTOs = MAPPER.fromInventoryModel(pageResult.getContent());
	        searchResult.setContent(inventoryDTOs);
	        result.setData(searchResult);
	        if (inventoryDTOs.size() == 0) {
	          result.setStatusCode(HttpStatus.NOT_FOUND.value());
	          result.setErrorMessage("No Result Found");
	        } else {
	          result.setStatusCode(HttpStatus.OK.value());
	          result
	              .setSuccessMessage("Fetching all inventories details based on the selected filters");
	        }
	      } else {
	    	result.setStatusCode(HttpStatus.OK.value());
	        result.setData(exportData(inventorySearch, dynamicFilters));
	      }

	    } catch (Exception e) {
	      log.error("Error in searchInventory :: ", e);
	      throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    return result;
	  }
	

	  /**
	   * Export data.
	   *
	   * @param inventorySearch the inventory search
	   * @param dynamicFilters the dynamic filters
	   * @return the search result
	   */
	  private SearchResult<InventoryDTO> exportData(InventorySearch inventorySearch,
	      Map<String, Map<String, Object>> dynamicFilters) {
	    SearchResult<InventoryDTO> searchResult = new SearchResult<>();
	    try {
	      List<Inventory> sortResult =
	          this.inventoryDAO.findAll(GenericSpecification.getSpecification(dynamicFilters),
	              GenericSpecification.getSort(inventorySearch));

	      List<InventoryDTO> providersDTOs = MAPPER.fromInventoryModel(sortResult);
	      searchResult.setContent(providersDTOs);
	    } catch (Exception e) {
	      log.error("Error in exportData :: ", e);
	      throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    return searchResult;
	  }

	  /**
	   * Gets the claim dispense details.
	   *
	   * @return the claim dispense details
	   */
	  @Override
	  public Result getClaimDispenseDetails(ClaimDispenseInnerGridSearch claimDispenseInnerGridSearch) {
	    Result result = null;
	    try {
	      Map<String, Object> filters = null;
	      Map<String, Map<String, Object>> dynamicFilters = new HashMap<String, Map<String, Object>>();
	      if (claimDispenseInnerGridSearch.getSortBy() == null
	          || "".equalsIgnoreCase(claimDispenseInnerGridSearch.getSortBy())) {
	        claimDispenseInnerGridSearch.setSortBy(Constant.ID);
	      }

	      if (claimDispenseInnerGridSearch.getCeID() != null
	          && claimDispenseInnerGridSearch.getCeID() > 0) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, claimDispenseInnerGridSearch.getCeID());
	        dynamicFilters.put(Constant.CEID, filters);
	      }
	      if (claimDispenseInnerGridSearch.getPhID() != null
	          && claimDispenseInnerGridSearch.getPhID() > 0) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, claimDispenseInnerGridSearch.getPhID());
	        dynamicFilters.put(Constant.PH_ID, filters);
	      }
	      if (claimDispenseInnerGridSearch.getWholesalerID() != null
	          && claimDispenseInnerGridSearch.getWholesalerID() > 0) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, claimDispenseInnerGridSearch.getWholesalerID());
	        dynamicFilters.put(Constant.WHOLESALER_ID, filters);
	      }

	      if (claimDispenseInnerGridSearch.getNdc() != null
	          && claimDispenseInnerGridSearch.getNdc().length() > 0) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, claimDispenseInnerGridSearch.getNdc());
	        dynamicFilters.put(Constant.NDC, filters);
	      }
			if (claimDispenseInnerGridSearch.getLatestStatus() != null
					&& !"".equals(claimDispenseInnerGridSearch.getLatestStatus())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.START_WITH, claimDispenseInnerGridSearch.getLatestStatus());
				dynamicFilters.put(Constant.LATEST_STATUS, filters);
			}
	      
	      if (claimDispenseInnerGridSearch.getFilter() != null) {
	        GenericSpecification.dynamicFilters(claimDispenseInnerGridSearch.getFilter(),
	            dynamicFilters);
	      }
	      result = new Result();
	      if (!claimDispenseInnerGridSearch.isExport()) {
	        Page<ClaimDispense> pageResult = this.claimDispenseDetailsDAO.findAll(
	            GenericSpecification.getSpecification(dynamicFilters),
	            GenericSpecification.getPagination(claimDispenseInnerGridSearch));

	        SearchResult<ClaimDispenseInnerGridDTO> searchResult =
	            GenericSpecification.getPaginationDetails(pageResult, ClaimDispenseInnerGridDTO.class);

	        List<ClaimDispenseInnerGridDTO> claimDispenseInnerGridDTOs =
	            MAPPER.fromClaimDispenseInnerGridModel(pageResult.getContent());

	        searchResult.setContent(claimDispenseInnerGridDTOs);

	        result.setData(searchResult);
	        if (claimDispenseInnerGridDTOs.size() == 0) {
	          result.setStatusCode(HttpStatus.NOT_FOUND.value());
	          result.setErrorMessage("No Result Found");
	        } else {
	          result.setStatusCode(HttpStatus.OK.value());
	          result.setSuccessMessage("Fetching inventory details for the selected NDC");
	        }
	      } else {
	        result.setStatusCode(HttpStatus.OK.value());
	        result.setData(exportData(claimDispenseInnerGridSearch, dynamicFilters));
	      }
	    } catch (Exception e) {
	      log.error("Error in claimDispenseInnerGrid :: ", e);
	      throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    return result;
	  }

	  /**
	   * Export data.
	   *
	   * @param purchaseOrdersInnerGridSearch the purchase orders inner grid search
	   * @param dynamicFilters the dynamic filters
	   * @return the search result
	   */
	  private SearchResult<ClaimDispenseInnerGridDTO> exportData(
	      ClaimDispenseInnerGridSearch claimDispenseInnerGridSearch,
	      Map<String, Map<String, Object>> dynamicFilters) {
	    SearchResult<ClaimDispenseInnerGridDTO> searchResult = new SearchResult<>();

	    try {
	      List<ClaimDispense> sortResult = this.claimDispenseDetailsDAO.findAll(
	          GenericSpecification.getSpecification(dynamicFilters),
	          GenericSpecification.getSort(claimDispenseInnerGridSearch));

	      List<ClaimDispenseInnerGridDTO> claimDispenseInnerGridDTOs =
	          MAPPER.fromClaimDispenseInnerGridModel(sortResult);

	      searchResult.setContent(claimDispenseInnerGridDTOs);
	    } catch (Exception e) {
	      log.error("Error in exportData :: ", e);
	      throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    return searchResult;
	  }


	@Override
	public Result getScheduleType() {
		Result result = new Result(scheduleTypeDAO.findAll());
		result.setSuccessMessage("getting all dropdown values");
		result.setStatusCode(HttpStatus.OK.value());
		return result;
	}

		/**
		 * Search inventory inner grid.
		 *
		 * @param inventoryInnerGridSearch the inventory inner grid search
		 * @return the result
		 */

		@Override
		public Result searchInventoryInnerGrid(InventoryInnerGridSearch inventoryInnerGridSearch) {
			Result result = null;
			try {
				if (inventoryInnerGridSearch.getSortBy() == null
						|| "".equalsIgnoreCase(inventoryInnerGridSearch.getSortBy())) {
					inventoryInnerGridSearch.setSortBy(Constant.ID);
				}
				if (inventoryInnerGridSearch.getSortOrder() == null
						|| "".equalsIgnoreCase(inventoryInnerGridSearch.getSortOrder())) {
					inventoryInnerGridSearch.setSortOrder("asc");
				}

				String actionDate = "";
				String action = "";
				String captureDate = "";
				String refNo = "";
				String dispenseQty = "";
				String replenishedQty = "";
				String trueUpQty = "";
				String replenishedPerc = "";
				String totalPrice = "";
				String wholesalerName = "";
				String status = "";
				
				if (inventoryInnerGridSearch.getFilter() != null) {
					for (ColumnFilter columnFilter :inventoryInnerGridSearch.getFilter()) {
						if(columnFilter.getColumn().getField().equals(Constant.ACTION_DATE)) {
							actionDate = columnFilter.getValue();
						} else if(columnFilter.getColumn().getField().equals(Constant.ACTION)) {
							action = columnFilter.getValue();
						} else if(columnFilter.getColumn().getField().equals(Constant.INV_CAPTURED_DATE)) {
							captureDate = columnFilter.getValue();
						} else if(columnFilter.getColumn().getField().equals(Constant.REF_NO)) {
							refNo = columnFilter.getValue();
						} else if(columnFilter.getColumn().getField().equals(Constant.DISPENSED_QTY)) {
							dispenseQty = columnFilter.getValue();
						} else if(columnFilter.getColumn().getField().equals(Constant.REPLENISHED_QTY)) {
							replenishedQty = columnFilter.getValue();
						} else if(columnFilter.getColumn().getField().equals(Constant.TRUE_UP_QTY)) {
							trueUpQty = columnFilter.getValue();
						} else if(columnFilter.getColumn().getField().equals(Constant.REPLENISHED_PERC)) {
							replenishedPerc = columnFilter.getValue();
						} else if(columnFilter.getColumn().getField().equals(Constant.TOTAL_PRICE)) {
							totalPrice = columnFilter.getValue();
						} else if(columnFilter.getColumn().getField().equals(Constant.WHOLESALER_NAME)) {
							wholesalerName = columnFilter.getValue();
						} else if(columnFilter.getColumn().getField().equals(Constant.CLAIM_STATUS)) {
							status = columnFilter.getValue();
						}
					}
				}
				
				result = new Result();
				List<InventoryInnerGrid> inventoryInnerGrids = this.inventoryInnerGridDAO.getPODetails(inventoryInnerGridSearch.getCeID(),
						inventoryInnerGridSearch.getRxNumber(), inventoryInnerGridSearch.getDispensedDate(),inventoryInnerGridSearch.getNdc(),inventoryInnerGridSearch.getPhID(),
						inventoryInnerGridSearch.getWholesalerID(),inventoryInnerGridSearch.getPageNumber(),
						inventoryInnerGridSearch.getPageSize(), inventoryInnerGridSearch.getSortBy(),
						inventoryInnerGridSearch.getSortOrder(), inventoryInnerGridSearch.isExport() ? "T" : "F"
						, actionDate, action, captureDate, refNo, dispenseQty, replenishedQty, trueUpQty, replenishedPerc, totalPrice, wholesalerName, status
						);

				List<InventoryInnerGridDTO> inventoryInnerGridDTOs = MAPPER
						.fromInventoryInnerGridModel(inventoryInnerGrids);
				SearchResult<InventoryInnerGridDTO> searchResult = new SearchResult<>();
				searchResult.setContent(inventoryInnerGridDTOs);
				searchResult.setPageNo(inventoryInnerGridSearch.getPageNumber());
				searchResult.setPageSize(inventoryInnerGridSearch.getPageSize());

				result.setData(searchResult);
				if (inventoryInnerGridDTOs.size() == 0) {
					result.setStatusCode(HttpStatus.NOT_FOUND.value());
					result.setErrorMessage("No Result Found");
				} else {
					searchResult.setTotalElements(inventoryInnerGrids.get(0).getTotalRows());
					result.setStatusCode(HttpStatus.OK.value());
					result.setSuccessMessage("Fetching all inventory replinished details for the selected claim ID");
				}
			} catch (Exception e) {
				log.error("Error in searchInventoryInnerGrid :: ", e);
				throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return result;
		}

		/**
		 * Get DrugManufacturer.
		 *
		 * @param DrugManufacturer the DrugManufacturer search
		 * @return the result
		 */

		@Override
		public Result getDrugManufacturer(DrugManufacturerSearch drugManufacturerSearch) {
			Result result = null;
			try {
				List<DrugManufacture> drugManufactures= drugManufacturerDAO.getDrugManufacturer(drugManufacturerSearch.getCeID(),
						drugManufacturerSearch.getPhID(), 
						drugManufacturerSearch.getWholesalerID(), 
						drugManufacturerSearch.getDrugManufacturerName());
				result = new Result(drugManufactures);
				result.setStatusCode(HttpStatus.OK.value());
				result.setSuccessMessage("Fetching DrugManufacturer details.");

			} catch (Exception e) {
				log.error("Error in DrugManufacturer :: ", e);
				throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return result;
		}
	}
