package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import com.pps.managed.services.model.PurchaseOrdersInnerGrid;

public interface PurchaseOrdersInnerGridDAO extends JpaRepository<PurchaseOrdersInnerGrid, Long> {


	  Page<PurchaseOrdersInnerGrid> findAll(Specification<PurchaseOrdersInnerGrid> spec,
	      Pageable pageable);

	  List<PurchaseOrdersInnerGrid> findAll(Specification<PurchaseOrdersInnerGrid> spec, Sort sort);
}
