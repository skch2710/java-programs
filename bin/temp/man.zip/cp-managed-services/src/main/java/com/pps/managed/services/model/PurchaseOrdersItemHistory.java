package com.pps.managed.services.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "vwpurchase_order_item_history_mvp", schema = "Plus")
public class PurchaseOrdersItemHistory {
	@Column(name="[POID]")
	private Long poID;
	
	@Column(name="po_itemid")
	private Long poItemID;

	@Id
	@Column(name="po_item_seqid")
	private Long poItemSeqID;
	
	@Column(name="file_poitem_number")
	private String filePoItemNumber;
	
	@Column(name="item_invoice_number")
	private String itemInvoiceNumber;
	
	@Column(name="po_item_status_id")
	private Long poItemStatusID;
	
	@Column(name="package_ordered")
	private Long packageOrdered;

	@Column(name="package_acknowledged")
	private Long packageAcknowledged;

	@Column(name="package_invoiced")
	private Long packageInvoiced;
	
	@Column(name="[Package Reconciled]")
	private Long packageReconciled;
	
	@Column(name="file_item_status_code")
	private String fileItemStatusCode;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="item_ordered_date")
	private Date itemOrderedDate;
	

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="item_acknowledged_date")
	private Date itemAcknowledgedDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="item_invoiced_date")
	private Date itemInvoicedDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="[Item reconciled Date]")
	private Date itemReconciledDate;
	
	@Column(name="AcknowledgedNDC")
	private String acknowledgedNDC;
	
	@Column(name="InvoicedNDC")
	private String inVoicedNDC;
	
	@Column(name="substituted_parent_po_item_id")
	private Long substitutedParentpoItemId;
	
	@Column(name="pgm_package_size")
	private Long pgmPackageSize;
	
	@Column(name="created_byid")
	private Long createdByID;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_date")
	private Date createdDate;

}
