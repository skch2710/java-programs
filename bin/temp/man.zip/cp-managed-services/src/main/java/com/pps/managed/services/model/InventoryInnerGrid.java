package com.pps.managed.services.model;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "VwInventoryInnerGrid2", schema = "dbo")
public class InventoryInnerGrid {

	@Id
	@Column(name = "[id]", nullable = false)
	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "[ActionDate]")
	private Date actionDate;

	@Column(name = "[Action]")
	private String action;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "[CapturedDate]")
	private Date capturedDate;

	@Column(name = "[RefNo]")
	private String refNo;

	@Column(name = "[TotalPrice]")
	private BigDecimal totalPrice;

	@Column(name = "[Wholesaler]")
	private String wholesaler;

	@Column(name = "[Status]")
	private String status;

	@Column(name = "[ClaimID]")
	private Long claimID;

	@Column(name = "[NDC]")
	private String ndc;

	@Column(name = "[PHID]")
	private Long phID;

	@Column(name = "[CEID]")
	private Long ceID;

	@Column(name = "WholesalerID")
	private Long wholesalerID;

	@Column(name = "[RxNumber]")
	private String rxNumber;

	@Column(name = "totalRows")
	private Long totalRows;

	@Column(name = "[DispensedQty]")
	private String dispensedQty;

	@Column(name = "[ReplenishedQty]")
	private String replenishedQty;

	@Column(name = "[ReturnedQty]")
	private String returnedQty;

	@Column(name = "[TrueUpQty]")
	private BigDecimal trueUpQty;

	@Column(name = "[ReplenishedPerc]")
	private String replenishedPerc;

}
