package com.pps.managed.services.service;

import com.pps.managed.services.dto.ClaimDispenseInnerGridSearch;
import com.pps.managed.services.dto.DrugManufacturerSearch;
import com.pps.managed.services.dto.InventoryInnerGridSearch;
import com.pps.managed.services.dto.InventorySearch;
import com.pps.managed.services.dto.Result;

public interface InventoryService {

	Result searchInventory(InventorySearch inventorySearch);
	
	Result getClaimDispenseDetails(ClaimDispenseInnerGridSearch claimDispenseInnerGridSearch);
	
	Result getScheduleType();
	 Result searchInventoryInnerGrid(InventoryInnerGridSearch inventoryInnerGridSearch);
	 
	 Result getDrugManufacturer(DrugManufacturerSearch drugManufacturerDTO);

}
