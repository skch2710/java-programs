package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import com.pps.managed.services.model.PurchaseOrderHistory;

public interface PurchaseOrderHistoryDAO extends JpaRepository<PurchaseOrderHistory, Long> {
  
  Page<PurchaseOrderHistory> findAll(Specification<PurchaseOrderHistory> spec, Pageable pageable);
  List<PurchaseOrderHistory> findAll(Specification<PurchaseOrderHistory> spec, Sort sort);
}
