package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class ClaimDispenseInnerGridSearch extends Pagination {

  private Long ceID;
  private Long phID;
  private Long wholesalerID;
  private String ndc;
  private String latestStatus;
}
