package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VwRxNumDetailsEligibilityDTO {
	private String RxNumber;
	private Long claimId;
	private String EligibilityRule;
	private String EligibilityRuleStatus;
}
