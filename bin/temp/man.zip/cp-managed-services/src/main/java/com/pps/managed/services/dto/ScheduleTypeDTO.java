package com.pps.managed.services.dto;



public class ScheduleTypeDTO {
	  private Long drugDEAClassID;
	  private String drugDEAClassCode;
	  private String drugDEAClassDesc;
	  private String inactiveFlag;
	  private Long createdByID;
	  private String createdDate;
	  private Long modifiedByID;
	  private String modifiedDate;
}
