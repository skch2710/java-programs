package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrueUpReportPopupDTO {

	private Long claimId;
	private String processedDate;
	private String rxNumber;
	private String rxWrittenDate;
	private String refillHash;
	private String dateOfService;
	private String tfbID;
	private String coveredEntity;
	private String memberFirstName;
	private String memberLastName;
	private String memberId;
	private String patientVisitDate;
	private String patientSlidingScale;
	private String physicianFirstName;
	private String physicianLastName;
	private Long prescriberID;
	private String store;
	private String ncpdp;
	private String npi;
	private String ndcEleven;
	private String drugName;
	private String indicator;
	private String qtyDisp;
	private String daysSupply;
	private String bin;
	private String pcn;
	private String groupNumber;
	private Long personType;
	private String patientPay;
	private Long thirdPartPayment;
	private String cePlanSubsidy;
	private Long totalPayment;
	private Long insuredPatientCost;
	private Long unInsuredPatientCost;
	private String grossDispensingFee;
	private String programAdminFee;
	private String tfBIngredientCost;
	private Long totalClaimCost;
	private String totalCEReceivable;
	private String claimProfitorLoss;
	private String reversed;
	private Long poNumber;
	private String memberDateOfBirth;
	private String startDate;
	private String endDate;
	private Long ceid;
	private Long phGroupId;
	private Long phid;
	private String trueUpDate;
	private String trueUpUnits;
	private String brandGenericFlag;
	private String unitprice;
	private String trueUpAdjpercent;
	private Long trueUpDispensingFee;
	private String trueUpAmount;
	private String trueUpReason;
	private String dispensingStore;
	private String dispensingStoreNPI;
	private Long carveInClaimId;
	private String ceReimbursementModel;
	private String eac;
	private String trueUpModel;
	private String metricQuantity;
	private String eacType;
	private String trueUpEAC;
	private String mCOTrueUpCost;
	private String trueUpUnitsMetricQty;
	private String billingPeriod;
	private String sourceType;

}
