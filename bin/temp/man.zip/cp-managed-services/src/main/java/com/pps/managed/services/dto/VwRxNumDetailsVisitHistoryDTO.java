package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VwRxNumDetailsVisitHistoryDTO {
	
	private Long id;
	private String visitDate;
	private String hospitalService;
	private String admitType;
	private String servicingFacility;
	private String assignedPatientLocation;
	private String prescriberNPI;
	private String prescriberFirstName;
	private String prescriberLastName;
	private String rxNumber;
	private Long claimId;

}
