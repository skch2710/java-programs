package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.InvoiceTrueUp;

@Repository
public interface InvoiceTrueUpDAO extends JpaRepository<InvoiceTrueUp, Long>{
	
	@Query(value="EXEC plus.UspInvoiceTrueUpDetails @In_Ceid=:ceid, @In_StartPeriod=:startPeriod,"
			+ " @In_EndPeriod=:endPeriod, @In_Phgroupid=:phgroupId,"
			+ " @In_PhId=:phid, @In_SortColumn=:sortColumn,"
			+ " @In_SortDirection=:sortDirection, @In_PageNumber=:pageNumber,"
			+ " @In_PageSize=:pageSize, @In_IsExport=:export,"
			+ " @In_BillingCycle=:billingCycle, @In_340BID=:tfbID,"
			+ " @In_Claimid=:claimId, @In_ProcessedDate=:processedDate, @In_RxNumber=:rxNumber,"
			+ " @In_RxWrittenDate=:rxWrittenDate, @In_Refill#=:refill,"
			+ " @In_DateOfService=:dateofService, @In_Bin=:bin,"
			+ " @In_PCN=:pcn, @In_PHGroupName=:phGroupName,"
			+ " @In_Store=:store, @In_DispensingStoreNPI=:dispensingStoreNPI,"
			+ " @In_NDC11=:ndc, @In_DrugName=:drugName,"
			+ " @In_BrandGenericFlag=:brandGenericFlag, @In_replenishedpercentage=:replenishedpercentage,"
			+ " @In_TrueUpUnits=:trueUPUnits, @In_TrueUpAmount=:trueUpAmount,"
			+ " @In_TrueUpReason=:trueUpReason, @In_TrueUpType=:trueUpType", nativeQuery = true)
	List<InvoiceTrueUp> getInvoiceTrueUpDetails(@Param("ceid") Long ceid, @Param("startPeriod") String startPeriod,
			@Param("endPeriod") String endPeriod, @Param("phgroupId") Long phgroupId, @Param("phid") Long phid,
			@Param("sortColumn") String sortColumn, @Param("sortDirection") String sortDirection,
			@Param("pageNumber") int pageNumber, @Param("pageSize") int pageSize,
			@Param("export") int export, @Param("billingCycle") String billingCycle,
			@Param("tfbID") String tfbID, @Param("claimId") Long claimId, @Param("processedDate") String processedDate,
			@Param("rxNumber") String rxNumber, @Param("rxWrittenDate") String rxWrittenDate,
			@Param("refill") String refill, @Param("dateofService") String dateofService,
			@Param("bin") String bin, @Param("pcn") String pcn, @Param("phGroupName") String phGroupName,
			@Param("store") String store, @Param("dispensingStoreNPI") String dispensingStoreNPI,
			@Param("ndc") String ndc, @Param("drugName") String drugName,
			@Param("brandGenericFlag") String brandGenericFlag, @Param("replenishedpercentage") String replenishedpercentage,
			@Param("trueUPUnits") String trueUPUnits, @Param("trueUpAmount") String trueUpAmount,
			@Param("trueUpReason") String trueUpReason, @Param("trueUpType") String trueUpType);
}
