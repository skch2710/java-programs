package com.pps.managed.services.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldNameConstants
public class GetRxNumberDetailsDTO {

	private Long CEID;
	private String PatientName;
	private String RxNumber;
	private String ClaimStatus;
	private String CoveredEntity;
	private String Pharmacy;
	private String Prescriber;
	private String EntityLocation;
	private String RxDateWritten;
	private String DataFilled;
	private String VisitDate;
	private Long RefillNumber;
	private BigDecimal DispensedQuantity;
	private String BrandGeneric;
	private String NDC;
	private String DrugName;
	private String savings;
	private String drugCost;
	private String dispensingFee;
	private String adminFee;
	private String PODate;
	private String InvoiceDate;
	private Long PersonID;
	private Long PHID;
	private Long ClaimID;
	private String Action;
	private String ActionDate;
	private String Notes;
	private List<VwRxNumDetailsAuditHistoryDTO > AuditHistory = new  ArrayList<>();
	private List<VwRxNumDetailsClaimHistoryDTO> ClaimHistory= new  ArrayList<>();
	private List<VwRxNumDetailsEligibilityDTO>Eligibility= new  ArrayList<>();
	private List<RxNumberTimelineData>timelineData  = new ArrayList<>();
	private VwRxNumDetailsVisitHistoryDTO visitHistory;
}
