package com.pps.managed.services.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.Immutable;

import lombok.Getter;

@Entity
@Immutable
@Getter
@Table(name = "VwClaimsManagement", schema = "plus")
public class ClaimsManagement {
	
	@Column(name="PatientName")
	private String patientName;
	
	@Column(name="Provider")
	private String provider;
	
	@Column(name="Pharmacy")
	private String pharmacy;
	
	@Column(name="ProviderNPI")
	private String providerNPI;
	
	@Column(name="DOS")
	private Date dos;
	
	@Column(name="ClaimCaptured")
	private Date claimCaptured;
	
	@Column(name="Status")
	private String status;
	
	@Column(name="PharmacyGroup")
	private String pharmacyGroup;
	
	@Column(name="PatientFirstName")
	private String patientFirstName;
	
	@Column(name="PatientLastName")
	private String patientLastName;
	
	@Column(name="PatientDOB")
	private Date patientDOB;
	
	@Column(name="ClaimType")
	private String claimType;
	
	@Column(name="Location")
	private String location;
	
	@Column(name="ProviderLastName")
	private String providerLastName;
	
	@Column(name="EntityLocationID")
	private Long entityLocationID;
	
	@Column(name="Speciality")
	private String speciality;
	
	@Column(name="Eligibility")
	private String eligibility;
	
	@Column(name="[CE Savings]")
	private BigDecimal ceSavings;
	
	@Column(name="[Reason(s)]")
	private String reasons;
	
	@Column(name="Score")
	private String score;
	
	@Column(name="PharmacyNPI")
	private String pharmacyNPI;
	
	@Column(name="MRN")
	private Long mrn;
	
	@Column(name="ClaimStatus")
	private String claimStatus;
	
	@Column(name="BrandGenericTypeID")
	private Long brandGenericTypeID;
	
	@Column(name="BothTypeID")
	private Long bothTypeID;
	
	@Column(name="ActionTaken")
	private String actionTaken;
	
	@Column(name="ActionDate")
	private Date actionDate;
	
	@Column(name="ActionTakenBy")
	private String actionTakenBy;
	
	@Column(name="Note")
	private String note;
	
	@Column(name="CoveredEntity")
	private String coveredEntity;
	
	@Column(name="HRSAID")
	private String hrsaid;
	
	@Id
	@Column(name="ClaimID")
	private Long claimID;
	
	@Column(name="ProcessedDate")
	private Date processedDate;
	
	@Column(name="RxNumber")
	private String rxNumber;
	
	@Column(name="RxWrittenDate")
	private Date rxWrittenDate;
	
	@Column(name="Refill#")
	private String refill;
	
	@Column(name="DateofService")
	private Date dateofService;
	
	@Column(name="MemberFirstName")
	private String memberFirstName;
	
	@Column(name="MemberLastName")
	private String memberLastName;
	
	@Column(name="MemberID")
	private String memberID;
	
	@Column(name="PatientSlidingScale")
	private String patientSlidingScale;
	
	@Column(name="PhysicianFirstName")
	private String physicianFirstName;
	
	@Column(name="PhysicianLastName")
	private String physicianLastName;
	
	@Column(name="PrescriberID")
	private String prescriberID;
	
	@Column(name="Store")
	private String store;
	
	@Column(name="NCPDP")
	private String ncpdp;
	
	@Column(name="NPI")
	private String npi;
	
	@Column(name="NDC")
	private String ndc;
	
	@Column(name="DrugName")
	private String drugName;
	
	@Column(name="[Indicator]")
	private String indicator;
	
	@Column(name="QtyDisp")
	private String qtyDisp;
	
	@Column(name="DaysSupply")
	private Long daysSupply;
	
	@Column(name="BIN")
	private String bin;
	
	@Column(name="PCN")
	private String pcn;
	
	@Column(name="GroupNumber")
	private String groupNumber;
	
	@Column(name="PatientType")
	private String patientType;
	
	@Column(name="PatientPay")
	private BigDecimal patientPay;
	
	@Column(name="ThirdPartyPayment")
	private BigDecimal thirdPartyPayment;
	
	@Column(name="CEPlanSubsidy")
	private BigDecimal cePlanSubsidy;
	
	@Column(name="TotalPayment")
	private BigDecimal totalPayment;
	
	@Column(name="InsuredPatientCost")
	private BigDecimal insuredPatientCost;
	
	@Column(name="UninsuredPatientCost")
	private BigDecimal uninsuredPatientCost;
	
	@Column(name="GrossDispensingFee")
	private BigDecimal grossDispensingFee;
	
	@Column(name="ProgramAdminFee")
	private Long programAdminFee;
	
	@Column(name="[340BIngredientCost]")
	private BigDecimal tfBIngredientCost;
	
	@Column(name="TotalClaimCost")
	private Long totalClaimCost;
	
	@Column(name="TotalCEReceivable")
	private BigDecimal totalCEReceivable;
	
	@Column(name="ClaimProfitLoss")
	private BigDecimal claimProfitLoss;
	
	@Column(name="Reversed")
	private String reversed;
	
	@Column(name="ReplenishedQty")
	private Long replenishedQty;
	
	@Column(name="TotalClaimCostAdjustedforReplenishedQty")
	private Long totalClaimCostAdjustedforReplenishedQty;
	
	@Column(name="ClaimProfitLossAdjustedforReplenishedQty")
	private Long claimProfitLossAdjustedforReplenishedQty;
	
	@Column(name="ReplenishmentID")
	private Long replenishmentID;
	
	@Column(name="CEReimbursementModelId")
	private Long ceReimbursementModelId;
	
	@Column(name="EAC")
	private Long eac;
	
	@Column(name="[Fallout Reason(s)]")
	private String falloutReasons;
	
	@Column(name="ClaimScore")
	private Long claimScore;
	
	@Column(name="PHID")
	private Long phID;
	
	@Column(name="CEID")
	private Long ceID;
	
	@Column(name="PersonID")
	private Long personID;
	
	@Column(name="PHGroupID")
	private Long phGroupID;
	
	@Column(name="ClaimTypeId")
	private Long claimTypeId;
	
	@Column(name="BINID")
	private Long binID;
	
	@Column(name="ReasonID")
	private Long reasonID;
	
    @Column(name="SavingsMin")
    private BigDecimal savingsMin;
    
    @Column(name="SavingsMax")
    private BigDecimal savingsMax;
}
