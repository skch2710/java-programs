package com.pps.managed.services.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrder {

	  @Id
	  @Column(name = "[POId]", nullable = false)
	  private Long poID;

	  @Column(name = "CoveredEntity", nullable = false)
	  private String ceName;

	  @Column(name = "Pharmacy", nullable = false)
	  private String pharmacy;
	  
	  @Column(name = "Wholesaler", nullable = false)
	  private String wholesaler;

	  @Temporal(TemporalType.TIMESTAMP)
	  @Column(name = "PODate", nullable = false)
	  private Date poDate;

	  @Column(name = "POStatus", nullable = false)
	  private String poStatus;

	  @Column(name = "TotalOrderAmount", nullable = false)
	  private BigDecimal totalOrderAmount;

	  @Column(name = "TotalBilledAmount", nullable = false)
	  private BigDecimal totalBilledAmount;

//	  @Column(name = "order_type", nullable = false)
//	  private String orderType;
	  
//	  @Column(name = "WholeSalerAccountDivisionCode")
//	  private String wholeSalerAccountDivisionCode;
	  
	  @Column(name = "POSTatusId")
	  private Long poStatusID;

	  @Column(name = "CEID")
	  private Long ceID;

//	  @Column(name = "OrgId")
//	  private Long orgID;

	  @Column(name = "PHId")
	  private Long phID;

	  @Column(name = "PHGroupID")
	  private Long phGroupID;

	  @Column(name = "WholesalerAccountID")
	  private Long wholesalerAccountID;

	  @Column(name = "totalRows")
	  private Long totalRows;
	  
	  @Column(name = "HRSAID")
	  private String hrsaID;
	  
	  @Column(name="WholesalerID")
	  private Integer wholesalerID;
}
