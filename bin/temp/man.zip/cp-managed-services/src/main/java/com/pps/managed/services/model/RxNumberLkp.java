package com.pps.managed.services.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RxNumberLkp {

	@Id
	private Long id;
	
	@Column(name = "[RxNumber]")
	private String rxNumber;

}
