package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.VwRxNumDetailsAuditHistory;

@Repository
public interface VwRxNumDetailsAuditHistoryDAO  extends JpaRepository<VwRxNumDetailsAuditHistory, Long> {
 List<VwRxNumDetailsAuditHistory> findAllByClaimIdAndRxNumber(Long Claimid, String RxNumber);
}
