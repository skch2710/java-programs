package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrderPXClaimDTO {

  private Long poID;
  private String filePONumber;
  private String itemInvoiceNumber;
  private String itemInvoicedDate; 
  private Long ceID;
  private String store;
  private Long claimID;
  private String invoiceDate340BDirect;
  private String reFillNo;
  private String wholesalerAccountDivisionCode;
  private Long centralClientID;
  private Long poItemID;
  private Long invOrderID;
  private Long claimTypeID;
  private String poDate;
  private Long drugID;
  private String ndc;
  private String drugName;
  private String itemPkgs;
  private String pkgSize;
  private String poItemStatus;
  private String noClaimReason;
  private String claimsMappingFlag;
  private String dateOfService;
  private String rxNumber;
  private String units;
  private String sourceType;
  private Long inventoryItemID;
  private String receivingStore;
  private Long phID;
  private String dispensingStore;
  private String tfbId;
  private String admin340b;
  private String memberFirstName;
  private String memberLastName;
  private String memberID;
  private String physicianFirstName;
  private String physicianLastName;
  private Long prescriberID;
  private Long clientID;
  private String totalQuantity;
  private String manufacturere;
  private Integer dispensedUnits;
  private Integer replenishedUnits;
}