package com.pps.managed.services.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.ScheduleType;

@Repository
public interface ScheduleTypeDAO extends JpaRepository<ScheduleType, Long>{

}
