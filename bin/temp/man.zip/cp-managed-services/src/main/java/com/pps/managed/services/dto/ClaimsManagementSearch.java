package com.pps.managed.services.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class ClaimsManagementSearch extends Pagination {

  private List<Long> ceID;
  private List<Long> phGroupID;
  private List<Long> phID;
  private List<Long> entityLocationID;
  private List<String> rxNumber;
  private List<Long> claimTypeID;
  private List<Long> binID;
  private Long brandGenericTypeID;
  private List<Long> reasonID;
  private List<Long> mrn;
  private String patientDOB;
  private String providerNPI;
  private String providerLastName;
  private String ndc;
  private String savingsMin;
  private String savingsMax;
  private String patientFirstName;
  private String patientLastName;
  private String dosFromDate;
  private String dosToDate;
  private String capturedFromDate;
  private String capturedToDate;
  private List<String> status;
  private String patientInfo;
}
