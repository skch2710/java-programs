package com.pps.managed.services.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.Immutable;

import lombok.Getter;

@Entity
@Immutable
@Getter 
@Table(name = "vw_Purchase_Order_History_mvp", schema = "plus")
public class PurchaseOrderHistory {

  @Id
  @Column(name = "[POLogID]", nullable = false)
  private Long poLogID;

  @Column(name = "[POID]", nullable = false)
  private Long poID;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "PODate")
  private Date poDate;

  @Column(name = "ReasonDesc")
  private String reasonDesc;
  
  @Column(name = "POStatus")
  private String poStatus;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "POStatusDate")
  private Date poStatusDate;

  @Column(name = "InvoiceNumber")
  private String invoiceNumber;

  @Column(name = "[EDI 855 File Count]")
  private Integer edi855FileCount;

  @Column(name = "[EDI 810 File Count]")
  private Integer edi810FileCount;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "CreatedDate")
  private Date createdDate;

  @Column(name = "CreatedByID")
  private Long createdByID;

}