package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pps.managed.services.model.InventoryInnerGrid;
import com.pps.managed.services.model.InvoicesMainGrid;

public interface InvoicesMainGridDAO extends JpaRepository<InvoicesMainGrid, Long>{

	Page<InvoicesMainGrid> findAll(Specification<InventoryInnerGrid> spec, Pageable pageable);

	List<InvoicesMainGrid> findAll(Specification<InventoryInnerGrid> spec, Sort sort);

	@Query(value = "EXEC [Plus].[Usp_InvoiceScreenDetailsOnCelevelwithCLF]  @In_CoveredEntityid=:ceid,@In_PharmacyGroupid=:phGroupId, @In_Pharmacyid=:phId, @In_StartPeriod=:invoicePeriodStartDate,@In_EndPeriod=:invoicePeriodEndDate,@In_SortColumn=:sortBy, @In_SortDirection=:sortOrder, @In_PageNumber=:pageNumber,@In_PageSize=:pageSize, @In_IsExport=:export,\r\n"
			+ "@In_InvoiceNumber=:invoiceNumber,@In_CENAME=:ceName,@In_BillingPeriod=:billingPeriod,@In_TotalInvoiced=:totalInvoiced,@In_DispensingFee=:dispensingFee,@In_Trueup=:trueUp,@In_Storefees=:storeFees,@In_CETotalReceivedAmount=:ceTotalReceivedAmount,@In_340BDirectplusFee=:direct340BTrxnFee,@In_Invoicestartdate=:invoiceStartDate,@In_Invoiceenddate=:invoiceEndDate", nativeQuery = true)
	List<InvoicesMainGrid> getInvoiceGridDetails(@Param("ceid") Long ceid,@Param("phGroupId") Long phGroupId,@Param("phId") Long phId, @Param("invoicePeriodStartDate") String invoicePeriodStartDate, @Param("invoicePeriodEndDate") String invoicePeriodEndDate,
			@Param("pageNumber") Integer pageNumber, @Param("pageSize") Integer pageSize,
			@Param("sortBy") String sortBy, @Param("sortOrder") String sortOrder, @Param("export") Boolean export,@Param("invoiceNumber") String invoiceNumber,
			@Param("ceName") String ceName,@Param("billingPeriod") String billingPeriod,@Param("totalInvoiced") String totalInvoiced,@Param("dispensingFee") String dispensingFee,
			@Param("trueUp") String trueUp,@Param("storeFees") String storeFees,@Param("ceTotalReceivedAmount") String ceTotalReceivedAmount,@Param("direct340BTrxnFee") String direct340BTrxnFee,@Param("invoiceStartDate") String invoiceStartDate,@Param("invoiceEndDate") String invoiceEndDate);
}
