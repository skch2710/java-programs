package com.pps.managed.services.dao;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import com.pps.managed.services.model.PhInvoiceReport;

public interface PhInvoiceReportDAO extends JpaRepository<PhInvoiceReport, Long> {

	Page<PhInvoiceReport> findAll(Specification<PhInvoiceReport> spec, Pageable pageable);

	List<PhInvoiceReport> findAll(Specification<PhInvoiceReport> spec, Sort sort);

}
