package com.pps.managed.services.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.pps.managed.services.model.PatientMRNLKP;

public interface PatientMRNDAO extends JpaRepository<PatientMRNLKP, Long> {
	
	@Query(value = "SELECT TOP 100 * FROM [dbo].[Person] where ceID in :ceID and PersonId LIKE :personId%  ORDER BY PersonID", nativeQuery = true)
	List<PatientMRNLKP> getPatientMRNLKPDetails(@Param("ceID") List<Long> ceID,@Param("personId") Long personId);

	@Query(value = "SELECT TOP 100 * FROM [dbo].[Person] where ceID in :ceID and FirstName LIKE :firstName%  ORDER BY FirstName", nativeQuery = true)
	List<PatientMRNLKP> getPatientFirstName(@Param("ceID") List<Long> ceID, @Param("firstName") String firstName);
	
	@Query(value = "SELECT TOP 100 * FROM [dbo].[Person] where ceID in :ceID and LastName LIKE :lastName%  ORDER BY LastName", nativeQuery = true)
	List<PatientMRNLKP> getPatientLastName(@Param("ceID") List<Long> ceID, @Param("lastName") String lastName);
}
