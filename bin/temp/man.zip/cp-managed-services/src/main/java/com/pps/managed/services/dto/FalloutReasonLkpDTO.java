package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FalloutReasonLkpDTO {

	private Long reasonID;
	private String reasonCode;
	private String reasonDesc;
	private Long reasonTypeID;
	private String inactiveFlag;
	private String displayName;
	private String reprocessFlag;
	private Long createdByID;
	private String createdDate;
	private Long modifiedByID;
	private String modifiedDate;
}
