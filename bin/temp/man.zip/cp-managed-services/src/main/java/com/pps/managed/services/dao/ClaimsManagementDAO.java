package com.pps.managed.services.dao;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.ClaimsManagement;

@Repository
public interface ClaimsManagementDAO extends JpaRepository<ClaimsManagement, Long> {

  Page<ClaimsManagement> findAll(Specification<ClaimsManagement> spec, Pageable pageable);

  List<ClaimsManagement> findAll(Specification<ClaimsManagement> spec, Sort sort);


}
