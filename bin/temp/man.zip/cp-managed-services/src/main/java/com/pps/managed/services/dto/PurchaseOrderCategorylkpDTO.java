package com.pps.managed.services.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrderCategorylkpDTO {

	private Long POCategoryID;

	private String POCategoryCode;

	private String POCategory;

	private String InActiveFlag;

	private String CreatedByID;

	private Date CreatedDate;

	private Long ModifiedByID;

	private Date ModifiedDate;
}
