package com.pps.managed.services.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "VwRxNumDetailsVisitHistory", schema = "plus")
public class VwRxNumDetailsVisitHistory {

	@Id
	@Column(name = "[id]")
	private Long id;
	
	@Column(name = "[VisitDate]")
	private Date visitDate;
	
	@Column(name = "[HospitalService]")
	private String hospitalService;
	
	@Column(name = "[AdmitType]")
	private String admitType;
	
	@Column(name = "[ServicingFacility]")
	private String servicingFacility;
	
	@Column(name = "[AssignedPatientLocation]")
	private String assignedPatientLocation;
	
	@Column(name = "[PrescriberNPI]")
	private String prescriberNPI;
	
	@Column(name = "[PrescriberFirstName]")
	private String prescriberFirstName;
	
	@Column(name = "[PrescriberLastName]")
	private String prescriberLastName;
	
	@Column(name = "[RxNumber]")
	private String rxNumber;
	
	@Column(name = "[Claimid]")
	private Long claimId;
}
