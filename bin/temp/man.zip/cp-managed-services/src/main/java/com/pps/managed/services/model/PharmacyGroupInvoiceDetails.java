package com.pps.managed.services.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class PharmacyGroupInvoiceDetails {

	@Id
	@Column(name = "[id]", nullable = false)
	private Long id;
	
	private Long ceid;
	
	@Column(name="PHGroupid")
	private Long phGroupId;

	@Column(name = "[CENAME]", nullable = false)
	private String ceName;
	
	@Column(name="PHGroupName")
	private String phGroupName;

	@Column(name = "[BillingPeriod]", nullable = false)
	private Date billingPeriod;

	@Column(name = "[InvoicePeriodStartDate]", nullable = false)
	private Date invoicePeriodStartDate;

	@Column(name = "[InvoicePeriodEndDate]", nullable = false)
	private Date invoicePeriodEndDate;

	@Column(name = "[TotalInvoiced]", nullable = false)
	private BigDecimal totalInvoiced;

	@Column(name = "[DispensingFee]", nullable = false)
	private BigDecimal dispensingFee;

	@Column(name = "[Trueup]", nullable = false)
	private BigDecimal trueUp;

	@Column(name = "[Storefees]", nullable = false)
	private BigDecimal storeFees;

	@Column(name = "[CETotalReceivedAmount]", nullable = false)
	private BigDecimal ceTotalReceivedAmount;

	@Column(name = "[Direct340BTrxnFee]", nullable = false)
	private BigDecimal direct340BTrxnFee;

	@Column(name = "[TotalRows]", nullable = false)
	private Long totalRows;

}
