package com.pps.managed.services.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "VwRxNumDetailsClaimHistory", schema = "plus")
public class VwRxNumDetailsClaimHistory {
	@Id
	@Column(name = "[id]")
	private Long id;
	
	@Column(name = "[RxNumber]")
	private String rxNumber;
	
	@Column(name = "[Claimid]")
	private Long claimId;
	
	@Column(name = "[RefillNumber]")
	private Long refillNumber;
	
	@Column(name = "[RefillStatus]")
	private String refillStatus;
	
	@Column(name = "[RefillDate]")
	private Date refillDate;
}
