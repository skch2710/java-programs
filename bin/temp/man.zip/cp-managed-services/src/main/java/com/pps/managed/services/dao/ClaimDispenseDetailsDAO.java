package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Sort;

import com.pps.managed.services.model.ClaimDispense;

@Repository
public interface ClaimDispenseDetailsDAO  extends JpaRepository<ClaimDispense, Integer> {
  Page<ClaimDispense> findAll(Specification<ClaimDispense> spec,
      Pageable pageable);

  List<ClaimDispense> findAll(Specification<ClaimDispense> spec, Sort sort);
}
