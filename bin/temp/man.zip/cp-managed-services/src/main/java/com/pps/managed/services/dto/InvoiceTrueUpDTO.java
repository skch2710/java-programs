package com.pps.managed.services.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceTrueUpDTO {

    private Long id;
    private String billingCycle;
    private String tfbID;
    private Long claimId;
    private String processedDate;
    private String rxNumber;
    private String rxWrittenDate;
    private String refillNumber;
    private String dateOfService;
    private String bin;
    private String pcn;
    private String phGroupName;
    private String store;
    private String dispensingStoreNpi;
    private String ndc;
    private String drugName;
    private String brandGenericFlag;
    private String replenishedPercentage;
    private String trueUpUnits;
    private String trueUpAmount;
    private String trueUpReason;
    private String trueUpType;
    private Long totalRows;

}
