package com.pps.managed.services.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class PharmacyInvoiceDetails {

	@Id
	private Long id;
	
	private Long ceid;
	
	@Column(name = "[PHGroupId]")
	private Long phGroupId;
	
	@Column(name="PHID")
	private Long phid;

	@Column(name = "[CENAME]")
	private String ceName;
	
	@Column(name = "[PHGroupName]")
	private String phGroupName;

	@Column(name = "[PHName]")
	private String phName;

	@Column(name = "[BillingPeriod]")
	private Date billingPeriod;

	@Column(name = "[InvoicePeriodStartDate]")
	private Date invoicePeriodStartDate;

	@Column(name = "[InvoicePeriodEndDate]")
	private Date invoicePeriodEndDate;

	@Column(name = "[TotalInvoiced]", nullable = false)
	private BigDecimal totalInvoiced;

	@Column(name = "[DispensingFee]")
	private BigDecimal dispensingFee;

	@Column(name = "[Trueup]")
	private BigDecimal trueUp;

	@Column(name = "[Storefees]")
	private BigDecimal storeFees;

	@Column(name = "[CETotalReceivedAmount]")
	private BigDecimal ceTotalReceivedAmount;

	@Column(name = "[Direct340BTrxnFee]")
	private BigDecimal direct340BTrxnFee;

	@Column(name = "[EstimatedCeSavings]")
	private BigDecimal estimatedCeSavings;

	@Column(name = "[PharmacyPaymentreceived]")
	private BigDecimal pharmacyPaymentReceived;

	@Column(name = "[TfbDirectPlusRemittance]")
	private BigDecimal tfbDirectPlusRemittance;
	
	@Column(name="totalRows")
	private Long totalRows;

}
