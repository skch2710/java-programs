package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class InvoiceReportSearch extends Pagination{
	
	private Long ceid;
	private Long phGroupId;
	private Long phid;
	private String billingPeriod;

}
