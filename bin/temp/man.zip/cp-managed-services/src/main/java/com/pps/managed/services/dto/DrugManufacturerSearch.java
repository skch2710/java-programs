package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DrugManufacturerSearch {
	
	private Long ceID;

	private Long phID;
	
	private Long wholesalerID;

	private String drugManufacturerName;
}
