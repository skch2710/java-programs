package com.pps.managed.services.serviceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.pps.managed.services.common.Constant;
import com.pps.managed.services.dao.PurchaseOrderCategorylkpDAO;
import com.pps.managed.services.dao.PurchaseOrderDAO;
import com.pps.managed.services.dao.PurchaseOrderHistoryDAO;
import com.pps.managed.services.dao.PurchaseOrderPXClaimsDAO;
import com.pps.managed.services.dao.PurchaseOrderStatusDAO;
import com.pps.managed.services.dao.PurchaseOrdersInnerGridDAO;
import com.pps.managed.services.dao.PurchaseOrdersItemHistoryDAO;
import com.pps.managed.services.dto.ColumnFilter;
import com.pps.managed.services.dto.PurchaseOrderCategorylkpDTO;
import com.pps.managed.services.dto.PurchaseOrderDTO;
import com.pps.managed.services.dto.PurchaseOrderHistoryDTO;
import com.pps.managed.services.dto.PurchaseOrderPXClaimDTO;
import com.pps.managed.services.dto.PurchaseOrderPXClaimSearch;
import com.pps.managed.services.dto.PurchaseOrderSearch;
import com.pps.managed.services.dto.PurchaseOrderStatusDTO;
import com.pps.managed.services.dto.PurchaseOrdersInnerGridDTO;
import com.pps.managed.services.dto.PurchaseOrdersInnerGridSearch;
import com.pps.managed.services.dto.PurchaseOrdersItemHistoryDTO;
import com.pps.managed.services.dto.PurchaseOrdersItemHistorySearch;
import com.pps.managed.services.dto.Result;
import com.pps.managed.services.dto.SearchResult;
import com.pps.managed.services.exception.CustomException;
import com.pps.managed.services.mapper.ObjectMapper;
import com.pps.managed.services.model.PurchaseOrder;
import com.pps.managed.services.model.PurchaseOrderHistory;
import com.pps.managed.services.model.PurchaseOrderPxClaim;
import com.pps.managed.services.model.PurchaseOrdersInnerGrid;
import com.pps.managed.services.model.PurchaseOrdersItemHistory;
import com.pps.managed.services.service.PurchaseOrderService;
import com.pps.managed.services.specs.GenericSpecification;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class PurchaseOrderServiceImpl.
 */
@Service

/** The Constant log. */
@Slf4j
public class PurchaseOrderServiceImpl implements PurchaseOrderService {

	/** The mapper. */
	private ObjectMapper MAPPER = ObjectMapper.INSTANCE;

	@Autowired
	private PurchaseOrderStatusDAO purchaseOrderStatusDAO;

	@Autowired
	private PurchaseOrderCategorylkpDAO purchaseOrderCategorylkpDAO;

	@Autowired
	PurchaseOrderPXClaimsDAO purchaseOrderPXClaimsDAO;

	@Autowired
	PurchaseOrdersItemHistoryDAO purchaseOrderItemHistoryDAO;

	@Autowired
	PurchaseOrdersInnerGridDAO purchaseOrdersInnerGridDAO;
	
	@Autowired
	PurchaseOrderDAO purchaseOrderDAO;
	
	@Autowired
	PurchaseOrderHistoryDAO purchaseOrderHistoryDAO;

	/**
	 * Purchse order status.
	 *
	 * @return the result
	 */

	@Override
	public Result getPurchseOrderStatus() {
		Result result = null;
		try {
			List<PurchaseOrderStatusDTO> purchaseOrderStatusDTO = MAPPER
					.fromPurchaseOrderStatusModel(purchaseOrderStatusDAO.findAll());
			result = new Result(purchaseOrderStatusDTO);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting all purchaseOrderStatus Data");
		} catch (Exception e) {
			log.error("Error in searchOrderStatus :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Gets the Purchase order category by Purchase order category.
	 *
	 * @return the Purchase order category by Purchase order category
	 */
	@Override
	public Result getPOorderCriteria() {
		Result result = null;
		try {
			List<PurchaseOrderCategorylkpDTO> purchaseOrderCategorylkpDTOs = MAPPER
					.frompurchasecategory(purchaseOrderCategorylkpDAO.findAll());
			result = new Result(purchaseOrderCategorylkpDTOs);
			result.setStatusCode(HttpStatus.OK.value());
			result.setSuccessMessage("getting purchaseOrderCategorylkpDetails");
		} catch (Exception e) {
			log.error("Error in purchaseOrderCategorylkpDetails :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	@Override
	public Result getPurchaseOrderPXClaims(PurchaseOrderPXClaimSearch purchaseOrderPXClaimSearch) {
		Result result = null;
		try {
			Map<String, Object> filters = null;
			Map<String, Map<String, Object>> dynamicFilters = new HashMap<String, Map<String, Object>>();
			if (purchaseOrderPXClaimSearch.getFilter() != null) {
				GenericSpecification.dynamicFilters(purchaseOrderPXClaimSearch.getFilter(), dynamicFilters);
			}
			if (purchaseOrderPXClaimSearch.getSortBy() == null
					|| "".equalsIgnoreCase(purchaseOrderPXClaimSearch.getSortBy())) {
				purchaseOrderPXClaimSearch.setSortBy(Constant.PO_ID);
			}

			if (purchaseOrderPXClaimSearch.getPoID() != null && purchaseOrderPXClaimSearch.getPoID() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, purchaseOrderPXClaimSearch.getPoID());
				dynamicFilters.put(Constant.PO_ID, filters);
			}

			if (purchaseOrderPXClaimSearch.getPoItemID() != null && purchaseOrderPXClaimSearch.getPoItemID() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, purchaseOrderPXClaimSearch.getPoItemID());
				dynamicFilters.put(Constant.PO_ITEM_ID, filters);
			}
		
			result = new Result();
			if (!purchaseOrderPXClaimSearch.isExport()) {
				Page<PurchaseOrderPxClaim> pageResult = this.purchaseOrderPXClaimsDAO.findAll(
						GenericSpecification.getSpecification(dynamicFilters),
						GenericSpecification.getPagination(purchaseOrderPXClaimSearch));
				SearchResult<PurchaseOrderPXClaimDTO> searchResult = GenericSpecification
						.getPaginationDetails(pageResult, PurchaseOrderPXClaimDTO.class);
				List<PurchaseOrderPXClaimDTO> purchaseOrderPXClaimDTOs = MAPPER
						.fromPurchaseOrderPXClaimModel(pageResult.getContent());
				searchResult.setContent(purchaseOrderPXClaimDTOs);
				result.setData(searchResult);
				if (purchaseOrderPXClaimDTOs.size() == 0) {
					result.setStatusCode(HttpStatus.NOT_FOUND.value());
					result.setErrorMessage("No Result Found");
				} else {
					result.setStatusCode(HttpStatus.OK.value());
					result.setSuccessMessage(
							"Fetching all purchase Order PX claim details based on the purchase Order ID");
				}
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setData(exportPOPXClaimsData(purchaseOrderPXClaimSearch, dynamicFilters));
		}
		}catch (Exception e) {
			log.error("Error in getPurchseOrderPXClaims :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}
	private SearchResult<PurchaseOrderPXClaimDTO> exportPOPXClaimsData(
			PurchaseOrderPXClaimSearch purchaseOrderPXClaimSearch, Map<String, Map<String, Object>> dynamicFilters) {
		SearchResult<PurchaseOrderPXClaimDTO> searchResult = new SearchResult<>();
		try {
			List<PurchaseOrderPxClaim> sortResult = this.purchaseOrderPXClaimsDAO.findAll(
					GenericSpecification.getSpecification(dynamicFilters),
					GenericSpecification.getSort(purchaseOrderPXClaimSearch));

			List<PurchaseOrderPXClaimDTO> purchaseOrderPXClaimDTOs = MAPPER.fromPurchaseOrderPXClaimModel(sortResult);
			searchResult.setContent(purchaseOrderPXClaimDTOs);
			searchResult.setTotalElements(purchaseOrderPXClaimDTOs.size());
		} catch (Exception e) {
			log.error("Error in exportPOPXClaimsData :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return searchResult;
	}

	@Override
	public Result searchPurchaseOrdersItemHistory(PurchaseOrdersItemHistorySearch purchaseOrdersItemHistorySearch) {
		Result result = null;
		try {
			Map<String, Object> filters = null;
			Map<String, Map<String, Object>> dynamicFilters = new HashMap<String, Map<String, Object>>();
			if (purchaseOrdersItemHistorySearch.getFilter() != null) {
				GenericSpecification.dynamicFilters(purchaseOrdersItemHistorySearch.getFilter(), dynamicFilters);
			}
			if (purchaseOrdersItemHistorySearch.getSortBy() == null
					|| "".equalsIgnoreCase(purchaseOrdersItemHistorySearch.getSortBy())) {
				purchaseOrdersItemHistorySearch.setSortBy(Constant.PO_ID);
			}

			if (purchaseOrdersItemHistorySearch.getPoID() != null && purchaseOrdersItemHistorySearch.getPoID() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, purchaseOrdersItemHistorySearch.getPoID());
				dynamicFilters.put(Constant.PO_ID, filters);
			}
			if (purchaseOrdersItemHistorySearch.getPoItemID() != null
					&& purchaseOrdersItemHistorySearch.getPoItemID() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, purchaseOrdersItemHistorySearch.getPoItemID());
				dynamicFilters.put(Constant.PO_ITEM_ID, filters);
			}
			
			result = new Result();
			if (!purchaseOrdersItemHistorySearch.isExport()) {
				Page<PurchaseOrdersItemHistory> pageResult = this.purchaseOrderItemHistoryDAO.findAll(
						GenericSpecification.getSpecification(dynamicFilters),
						GenericSpecification.getPagination(purchaseOrdersItemHistorySearch));
				SearchResult<PurchaseOrdersItemHistoryDTO> searchResult = GenericSpecification
						.getPaginationDetails(pageResult, PurchaseOrdersItemHistoryDTO.class);
				List<PurchaseOrdersItemHistoryDTO> purchaseOrdersItemHistoryDTOs = MAPPER
						.fromPurchaseOrdersItemHistoryModel(pageResult.getContent());
				searchResult.setContent(purchaseOrdersItemHistoryDTOs);
				result.setData(searchResult);
				if (purchaseOrdersItemHistoryDTOs.size() == 0) {
					result.setStatusCode(HttpStatus.NOT_FOUND.value());
					result.setErrorMessage("No Result Found");
				} else {
					result.setStatusCode(HttpStatus.OK.value());
					result.setSuccessMessage(
							"Fetching all purchase Orders Item History details based on the selected filters");
				}
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setData(exportPurchaseItemData(purchaseOrdersItemHistorySearch, dynamicFilters));
			}
		} catch (Exception e) {
			log.error("Error in searchPurchaseOrders :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	private Object exportPurchaseItemData(PurchaseOrdersItemHistorySearch purchaseOrdersItemHistorySearch,
			Map<String, Map<String, Object>> dynamicFilters) {
		SearchResult<PurchaseOrdersItemHistoryDTO> searchPOResult = new SearchResult<>();

		try {
			List<PurchaseOrdersItemHistory> itemHistoryResult = this.purchaseOrderItemHistoryDAO.findAll(
					GenericSpecification.getSpecification(dynamicFilters),
					GenericSpecification.getSort(purchaseOrdersItemHistorySearch));

			List<PurchaseOrdersItemHistoryDTO> purchaseOrdersItemHistoryDTOs = MAPPER
					.fromPurchaseOrdersItemHistoryModel(itemHistoryResult);
			searchPOResult.setContent(purchaseOrdersItemHistoryDTOs);
		} catch (Exception e) {
			log.error("Error in  exportPurchaseItemData :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return searchPOResult;

	}

	/**
	 * Search purchase orders inner grid.
	 *
	 * @param purchaseOrdersInnerGridSearch the purchase orders inner grid search
	 * @return the result
	 */
	@Override
	public Result searchPurchaseOrdersInnerGrid(PurchaseOrdersInnerGridSearch purchaseOrdersInnerGridSearch) {

		Result result = null;
		try {
			Map<String, Object> filters = null;
			Map<String, Map<String, Object>> dynamicFilters = new HashMap<String, Map<String, Object>>();
			if (purchaseOrdersInnerGridSearch.getSortBy() == null
					|| "".equalsIgnoreCase(purchaseOrdersInnerGridSearch.getSortBy())) {
				purchaseOrdersInnerGridSearch.setSortBy(Constant.NDC);
			}

			if (purchaseOrdersInnerGridSearch.getPoID() != null && purchaseOrdersInnerGridSearch.getPoID() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, purchaseOrdersInnerGridSearch.getPoID());
				dynamicFilters.put(Constant.PO_ID, filters);
			}

			if (purchaseOrdersInnerGridSearch.getFilter() != null) {
				GenericSpecification.dynamicFilters(purchaseOrdersInnerGridSearch.getFilter(), dynamicFilters);
			}
			result = new Result();
			if (!purchaseOrdersInnerGridSearch.isExport()) {
				Page<PurchaseOrdersInnerGrid> pageResult = this.purchaseOrdersInnerGridDAO.findAll(
						GenericSpecification.getSpecification(dynamicFilters),
						GenericSpecification.getPagination(purchaseOrdersInnerGridSearch));
				SearchResult<PurchaseOrdersInnerGridDTO> searchResult = GenericSpecification
						.getPaginationDetails(pageResult, PurchaseOrdersInnerGridDTO.class);
				List<PurchaseOrdersInnerGridDTO> purchaseOrdersInnerGridDTOs = MAPPER
						.fromPurchaseOrdersInnerGridModel(pageResult.getContent());
				searchResult.setContent(purchaseOrdersInnerGridDTOs);
				result.setData(searchResult);
				if (purchaseOrdersInnerGridDTOs.size() == 0) {
					result.setStatusCode(HttpStatus.NOT_FOUND.value());
					result.setErrorMessage("No Result Found");
				} else {
					result.setStatusCode(HttpStatus.OK.value());
					result.setSuccessMessage(
							"Fetching all purchase Orders Inner Grid details based on the selected filters");
				}
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setData(exportData(purchaseOrdersInnerGridSearch, dynamicFilters));
			}
		} catch (Exception e) {
			log.error("Error in searchPurchaseOrdersInnerGrid :: ", e);
		}
		return result;
	}

	@Override
	public Result searchPurchaseOrder(PurchaseOrderSearch purchaseOrderSearch) {
		log.debug("inside in searchPurchaseOrder :: ");
		Result result = null;
		try {
			if (purchaseOrderSearch.getSortBy() == null || "".equalsIgnoreCase(purchaseOrderSearch.getSortBy())) {
				purchaseOrderSearch.setSortBy(Constant.PO_ID);
			}
			if (purchaseOrderSearch.getSortOrder() == null || "".equalsIgnoreCase(purchaseOrderSearch.getSortOrder())) {
				purchaseOrderSearch.setSortOrder("asc");
			}
			purchaseOrderSearch.setNotOrderFlag("N");
			purchaseOrderSearch.setStalledOrderFlag("N");
			purchaseOrderSearch.setProductReturnFlag("N");
			purchaseOrderSearch.setManualOrdersFlag("N");

			if (purchaseOrderSearch.getAddPOStatusID() != null && purchaseOrderSearch.getAddPOStatusID().length() > 0) {
				if (purchaseOrderSearch.getAddPOStatusID().equals("1")) {
					purchaseOrderSearch.setNotOrderFlag("Y");
				} else if (purchaseOrderSearch.getAddPOStatusID().equals("2")) {
					purchaseOrderSearch.setStalledOrderFlag("Y");
				} else if (purchaseOrderSearch.getAddPOStatusID().equals("3")) {
					purchaseOrderSearch.setProductReturnFlag("Y");
				} else if (purchaseOrderSearch.getAddPOStatusID().equals("4")) {
					purchaseOrderSearch.setManualOrdersFlag("Y");
				}

			}
			String poNumber = "";
			String poDate = "";
			String phName = "";
			String wholesalerAccNo = "";
			String wholesalerName = "";
			String poStatus = "";
			String poTotalOrderAmt = "";
			String poTotalBilledAmt = "";
			if (purchaseOrderSearch.getFilter() != null) {
				for (ColumnFilter columnFilter :purchaseOrderSearch.getFilter()) {
					if(columnFilter.getColumn().getField().equals(Constant.PO_ID)) {
						poNumber = columnFilter.getValue();
					} else if(columnFilter.getColumn().getField().equals(Constant.PO_DATE)) {
						poDate = columnFilter.getValue();
					} else if(columnFilter.getColumn().getField().equals(Constant.PH_NAME)) {
						phName = columnFilter.getValue();
					} else if(columnFilter.getColumn().getField().equals(Constant.WHOLESALER_ACC_NO)) {
						wholesalerAccNo = columnFilter.getValue();
					} else if(columnFilter.getColumn().getField().equals(Constant.WHOLESALER_NAME)) {
						wholesalerName = columnFilter.getValue();
					} else if(columnFilter.getColumn().getField().equals(Constant.PO_STATUS)) {
						poStatus = columnFilter.getValue();
					} else if(columnFilter.getColumn().getField().equals(Constant.PO_TOTAL_ORDER_AMT)) {
						poTotalOrderAmt = columnFilter.getValue();
					} else if(columnFilter.getColumn().getField().equals(Constant.PO_TOTAL_BILLER_AMT)) {
						poTotalBilledAmt = columnFilter.getValue();
					}
				}
			}
			result = new Result();
			List<PurchaseOrder> purchaseOrders = purchaseOrderDAO.getPODetails(
					StringUtils.join(purchaseOrderSearch.getCeID(), ","), purchaseOrderSearch.getPhID(),
					purchaseOrderSearch.getPhGroupId(), purchaseOrderSearch.getWholesalerID(),
					StringUtils.join(purchaseOrderSearch.getDrugManufacturerID(), ","), purchaseOrderSearch.getPoStatusID(),
					purchaseOrderSearch.getReatil304BOrderID(), purchaseOrderSearch.getPo(),
					purchaseOrderSearch.getPoCatergoryID(), purchaseOrderSearch.getInvoiceNumber(),
					purchaseOrderSearch.getNdc(), StringUtils.join(purchaseOrderSearch.getDrugDEAClassID(), ","),
					purchaseOrderSearch.getPoSearchCriteria(), purchaseOrderSearch.getYear(),
					purchaseOrderSearch.getPoStartDate(), purchaseOrderSearch.getPoEndDate(),
					purchaseOrderSearch.getNotOrderFlag(), purchaseOrderSearch.getStalledOrderFlag(),
					purchaseOrderSearch.getProductReturnFlag(), purchaseOrderSearch.getManualOrdersFlag(),
					purchaseOrderSearch.getQuarter(), purchaseOrderSearch.getMonth(),
					purchaseOrderSearch.getPoDateFilter(), purchaseOrderSearch.getPageNumber(),
					purchaseOrderSearch.getPageSize(), purchaseOrderSearch.getSortBy(),
					purchaseOrderSearch.getSortOrder(), purchaseOrderSearch.isExport() ? "T" : "F"
					, poNumber, poDate	, phName, wholesalerAccNo, wholesalerName, poStatus, poTotalOrderAmt, poTotalBilledAmt 
					);
			List<PurchaseOrderDTO> purchaseOrderDTOs = MAPPER.fromPurchaseOrderModel(purchaseOrders);
			SearchResult<PurchaseOrderDTO> searchResult = new SearchResult<>();
			searchResult.setContent(purchaseOrderDTOs);
			searchResult.setPageNo(purchaseOrderSearch.getPageNumber());
			searchResult.setPageSize(purchaseOrderSearch.getPageSize());
			if (purchaseOrderDTOs.size() > 0) {
				searchResult.setTotalElements(purchaseOrders.get(0).getTotalRows());
			}
			result.setData(searchResult);
			if (purchaseOrderDTOs.size() == 0) {
				result.setStatusCode(HttpStatus.NOT_FOUND.value());
				result.setErrorMessage("No Result Found");
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setSuccessMessage("Fetching all purchase orders details based on the selected filters");
			}
		} catch (Exception e) {
			log.error("Error in searchPurchaseOrder :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Export data.
	 *
	 * @param purchaseOrdersInnerGridSearch the purchase orders inner grid search
	 * @param dynamicFilters                the dynamic filters
	 * @return the search result
	 */
	private SearchResult<PurchaseOrdersInnerGridDTO> exportData(
			PurchaseOrdersInnerGridSearch purchaseOrdersInnerGridSearch,
			Map<String, Map<String, Object>> dynamicFilters) {
		SearchResult<PurchaseOrdersInnerGridDTO> searchResult = new SearchResult<>();
		try {
			List<PurchaseOrdersInnerGrid> sortResult = this.purchaseOrdersInnerGridDAO.findAll(
					GenericSpecification.getSpecification(dynamicFilters),
					GenericSpecification.getSort(purchaseOrdersInnerGridSearch));

			List<PurchaseOrdersInnerGridDTO> purchaseOrdersInnerGridDTOs = MAPPER
					.fromPurchaseOrdersInnerGridModel(sortResult);
			searchResult.setContent(purchaseOrdersInnerGridDTOs);
		} catch (Exception e) {
			log.error("Error in exportData :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return searchResult;

	}
	
	 @Override
	  public Result getPurchseOrderHistory(PurchaseOrdersInnerGridSearch purchaseOrdersInnerGridSearch) {
	   
	    Result result = null;
	  
	    try {
	      Map<String, Object> filters = null;
	      Map<String, Map<String, Object>> dynamicFilters = new HashMap<String, Map<String, Object>>();
	      if (purchaseOrdersInnerGridSearch.getSortBy() == null
	          || "".equalsIgnoreCase(purchaseOrdersInnerGridSearch.getSortBy())) {
	        purchaseOrdersInnerGridSearch.setSortBy(Constant.PO_LOG_ID);
	      }

	      if (purchaseOrdersInnerGridSearch.getPoID() != null
	          && purchaseOrdersInnerGridSearch.getPoID() > 0) {
	        filters = new HashMap<String, Object>();
	        filters.put(Constant.EQUALS, purchaseOrdersInnerGridSearch.getPoID());
	        dynamicFilters.put(Constant.PO_ID, filters);
	      }
	      if (purchaseOrdersInnerGridSearch.getFilter() != null) {
		        GenericSpecification.dynamicFilters(purchaseOrdersInnerGridSearch.getFilter(),
		            dynamicFilters);
		      }
	      result = new Result();
	      if (!purchaseOrdersInnerGridSearch.isExport()) {
	        Page<PurchaseOrderHistory> pageResult = this.purchaseOrderHistoryDAO.findAll(
	            GenericSpecification.getSpecification(dynamicFilters),
	            GenericSpecification.getPagination(purchaseOrdersInnerGridSearch));
	        SearchResult<PurchaseOrderHistoryDTO> searchResult =
	            GenericSpecification.getPaginationDetails(pageResult, PurchaseOrderHistoryDTO.class);
	        List<PurchaseOrderHistoryDTO> purchaseOrdersInnerGridDTOs =
	            MAPPER.fromPurchaseOrderHistoryModel(pageResult.getContent());
	        searchResult.setContent(purchaseOrdersInnerGridDTOs);
	        result.setData(searchResult);
	        if (purchaseOrdersInnerGridDTOs.size() == 0) {
	          result.setStatusCode(HttpStatus.NOT_FOUND.value());
	          result.setErrorMessage("No Result Found");
	        } else {
	          result.setStatusCode(HttpStatus.OK.value());
	          result.setSuccessMessage(
	              "Fetching all purchase Order History details based on the purchase Order ID");
	        }
	      } else {
	        result.setStatusCode(HttpStatus.OK.value());
	        result.setData(exportPOHistoryData(purchaseOrdersInnerGridSearch, dynamicFilters));
	      }
	    } catch (Exception e) {
	      log.error("Error in getPurchseOrderHistory :: ", e);
	      throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    return result;
	  }
	   
	  /**
	   * Export PO history data.
	   *
	   * @param purchaseOrdersInnerGridSearch the purchase orders inner grid search
	   * @param dynamicFilters the dynamic filters
	   * @return the search result
	   */
	  private SearchResult<PurchaseOrderHistoryDTO> exportPOHistoryData(
	      PurchaseOrdersInnerGridSearch purchaseOrdersInnerGridSearch,
	      Map<String, Map<String, Object>> dynamicFilters) {
	    SearchResult<PurchaseOrderHistoryDTO> searchResult = new SearchResult<>();
	    try {
	      List<PurchaseOrderHistory> sortResult = this.purchaseOrderHistoryDAO.findAll(
	          GenericSpecification.getSpecification(dynamicFilters),
	          GenericSpecification.getSort(purchaseOrdersInnerGridSearch));

	      List<PurchaseOrderHistoryDTO> purchaseOrderHistoryDTOs =
	          MAPPER.fromPurchaseOrderHistoryModel(sortResult);
	      searchResult.setContent(purchaseOrderHistoryDTOs);
	      searchResult.setTotalElements(purchaseOrderHistoryDTOs.size());
	    } catch (Exception e) {
	      log.error("Error in exportPOHistoryData :: ", e);
	      throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	    return searchResult;
	  }

}