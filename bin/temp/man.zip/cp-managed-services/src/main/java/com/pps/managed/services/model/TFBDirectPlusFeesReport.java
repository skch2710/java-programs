package com.pps.managed.services.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="Vw340BDirectPlusFeesReport",schema="Plus")
public class TFBDirectPlusFeesReport {
	
	@Id
	private Long id;
	
	private Long ceid;
	
	private Long phid;
	
	@Column(name="phgroupid")
	private Long phGroupId;
	
	@Column(name="CeName")
	private String ceName;
	
	@Column(name="AdminHRSAID")
	private String adminHrsaId;
	
	@Column(name="340Direct+Fees")
	private BigDecimal tfbDirectPlusFees;
	
	@Column(name="duedate")
	private Date dueDate;
	
	@Column(name="StartDate")
	private Date startDate;
	
	@Column(name="EndDate")
	private Date endDate;
	
	@Column(name="BillingPeriod")
	private Date billingPeriod;
	
}
