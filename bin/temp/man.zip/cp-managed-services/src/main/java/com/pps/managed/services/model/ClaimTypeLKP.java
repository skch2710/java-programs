package com.pps.managed.services.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "VwClaimTypeLKP", schema = "plus")
public class ClaimTypeLKP {

	@Id
	@Column(name = "[ClaimTypeId]")
	private Long claimTypeId;

	@Column(name = "[ClaimTypeCode]")
	private String claimTypeCode;

	@Column(name = "[ClaimType]")
	private String claimType;
}
	
