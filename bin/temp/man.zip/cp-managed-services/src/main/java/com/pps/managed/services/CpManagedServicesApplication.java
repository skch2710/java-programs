package com.pps.managed.services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.servers.Server;

@SpringBootApplication
@ComponentScan("com.pps.managed.services")
@OpenAPIDefinition(servers = {@Server(url = "${app.url}", description = "Default Server URL")},info = @Info(title = "managed Services APIs", version = "1.0", description = "Shows all managed Services APIs Information"))
@SecurityScheme(
	    name = "bearerAuth",
	    type = SecuritySchemeType.HTTP,
	    bearerFormat = "JWT",
	    scheme = "bearer"
	)
public class CpManagedServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CpManagedServicesApplication.class, args);
	}

}
