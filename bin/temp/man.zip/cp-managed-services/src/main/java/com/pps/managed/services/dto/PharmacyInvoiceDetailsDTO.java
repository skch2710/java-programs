package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PharmacyInvoiceDetailsDTO {

	private Long id;
	private Long ceid;
	private Long phGroupId;
	private Long phid;
	private String ceName;
	private String phGroupName;
	private String phName;
	private String billingPeriod;
	private String invoicePeriodStartDate;
	private String invoicePeriodEndDate;
	private String totalInvoiced;
	private String dispensingFee;
	private String trueUp;
	private String storeFees;
	private String ceTotalReceivedAmount;
	private String direct340BTrxnFee;
	private String estimatedCeSavings;
	private String pharmacyPaymentReceived;
	private String tfbDirectPlusRemittance;

}
