package com.pps.managed.services.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrderSearch extends Pagination {

  private List<Long> ceID;
  private String po;
  private Long phID;
  private Long wholesalerID;
  private List<Long> drugDEAClassID;
  private Long poStatusID;
  private Long reatil304BOrderID;
  private String ndc;
  private String invoiceNumber;
  private String creditInvoiceNumber;
  private String poSearchCriteria;
  private Integer year;
  private String poDateFilter;
  private String poStartDate;
  private String poEndDate;
  private String notOrderFlag;
  private String stalledOrderFlag;
  private String productReturnFlag;
  private String manualOrdersFlag;
  private String addPOStatusID;
  private Integer quarter;
  private Integer month;
  private Long phGroupId;
  private List<Long> drugManufacturerID;
  private Integer poCatergoryID;
}
