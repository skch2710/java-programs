package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PhInvoiceReportDTO {

	private Long claimId;
	private String processedDate;
	private String rxNumber;
	private String rxWrittenDate;
	private String refillHash;
	private String dateOfService;
	private String tfbId;
	private String coveredEntity;
	private String memberFirstName;
	private String memberLastName;
	private String memberId;
	private String patientVisitDate;
	private String patientSlidingScale;
	private String physicianFirstName;
	private String physicianLastName;
	private Long prescriberId;
	private String store;
	private String ncpdp;
	private String npi;
	private String ndc11;
	private String drugName;
	private String indicator;
	private String qtyDisp;
	private String daysSupply;
	private String bin;
	private String pcn;
	private String groupNumber;
	private Long personType;
	private String patientPay;
	private Long thirdPartPayment;
	private String cePlanSubsidy;
	private Long totalPayment;
	private Long insuredPatientCost;
	private Long unInsuredPatientCost;
	private String grossDispensingFee;
	private String programAdminFee;
	private String tfbIngredientCost;
	private Long totalClaimCost;
	private String totalCeReceivable;
	private String claimProfitOrLoss;
	private String reversed;
	private Long poNumber;
	private Long carveInClaimId;
	private String cEReimbursementModel;
	private String eac;
	private String memberDateOfBirth;
	private String startDate;
	private String endDate;
	private Long ceid;
	private Long phGroupId;
	private Long phid;
	private String billingPeriod;

}
