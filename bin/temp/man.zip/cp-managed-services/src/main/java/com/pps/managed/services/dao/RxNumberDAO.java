package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.RxNumberLkp;

@Repository
public interface RxNumberDAO extends JpaRepository<RxNumberLkp, Long> {

	@Query(value = "EXEC [Plus].[GetRxNumberFilter] @ceid=:ceID,@Rxnumber=:rxNumber", nativeQuery = true)
	List<RxNumberLkp> getRxNumberDetails(@Param("ceID") Long ceID, @Param("rxNumber") String rxNumber);

}
