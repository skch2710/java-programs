package com.pps.managed.services.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class InvoiceSearch extends Pagination {

	private List<Long> ceId;
	private Long phId;
	private Long phGroupId;
	private String invoicePeriodStartDate;
	private String invoicePeriodEndDate;
	private String billPeriod;
}
