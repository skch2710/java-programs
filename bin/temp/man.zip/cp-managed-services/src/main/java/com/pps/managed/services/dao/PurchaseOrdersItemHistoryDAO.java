package com.pps.managed.services.dao;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.PurchaseOrdersItemHistory;

@Repository
public interface PurchaseOrdersItemHistoryDAO extends JpaRepository<PurchaseOrdersItemHistory, Long> {
	  Page<PurchaseOrdersItemHistory> findAll(Specification<PurchaseOrdersItemHistory> spec,
	      Pageable pageable);
	  List<PurchaseOrdersItemHistory> findAll(Specification<PurchaseOrdersItemHistory> spec, Sort sort);
	}

