package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pps.managed.services.model.InvoiceRemittance;

public interface InvoiceRemittanceDAO extends JpaRepository<InvoiceRemittance, Long> {

	@Query(value = "Exec Plus.UspInvoiceRemittanceSummary @In_Ceid=:ceid,@In_phgroupid =:phGroupId,@In_PhId=:phId, @In_StartPeriod=:startDate,@In_EndPeriod=:endDate,@In_SortColumn=:sortBy, @In_SortDirection=:sortOrder, @In_PageNumber=:pageNumber,@In_PageSize=:pageSize, @In_IsExport=:export", nativeQuery = true)
	List<InvoiceRemittance> getInvoiceRemittanceDetails(@Param("ceid") Long ceid, @Param("phGroupId") Long phGroupId, @Param("phId") Long phId, @Param("startDate") String startDate,
			@Param("endDate") String endDate, @Param("sortBy") String sortBy, @Param("sortOrder") String sortOrder,
			@Param("pageNumber") Integer pageNumber, @Param("pageSize") Integer pageSize,
			@Param("export") Boolean export);
}
