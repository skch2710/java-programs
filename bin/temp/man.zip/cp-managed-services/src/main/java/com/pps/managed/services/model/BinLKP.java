package com.pps.managed.services.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Data;

@Entity
@Data
@Table(name = "BIN", schema = "dbo")
public class BinLKP {

	@Id
	@Column(name = "[BINID]")
	private Long binID;

	@Column(name = "[BINNumber]")
	private String binNumber;

	@Column(name = "[BINName]")
	private String binName;

	@Column(name = "[InactiveFlag]")
	private String inactiveFlag;

	@Column(name = "[CreatedByID]")
	private String createdByID;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "[CreatedDate]")
	private Date createdDate;

	@Column(name = "[ModifiedByID]")
	private Long modifiedByID;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "[ModifiedDate]")
	private Date modifiedDate;

}
