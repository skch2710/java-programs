package com.pps.managed.services.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VwRxNumDetailsClaimHistoryDTO {
	private String RxNumber;
	private Long claimId;
	private Long RefillNumber;
	private String RefillStatus;
	private String RefillDate;
	
}
