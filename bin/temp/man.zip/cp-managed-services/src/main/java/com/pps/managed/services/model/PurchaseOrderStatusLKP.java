package com.pps.managed.services.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "Purchase_Order_Status_LKP", schema = "dbo")

public class PurchaseOrderStatusLKP { 
	
    @Id
	@Column(name = "POStatusID")
	private Long poStatusID;

	@Column(name = "POStatusCode")
	private String poStatusCode;

	@Column(name = "POStatus")
	private String poStatus;

	@Column(name = "InactiveFlag")
	private String inactiveFlag;

	@Column(name = "CreatedByID")
	private Long createdByID;

	@Column(name = "CreatedDate")
	private Date createdDate;

	@Column(name = "ModifiedByID")
	private Long modifiedByID;

	@Column(name = "ModifiedDate")
	private Date modifiedDate;
}
