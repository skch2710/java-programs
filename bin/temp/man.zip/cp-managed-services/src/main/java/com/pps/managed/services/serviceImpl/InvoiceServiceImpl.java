package com.pps.managed.services.serviceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.pps.managed.services.common.Constant;
import com.pps.managed.services.dao.CERemittanceTotalsDAO;
import com.pps.managed.services.dao.InvoiceClaimDAO;
import com.pps.managed.services.dao.InvoiceRemittanceDAO;
import com.pps.managed.services.dao.InvoiceTrueUpDAO;
import com.pps.managed.services.dao.InvoicesMainGridDAO;
import com.pps.managed.services.dao.PhInvoiceReportDAO;
import com.pps.managed.services.dao.PharmacyGroupInvoiceDeatailsDAO;
import com.pps.managed.services.dao.PharmacyInvoiceDetailsDAO;
import com.pps.managed.services.dao.TFBDirectPlusFeesReportDAO;
import com.pps.managed.services.dao.TrueUpReportPopupDAO;
import com.pps.managed.services.dto.CERemittanceTotalsDTO;
import com.pps.managed.services.dto.CERemittanceTotalsSearch;
import com.pps.managed.services.dto.ColumnFilter;
import com.pps.managed.services.dto.InvoiceClaimDTO;
import com.pps.managed.services.dto.InvoiceClaimSearch;
import com.pps.managed.services.dto.InvoiceRemittanceDTO;
import com.pps.managed.services.dto.InvoiceRemittanceSearch;
import com.pps.managed.services.dto.InvoiceReportSearch;
import com.pps.managed.services.dto.InvoiceSearch;
import com.pps.managed.services.dto.InvoiceTrueUpDTO;
import com.pps.managed.services.dto.InvoiceTrueUpSearch;
import com.pps.managed.services.dto.InvoicesMainGridDTO;
import com.pps.managed.services.dto.PhInvoiceReportDTO;
import com.pps.managed.services.dto.PharmacyGroupInvoiceDetailsDTO;
import com.pps.managed.services.dto.PharmacyInvoiceDetailsDTO;
import com.pps.managed.services.dto.Result;
import com.pps.managed.services.dto.SearchResult;
import com.pps.managed.services.dto.TFBDirectPlusFeesReportDTO;
import com.pps.managed.services.dto.TrueUpReportPopupDTO;
import com.pps.managed.services.exception.CustomException;
import com.pps.managed.services.mapper.ObjectMapper;
import com.pps.managed.services.model.CERemittanceTotals;
import com.pps.managed.services.model.InvoiceClaim;
import com.pps.managed.services.model.InvoiceRemittance;
import com.pps.managed.services.model.InvoiceTrueUp;
import com.pps.managed.services.model.InvoicesMainGrid;
import com.pps.managed.services.model.PhInvoiceReport;
import com.pps.managed.services.model.PharmacyGroupInvoiceDetails;
import com.pps.managed.services.model.PharmacyInvoiceDetails;
import com.pps.managed.services.model.TFBDirectPlusFeesReport;
import com.pps.managed.services.model.TrueUpReportPopup;
import com.pps.managed.services.service.InvoiceService;
import com.pps.managed.services.specs.GenericSpecification;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class InventoryServiceImpl.
 */
@Service

/** The Constant log. */
@Slf4j
public class InvoiceServiceImpl implements InvoiceService {

	/** The mapper. */
	private ObjectMapper MAPPER = ObjectMapper.INSTANCE;

	@Autowired
	private PhInvoiceReportDAO phInvoiceReportDAO;

	@Autowired
	private TrueUpReportPopupDAO trueUpReportPopupDAO;

	@Autowired
	private TFBDirectPlusFeesReportDAO tfbDirectPlusFeesReportDAO;

	@Autowired
	private InvoicesMainGridDAO invoicesMainGridDAO;

	@Autowired
	private PharmacyInvoiceDetailsDAO pharmacyInvoiceDetailsDAO;

	@Autowired
	private PharmacyGroupInvoiceDeatailsDAO pharmacyGroupInvoiceDeatailsDAO;
	
	@Autowired
	InvoiceClaimDAO invoiceClaimDAO;
	@Autowired
	private InvoiceRemittanceDAO invoiceRemittanceDAO;
	
	@Autowired
	private CERemittanceTotalsDAO ceRemittanceTotalsDAO;

	@Autowired
	InvoiceTrueUpDAO invoiceTrueUpDAO;
	/**
	 * Gets the PharmacyInvoiceDetails
	 *
	 * @param InvoiceReportSearch invoiceReportSearch
	 * @return the phInvoiceReport
	 */
	@Override
	public Result getPharmacyInvoiceDetails(InvoiceReportSearch invoiceReportSearch) {

		Result result = null;
		try {

			Map<String, Object> filters = null;
			Map<String, Map<String, Object>> dynamicFilters = new HashMap<String, Map<String, Object>>();
			if (invoiceReportSearch.getSortBy() == null || "".equalsIgnoreCase(invoiceReportSearch.getSortBy())) {
				invoiceReportSearch.setSortBy(Constant.CLAIMID);
			}

			if (invoiceReportSearch.getCeid() != null && invoiceReportSearch.getCeid() > 0
					&& invoiceReportSearch.getCeid() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getCeid());
				dynamicFilters.put(Constant.CE_ID, filters);
			}

			if (invoiceReportSearch.getPhid() != null && invoiceReportSearch.getPhid() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getPhid());
				dynamicFilters.put(Constant.PHID, filters);
			}

			if (invoiceReportSearch.getPhGroupId() != null && invoiceReportSearch.getPhGroupId() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getPhGroupId());
				dynamicFilters.put(Constant.PH_GROUP_ID, filters);
			}

			if (invoiceReportSearch.getBillingPeriod() != null && !"".equalsIgnoreCase(invoiceReportSearch.getBillingPeriod())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getBillingPeriod());
				dynamicFilters.put(Constant.BILLING_PERIOD, filters);
			}

			if (invoiceReportSearch.getFilter() != null) {
				GenericSpecification.dynamicFilters(invoiceReportSearch.getFilter(), dynamicFilters);
			}
			result = new Result();
			if (!invoiceReportSearch.isExport()) {
				Page<PhInvoiceReport> pageResult = this.phInvoiceReportDAO.findAll(
						GenericSpecification.getSpecification(dynamicFilters),
						GenericSpecification.getPagination(invoiceReportSearch));
				SearchResult<PhInvoiceReportDTO> searchResult = GenericSpecification.getPaginationDetails(pageResult,
						PhInvoiceReportDTO.class);
				List<PhInvoiceReportDTO> purchaseOrdersInnerGridDTOs = MAPPER
						.fromPhInvoiceReportModel(pageResult.getContent());
				searchResult.setContent(purchaseOrdersInnerGridDTOs);
				result.setData(searchResult);
				if (purchaseOrdersInnerGridDTOs.size() == 0) {
					result.setStatusCode(HttpStatus.NOT_FOUND.value());
					result.setErrorMessage("No Result Found");
				} else {
					result.setStatusCode(HttpStatus.OK.value());
					result.setSuccessMessage(
							"Fetching all Pharmacy Invoice report Inner Grid Popup details based on the selected filters");
				}
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setData(exportData(invoiceReportSearch, dynamicFilters));
			}
		} catch (Exception e) {
			log.error("Error in Pharmacy Invoice Report Grid Popup  :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Export data.
	 *
	 * @param purchaseOrdersInnerGridSearch the purchase orders inner grid search
	 * @param dynamicFilters                the dynamic filters
	 * @return the search result
	 */
	private SearchResult<PhInvoiceReportDTO> exportData(InvoiceReportSearch invoiceReportSearch,
			Map<String, Map<String, Object>> dynamicFilters) {
		SearchResult<PhInvoiceReportDTO> phInvoiceSearchResult = new SearchResult<>();

		try {
			List<PhInvoiceReport> sortResult = this.phInvoiceReportDAO.findAll(
					GenericSpecification.getSpecification(dynamicFilters),
					GenericSpecification.getSort(invoiceReportSearch));

			List<PhInvoiceReportDTO> PhInvoiceReportDTOs = MAPPER.fromPhInvoiceReportModel(sortResult);

			phInvoiceSearchResult.setContent(PhInvoiceReportDTOs);
		} catch (Exception e) {
			log.error("Error in exportData :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return phInvoiceSearchResult;
	}

	/**
	 * get TrueUpReportPopupDetails
	 * 
	 * @param InvoiceReportSearch invoiceReportSearch
	 * @return the Result
	 */

	@Override
	public Result getTrueUpReportPopupDetails(InvoiceReportSearch invoiceReportSearch) {
		Result result = null;
		try {

			Map<String, Object> filters = null;
			Map<String, Map<String, Object>> dynamicFilters = new HashMap<String, Map<String, Object>>();
			if (invoiceReportSearch.getSortBy() == null 
					|| "".equalsIgnoreCase(invoiceReportSearch.getSortBy())) {
				invoiceReportSearch.setSortBy(Constant.CLAIMID);
			}

			if (invoiceReportSearch.getCeid() != null && invoiceReportSearch.getCeid() > 0
					&& invoiceReportSearch.getCeid() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getCeid());
				dynamicFilters.put(Constant.CE_ID, filters);
			}

			if (invoiceReportSearch.getPhid() != null && invoiceReportSearch.getPhid() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getPhid());
				dynamicFilters.put(Constant.PHID, filters);
			}

			if (invoiceReportSearch.getPhGroupId() != null && invoiceReportSearch.getPhGroupId() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getPhGroupId());
				dynamicFilters.put(Constant.PH_GROUP_ID, filters);
			}

			if (invoiceReportSearch.getBillingPeriod() != null && !"".equalsIgnoreCase(invoiceReportSearch.getBillingPeriod())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getBillingPeriod());
				dynamicFilters.put(Constant.BILLING_PERIOD, filters);
			}

			if (invoiceReportSearch.getFilter() != null) {
				GenericSpecification.dynamicFilters(invoiceReportSearch.getFilter(), dynamicFilters);
			}
			result = new Result();
			if (!invoiceReportSearch.isExport()) {
				Page<TrueUpReportPopup> pageResult = this.trueUpReportPopupDAO.findAll(
						GenericSpecification.getSpecification(dynamicFilters),
						GenericSpecification.getPagination(invoiceReportSearch));
				SearchResult<TrueUpReportPopupDTO> searchResult = GenericSpecification.getPaginationDetails(pageResult,
						TrueUpReportPopupDTO.class);
				List<TrueUpReportPopupDTO> trueUpReportPopupDTOs = MAPPER
						.fromTrueUpReportingModel(pageResult.getContent());
				searchResult.setContent(trueUpReportPopupDTOs);
				result.setData(searchResult);
				if (trueUpReportPopupDTOs.size() == 0) {
					result.setStatusCode(HttpStatus.NOT_FOUND.value());
					result.setErrorMessage("No Result Found");
				} else {
					result.setStatusCode(HttpStatus.OK.value());
					result.setSuccessMessage("Fetching all TrueUpReportPopupDetails ");
				}
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setData(exportTrueUpReportData(invoiceReportSearch, dynamicFilters));
			}
		} catch (Exception e) {
			log.error("Error in TrueUpReportPopupDetails  :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Export data.
	 *
	 * @param TrueUpReportPopup Details
	 * @param dynamicFilters    the dynamic filters
	 * @return the search result
	 */
	private SearchResult<TrueUpReportPopupDTO> exportTrueUpReportData(InvoiceReportSearch invoiceReportSearch,
			Map<String, Map<String, Object>> dynamicFilters) {
		SearchResult<TrueUpReportPopupDTO> trueUpReportPopupSearchResult = new SearchResult<>();

		try {
			List<TrueUpReportPopup> sortResult = this.trueUpReportPopupDAO.findAll(
					GenericSpecification.getSpecification(dynamicFilters),
					GenericSpecification.getSort(invoiceReportSearch));

			List<TrueUpReportPopupDTO> trueUpReportPopupDTOs = MAPPER.fromTrueUpReportingModel(sortResult);

			trueUpReportPopupSearchResult.setContent(trueUpReportPopupDTOs);
		} catch (Exception e) {
			log.error("Error in TrueUpReportPopupDetails:: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return trueUpReportPopupSearchResult;
	}

	/**
	 * Get the 340BDirect+ Fees Report
	 * 
	 * @param tfbDirectPlusFeesReportSearch
	 * @return Result result
	 */
	@Override
	public Result getTFBDirectPlusFeesReport(InvoiceReportSearch invoiceReportSearch) {
		Result result = null;
		try {

			Map<String, Object> filters = null;
			Map<String, Map<String, Object>> dynamicFilters = new HashMap<String, Map<String, Object>>();
			if (invoiceReportSearch.getSortBy() == null 
					|| "".equalsIgnoreCase(invoiceReportSearch.getSortBy())) {
				invoiceReportSearch.setSortBy(Constant.CE_ID);
			}

			if (invoiceReportSearch.getCeid() != null && invoiceReportSearch.getCeid() > 0
					&& invoiceReportSearch.getCeid() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getCeid());
				dynamicFilters.put(Constant.CE_ID, filters);
			}

			if (invoiceReportSearch.getPhid() != null && invoiceReportSearch.getPhid() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getPhid());
				dynamicFilters.put(Constant.PHID, filters);
			}

			if (invoiceReportSearch.getPhGroupId() != null 
					&& invoiceReportSearch.getPhGroupId() > 0) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getPhGroupId());
				dynamicFilters.put(Constant.PH_GROUP_ID, filters);
			}

			if (invoiceReportSearch.getBillingPeriod() != null && !"".equalsIgnoreCase(invoiceReportSearch.getBillingPeriod())) {
				filters = new HashMap<String, Object>();
				filters.put(Constant.EQUALS, invoiceReportSearch.getBillingPeriod());
				dynamicFilters.put(Constant.BILLING_PERIOD, filters);
			}

			if (invoiceReportSearch.getFilter() != null) {
				GenericSpecification.dynamicFilters(invoiceReportSearch.getFilter(), dynamicFilters);
			}
			result = new Result();
			if (!invoiceReportSearch.isExport()) {
				Page<TFBDirectPlusFeesReport> pageResult = tfbDirectPlusFeesReportDAO.findAll(
						GenericSpecification.getSpecification(dynamicFilters),
						GenericSpecification.getPagination(invoiceReportSearch));
				SearchResult<TFBDirectPlusFeesReportDTO> searchResult = GenericSpecification
						.getPaginationDetails(pageResult, TFBDirectPlusFeesReportDTO.class);
				List<TFBDirectPlusFeesReportDTO> tFBDirectPlusFeesReportDTO = MAPPER
						.fromTFBDirectPlusFeesReportModel(pageResult.getContent());
				searchResult.setContent(tFBDirectPlusFeesReportDTO);
				result.setData(searchResult);
				if (tFBDirectPlusFeesReportDTO.size() == 0) {
					result.setStatusCode(HttpStatus.NOT_FOUND.value());
					result.setErrorMessage("No Result Found");
				} else {
					result.setStatusCode(HttpStatus.OK.value());
					result.setSuccessMessage("Fetching all 340BDirectPlus Fees Report.");
				}
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setData(exportTFBDirectPlusFeesReportData(invoiceReportSearch, dynamicFilters));
			}
		} catch (Exception e) {
			log.error("Error in 340BDirectPlus Fees Report  :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Export data.
	 *
	 * @param InvoiceReportSearch invoiceReportSearch
	 * @param dynamicFilters      the dynamic filters
	 * @return the search result
	 */
	private SearchResult<TFBDirectPlusFeesReportDTO> exportTFBDirectPlusFeesReportData(
			InvoiceReportSearch invoiceReportSearch, 
			Map<String, Map<String, Object>> dynamicFilters) {
		SearchResult<TFBDirectPlusFeesReportDTO> tfbDirectPlusFeesReportSearchResult = new SearchResult<>();

		try {
			List<TFBDirectPlusFeesReport> sortResult = tfbDirectPlusFeesReportDAO.findAll(
					GenericSpecification.getSpecification(dynamicFilters),
					GenericSpecification.getSort(invoiceReportSearch));

			List<TFBDirectPlusFeesReportDTO> tfbDirectPlusFeesReportDTOs = MAPPER
					.fromTFBDirectPlusFeesReportModel(sortResult);

			tfbDirectPlusFeesReportSearchResult.setContent(tfbDirectPlusFeesReportDTOs);
		} catch (Exception e) {
			log.error("Error in exportData :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return tfbDirectPlusFeesReportSearchResult;

	}

	/**
	 * Search invoices main grid.
	 *
	 * @param invoicesMainGridSearch the invoices main grid search
	 * @return the result
	 */
	@Override
	public Result searchInvoicesMainGrid(InvoiceSearch invoiceSearch) {

		Result result = null;
		try {

			if (invoiceSearch.getSortBy() == null || "".equalsIgnoreCase(invoiceSearch.getSortBy())) {
				invoiceSearch.setSortBy(Constant.ID);
			}
			if (invoiceSearch.getSortOrder() == null || "".equalsIgnoreCase(invoiceSearch.getSortOrder())) {
				invoiceSearch.setSortOrder("asc");
			}

			String ceName = "";
			String billingPeriod = "";
			String totalInvoiced = "";
			String dispensingFee = "";
			String trueUp = "";
			String storeFees = "";
			String ceTotalReceivedAmount = "";
			String direct340BTrxnFee = "";
			String invoiceNumber="";
			String invoicePeriodStartDate = "";
			String invoicePeriodEndDate = "";

			if (invoiceSearch.getFilter() != null) {
				for (ColumnFilter columnFilter : invoiceSearch.getFilter()) {
					if (columnFilter.getColumn().getField().equals(Constant.CE_NAME)) {
						ceName = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.BILLING_PERIOD)) {
						billingPeriod = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TOTAL_INVOICED)) {
						totalInvoiced = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.DISPENSING_FEE)) {
						dispensingFee = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TRUE_UP)) {
						trueUp = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.STORE_FEES)) {
						storeFees = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.CE_TOTAL_RECEIVED_AMOUNT)) {
						ceTotalReceivedAmount = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.DIRECT340B_TRXN_FEE)) {
						direct340BTrxnFee = columnFilter.getValue();
					}else if (columnFilter.getColumn().getField().equals(Constant.INVOICE_NUMBER)) {
						invoiceNumber = columnFilter.getValue();
					}else if (columnFilter.getColumn().getField().equals(Constant.INVOICE_PERIOD_START_DATE)) {
						invoicePeriodStartDate = columnFilter.getValue();
					}else if (columnFilter.getColumn().getField().equals(Constant.INVOICE_PERIOD_END_DATE)) {
						invoicePeriodEndDate = columnFilter.getValue();
					}
				}
			}

			result = new Result();

			List<InvoicesMainGrid> invoicesMainGrids = this.invoicesMainGridDAO.getInvoiceGridDetails(
					invoiceSearch.getCeId().get(0), invoiceSearch.getPhGroupId(), 
					invoiceSearch.getPhId(),invoiceSearch.getInvoicePeriodStartDate(), 
					invoiceSearch.getInvoicePeriodEndDate(),invoiceSearch.getPageNumber(), 
					invoiceSearch.getPageSize(), invoiceSearch.getSortBy(),
					invoiceSearch.getSortOrder(), invoiceSearch.isExport() ? true : false, invoiceNumber,
				    ceName, billingPeriod,totalInvoiced, dispensingFee, trueUp, storeFees, ceTotalReceivedAmount, direct340BTrxnFee,
				    invoicePeriodStartDate,invoicePeriodEndDate);

			List<InvoicesMainGridDTO> invoicesMainGridDTOs = MAPPER.fromInvoiceMainGridModel(invoicesMainGrids);

			SearchResult<InvoicesMainGridDTO> searchResult = new SearchResult<>();
			searchResult.setContent(invoicesMainGridDTOs);
			searchResult.setPageNo(invoiceSearch.getPageNumber());
			searchResult.setPageSize(invoiceSearch.getPageSize());

			if (invoicesMainGridDTOs.size() > 0) {
				searchResult.setTotalElements(invoicesMainGrids.get(0).getTotalRows());
			}
			result.setData(searchResult);
			if (invoicesMainGrids.size() == 0) {
				result.setStatusCode(HttpStatus.NOT_FOUND.value());
				result.setErrorMessage("No Result Found");
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setSuccessMessage(
						"Fetching all invoices Main Grid replinished details for the selected covered entity");
			}

		} catch (Exception e) {
			log.error("Error in searchInvoicesMainGrid :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Search Pharmacy Invoice Details.
	 *
	 * @param InvoiceSearch the invoiceSearch
	 * @return the result
	 */
	@Override
	public Result searchPharmacyInvoiceDetails(InvoiceSearch invoiceSearch) {

		Result result = null;
		try {

			if (invoiceSearch.getSortBy() == null || "".equalsIgnoreCase(invoiceSearch.getSortBy())) {
				invoiceSearch.setSortBy(Constant.ID);
			}
			if (invoiceSearch.getSortOrder() == null || "".equalsIgnoreCase(invoiceSearch.getSortOrder())) {
				invoiceSearch.setSortOrder("asc");
			}

			String ceName = "";
			String phGroupName = "";
			String phName = "";
			String billingPeriod = "";
			String totalInvoiced = "";
			String dispensingFee = "";
			String trueUp = "";
			String storeFees = "";
			String ceTotalReceivedAmount = "";
			String direct340BTrxnFee = "";
			String estimatedCeSavings = "";
			String pharmacyPaymentReceived = "";
			String tfbDirectPlusRemittance = "";
			String invoicePeriodStartDate = "";
			String invoicePeriodEndDate = "";

			if (invoiceSearch.getFilter() != null) {
				for (ColumnFilter columnFilter : invoiceSearch.getFilter()) {
					if (columnFilter.getColumn().getField().equals(Constant.CE_NAME)) {
						ceName = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.PH_GROUP_NAME)) {
						phGroupName = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.PHY_NAME)) {
						phName = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.BILLING_PERIOD)) {
						billingPeriod = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TOTAL_INVOICED)) {
						totalInvoiced = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.DISPENSING_FEE)) {
						dispensingFee = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TRUE_UP)) {
						trueUp = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.STORE_FEES)) {
						storeFees = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.CE_TOTAL_RECEIVED_AMOUNT)) {
						ceTotalReceivedAmount = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.DIRECT340B_TRXN_FEE)) {
						direct340BTrxnFee = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.EST_CE_SAVINGS)) {
						estimatedCeSavings = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.PH_PAYMENT_RECIVED)) {
						pharmacyPaymentReceived = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TFB_DIRECT_PLUS_REMITTANCE)) {
						tfbDirectPlusRemittance = columnFilter.getValue();
					}else if (columnFilter.getColumn().getField().equals(Constant.INVOICE_PERIOD_START_DATE)) {
						invoicePeriodStartDate = columnFilter.getValue();
					}else if (columnFilter.getColumn().getField().equals(Constant.INVOICE_PERIOD_END_DATE)) {
						invoicePeriodEndDate = columnFilter.getValue();
					}
				}
			}

			result = new Result();

			List<PharmacyInvoiceDetails> pharmacyInvoiceDetails = this.pharmacyInvoiceDetailsDAO
					.getPharmacyInvoiceDetails(invoiceSearch.getCeId().get(0), invoiceSearch.getPhGroupId(),
							invoiceSearch.getPhId(), invoiceSearch.getInvoicePeriodStartDate(),
							invoiceSearch.getInvoicePeriodEndDate(), invoiceSearch.getBillPeriod(),invoiceSearch.getPageNumber(),
							invoiceSearch.getPageSize(), invoiceSearch.getSortBy(), invoiceSearch.getSortOrder(),
							invoiceSearch.isExport() ? true : false, ceName, phGroupName, phName, billingPeriod,
							totalInvoiced, dispensingFee, trueUp, storeFees, ceTotalReceivedAmount, direct340BTrxnFee,
							estimatedCeSavings, pharmacyPaymentReceived, tfbDirectPlusRemittance,invoicePeriodStartDate,invoicePeriodEndDate);
							
			List<PharmacyInvoiceDetailsDTO> pharmacyInvoiceDetailsDTOs = MAPPER
					.fromPharmacyInvoiceDetailsModel(pharmacyInvoiceDetails);

			SearchResult<PharmacyInvoiceDetailsDTO> searchResult = new SearchResult<>();
			searchResult.setContent(pharmacyInvoiceDetailsDTOs);
			searchResult.setPageNo(invoiceSearch.getPageNumber());
			searchResult.setPageSize(invoiceSearch.getPageSize());

			if (pharmacyInvoiceDetailsDTOs.size() > 0) {
				searchResult.setTotalElements(pharmacyInvoiceDetails.get(0).getTotalRows());
			}
			result.setData(searchResult);
			if (pharmacyInvoiceDetails.size() == 0) {
				result.setStatusCode(HttpStatus.NOT_FOUND.value());
				result.setErrorMessage("No Result Found");
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setSuccessMessage("Fetching all pharmacy Invoice Details");
			}

		} catch (Exception e) {
			log.error("Error in pharmacyInvoiceDetails :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	/**
	 * Search pharmacy invoice group details.
	 *
	 * @param PharmacyinvoiceGroupSearch the PharmacyinvoiceGroupSearch
	 * @return the result
	 */
	@Override
	public Result searchPharmacyGroupInvoicedetails(InvoiceSearch invoiceSearch) {
		Result result = null;
		try {

			if (invoiceSearch.getSortBy() == null || "".equalsIgnoreCase(invoiceSearch.getSortBy())) {
				invoiceSearch.setSortBy(Constant.ID);
			}
			if (invoiceSearch.getSortOrder() == null || "".equalsIgnoreCase(invoiceSearch.getSortOrder())) {
				invoiceSearch.setSortOrder("asc");
			}

			String ceName = "";
			String phGroupName = "";
			String billingPeriod = "";
			String totalInvoiced = "";
			String dispensingFee = "";
			String trueUp = "";
			String storeFees = "";
			String ceTotalReceivedAmount = "";
			String direct340BTrxnFee = "";
			String invoicePeriodStartDate = "";
			String invoicePeriodEndDate = "";

			if (invoiceSearch.getFilter() != null) {
				for (ColumnFilter columnFilter : invoiceSearch.getFilter()) {
					if (columnFilter.getColumn().getField().equals(Constant.CE_NAME)) {
						ceName = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.PH_GROUP_NAME)) {
						phGroupName = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.BILLING_PERIOD)) {
						billingPeriod = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TOTAL_INVOICED)) {
						totalInvoiced = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.DISPENSING_FEE)) {
						dispensingFee = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TRUE_UP)) {
						trueUp = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.STORE_FEES)) {
						storeFees = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.CE_TOTAL_RECEIVED_AMOUNT)) {
						ceTotalReceivedAmount = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.DIRECT340B_TRXN_FEE)) {
						direct340BTrxnFee = columnFilter.getValue();
					}else if (columnFilter.getColumn().getField().equals(Constant.INVOICE_PERIOD_START_DATE)) {
						invoicePeriodStartDate = columnFilter.getValue();
					}else if (columnFilter.getColumn().getField().equals(Constant.INVOICE_PERIOD_END_DATE)) {
						invoicePeriodEndDate = columnFilter.getValue();
					}
				}
			}

			result = new Result();

			List<PharmacyGroupInvoiceDetails> pharmacyGroupInvoiceDetails = this.pharmacyGroupInvoiceDeatailsDAO
					.getInvoiceGridDetails(invoiceSearch.getCeId().get(0), invoiceSearch.getPhGroupId(),
							invoiceSearch.getPhId(), invoiceSearch.getInvoicePeriodStartDate(),
							invoiceSearch.getInvoicePeriodEndDate(), invoiceSearch.getBillPeriod(), invoiceSearch.getPageNumber(),
							invoiceSearch.getPageSize(), invoiceSearch.getSortBy(), invoiceSearch.getSortOrder(),
							invoiceSearch.isExport() ? true : false, 
							ceName, phGroupName, billingPeriod, totalInvoiced, dispensingFee, trueUp, storeFees, ceTotalReceivedAmount, direct340BTrxnFee,
							invoicePeriodStartDate,invoicePeriodEndDate);

			List<PharmacyGroupInvoiceDetailsDTO> pharmacyGroupInvoiceDetailsDTOs = MAPPER
					.fromInvoiceInnerGridmodel(pharmacyGroupInvoiceDetails);

			SearchResult<PharmacyGroupInvoiceDetailsDTO> searchResult = new SearchResult<>();
			searchResult.setContent(pharmacyGroupInvoiceDetailsDTOs);
			searchResult.setPageNo(invoiceSearch.getPageNumber());
			searchResult.setPageSize(invoiceSearch.getPageSize());

			if (pharmacyGroupInvoiceDetailsDTOs.size() > 0) {
				searchResult.setTotalElements(pharmacyGroupInvoiceDetails.get(0).getTotalRows());
			}
			result.setData(searchResult);
			if (pharmacyGroupInvoiceDetails.size() == 0) {
				result.setStatusCode(HttpStatus.NOT_FOUND.value());
				result.setErrorMessage("No Result Found");
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setSuccessMessage(
						"Fetching all pharmacyGroupInvoiceDetails replinished details for the selected claim ID");
			}

		} catch (Exception e) {
			log.error("Error in pharmacyGroupInvoiceDetails :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

	@Override
	public Result invoiceClaim(InvoiceClaimSearch invoiceClaimSearch) {
		Result result = null;
		try {
			if (invoiceClaimSearch.getSortBy() == null || "".equalsIgnoreCase(invoiceClaimSearch.getSortBy())) {
				invoiceClaimSearch.setSortBy(Constant.ADMIN_NAME);
			}
			if (invoiceClaimSearch.getSortOrder() == null || "".equalsIgnoreCase(invoiceClaimSearch.getSortOrder())) {
				invoiceClaimSearch.setSortOrder("asc");
			}
				String adminName = null;
				String ceName = null;
				String hrsaID = null;
				String ceReimbursementModel = null;
				String ceReplenishmentModel = null;
				String pharmacyGroup = null;
				String pharmacyStoreName = null;
				String pharmacyNPI = null;
				String physicianFirstName = null;
				String physicianLastName = null;
				Long prescriberId = null;
				String replenishmentType = null;
				Long claimID = null;
				String refillCode = null;
				String rxNumber = null;
				String pgmDateRxWritten = null;
				String processedDate = null;
				String dateOfService = null;
				String dateReversed = null;
				Long claimStatusCode = null;
				String claimType = null;
				String bin = null;
				String pcn = null;
				String groupNumber = null;
				String ndc = null;
				String drugName = null;
				String borGIndicator = null;
				String patientPay = null;
				String thirdPartyPayment = null;
				String cePlanSubsidy = null;
				String totalCollected = null;
				String estimatedAcquisitionCost = null;
				String tfbIngredientCost = null;
				String actualIngredientCost = null;
				String totalInvoiced = null;
				String dispensingFee = null;
				String grossSavings = null;
				String tfbDirectplusFlatFee = null;
				String tfbDirectVariableTransactionFee = null;
				String total340BDirectplusFee = null;
				String totalCEReceivable = null;
				String eightTenDebitInvoice = null;
				String invoiceDate = null;
				String eightTenCreditInvoice = null;
				String creditInvoiceDate = null;
				Long qtyDisp = null;
				Long replenishedQty = null;
				Long replenishmentPercentage = null;
				if (invoiceClaimSearch.getFilter() != null) {
					for (ColumnFilter columnFilter : invoiceClaimSearch.getFilter()) {
						if (columnFilter.getColumn().getField().equals(Constant.ADMIN_NAME)) {
							adminName = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.CE_NAME)) {
							ceName = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.HRSA_ID)) {
							hrsaID = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.CE_REIMBURSEMENT_MODEL)) {
							ceReimbursementModel = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.CE_REPLENISHMENT_MODEL)) {
							ceReplenishmentModel = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PHARMACY_GROUP)) {
							pharmacyGroup = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PHARMACY_STORE_NAME)) {
							pharmacyStoreName = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PHARMACY_NPI)) {
							pharmacyNPI = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PHARMACY_NPI)) {
							pharmacyNPI = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PHYSICIAN_FIRST_NAME)) {
							physicianFirstName = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PHYSICIAN_LAST_NAME)) {
							physicianLastName = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PRESCRIBER_ID)) {
							String prescriberIdString = columnFilter.getValue();
							prescriberId = Long.parseLong(prescriberIdString);
						} else if (columnFilter.getColumn().getField().equals(Constant.REPLENISHMENT_TYPE)) {
							replenishmentType = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.CLAIM_ID)) {
							String claimIDString = columnFilter.getValue();
							claimID = Long.parseLong(claimIDString);
						} else if (columnFilter.getColumn().getField().equals(Constant.REFILL_CODE)) {
							refillCode = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.RX_NUMBER)) {
							rxNumber = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PGM_DATE_RX_WRITTEN)) {
							pgmDateRxWritten = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PGM_DATE_RX_WRITTEN)) {
							pgmDateRxWritten = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PROCESSED_DATE)) {
							processedDate = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.DATE_OF_SERVICE)) {
							dateOfService = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.DATE_REVERSED)) {
							dateReversed = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.CLAIM_STATUS_CODE)) {
							String claimStatusCodeString = columnFilter.getValue();
							claimStatusCode = Long.parseLong(claimStatusCodeString);
						} else if (columnFilter.getColumn().getField().equals(Constant.CLAIM_TYPE)) {
							claimType = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.BIN)) {
							bin = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PCN)) {
							pcn = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.GROUP_NUMBER)) {
							groupNumber = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.NDC)) {
							ndc = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.DRUG_NAME)) {
							drugName = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.B_OR_G_INDICATOR)) {
							borGIndicator = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.PATIENT_PAY)) {
							patientPay = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.THIRD_PARTY_PAYMENT)) {
							thirdPartyPayment = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.CE_PLAN_SUBSIDY)) {
							cePlanSubsidy = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.TOTAL_COLLECTED)) {
							totalCollected = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.ESTIMATED_ACQUISITION_COST)) {
							estimatedAcquisitionCost = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.TFB_INGREDIENT_COST)) {
							tfbIngredientCost = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.ACTUAL_INGREDIENT_COST)) {
							actualIngredientCost = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.TOTAL_INVOICED)) {
							totalInvoiced = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.DISPENSING_FEE)) {
							dispensingFee = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.GROSS_SAVINGS)) {
							grossSavings = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.TFB_DIRECTPLUS_FLAT_FEE)) {
							tfbDirectplusFlatFee = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField()
								.equals(Constant.TFB_DIRECT_VARIABLE_TRANSACTION_FEE)) {
							tfbDirectVariableTransactionFee = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.TOTAL_340B_DIRECTPLUS_FEE)) {
							total340BDirectplusFee = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.TOTAL_CE_RECEIVABLE)) {
							totalCEReceivable = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.EIGHT_TEN_DEBIT_INVOICE)) {
							eightTenDebitInvoice = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.INVOICE_DATE)) {
							invoiceDate = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.EIGHT_TEN_CREDIT_INVOICE)) {
							eightTenCreditInvoice = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.CREDIT_INVOICE_DATE)) {
							creditInvoiceDate = columnFilter.getValue();
						} else if (columnFilter.getColumn().getField().equals(Constant.QTY_DISP)) {
							qtyDisp = Long.parseLong(columnFilter.getValue());
						} else if (columnFilter.getColumn().getField().equals(Constant.REPLENISHED_QTY)) {
							replenishedQty = Long.parseLong(columnFilter.getValue());
						} else if (columnFilter.getColumn().getField().equals(Constant.REPLENISHMENT_PERCENTAGE)) {
							replenishmentPercentage = Long.parseLong(columnFilter.getValue());
						}
					}
					result = new Result();

					List<InvoiceClaim> invoiceClaims = invoiceClaimDAO.getInvoiceClaimDetails(
							invoiceClaimSearch.getCeid(), invoiceClaimSearch.getStartPeriod(),
							invoiceClaimSearch.getEndPeriod(),invoiceClaimSearch.getPhGroupid(), invoiceClaimSearch.getPhid(),
							invoiceClaimSearch.getSortBy(),
							invoiceClaimSearch.getSortOrder(), invoiceClaimSearch.getPageNumber(),
							invoiceClaimSearch.getPageSize(), invoiceClaimSearch.isExport() ? 1 : 0,
							 adminName, ceName, hrsaID,
							ceReimbursementModel, ceReplenishmentModel, pharmacyGroup, pharmacyStoreName, pharmacyNPI,
							physicianFirstName, physicianLastName, prescriberId, replenishmentType, claimID, refillCode,
							rxNumber, pgmDateRxWritten, processedDate, dateOfService, dateReversed, claimStatusCode,
							claimType, bin, pcn, groupNumber, ndc, drugName, borGIndicator, qtyDisp, replenishedQty,
							replenishmentPercentage, patientPay, thirdPartyPayment, cePlanSubsidy, totalCollected,
							estimatedAcquisitionCost, tfbIngredientCost, actualIngredientCost, totalInvoiced,
							dispensingFee, grossSavings, tfbDirectplusFlatFee, tfbDirectVariableTransactionFee,
							total340BDirectplusFee, totalCEReceivable, eightTenDebitInvoice, invoiceDate,
							eightTenCreditInvoice, creditInvoiceDate);
					List<InvoiceClaimDTO> invoiceClaimDTOs = MAPPER.fromInvoiceClaimModel(invoiceClaims);
					SearchResult<InvoiceClaimDTO> searchResult = new SearchResult<>();
					searchResult.setContent(invoiceClaimDTOs);
					searchResult.setPageNo(invoiceClaimSearch.getPageNumber());
					searchResult.setPageSize(invoiceClaimSearch.getPageSize());
					if (invoiceClaimDTOs.size() > 0) {
						searchResult.setTotalElements(invoiceClaims.get(0).getTotalRows());
					}
					result.setData(searchResult);
					if (invoiceClaimDTOs.size() == 0) {
						result.setStatusCode(HttpStatus.NOT_FOUND.value());
						result.setErrorMessage("No Result Found");
					} else {
						result.setStatusCode(HttpStatus.OK.value());
						result.setSuccessMessage("Fetching all Invoice details based on the selected filters");
					}
				}
		} catch (Exception e) {
			log.error("Error in Invoice claims :: ", e);
		}
		return result;
	}
	/**
	 * Search invoice remittancedetails.
	 *
	 * @param invoiceRemittanceSearch the invoice remittance search
	 * @return the result
	 */
	@Override
	public Result searchInvoiceRemittancedetails(InvoiceRemittanceSearch invoiceRemittanceSearch) {

		Result result = null;
		try {
			result = new Result();

			List<InvoiceRemittance> invoiceRemittance = this.invoiceRemittanceDAO.getInvoiceRemittanceDetails(
					invoiceRemittanceSearch.getCeid(), invoiceRemittanceSearch.getPhGroupId(),
					invoiceRemittanceSearch.getPhId(), invoiceRemittanceSearch.getStartDate(),
					invoiceRemittanceSearch.getEndDate(), invoiceRemittanceSearch.getSortBy(),
					invoiceRemittanceSearch.getSortOrder(), invoiceRemittanceSearch.getPageNumber(),
					invoiceRemittanceSearch.getPageSize(), invoiceRemittanceSearch.isExport() ? true : false);

			List<InvoiceRemittanceDTO> invoiceRemittanceDTOs = MAPPER.fromInvoiceRemittanceModel(invoiceRemittance);

			SearchResult<InvoiceRemittanceDTO> searchResult = new SearchResult<>();
			searchResult.setContent(invoiceRemittanceDTOs);
			searchResult.setPageNo(invoiceRemittanceSearch.getPageNumber());
			searchResult.setPageSize(invoiceRemittanceSearch.getPageSize());

			if (invoiceRemittanceDTOs.size() > 0) {
				searchResult.setTotalElements(invoiceRemittance.get(0).getTotalRows());
			}
			result.setData(searchResult);
			if (invoiceRemittance.size() == 0) {
				result.setStatusCode(HttpStatus.NOT_FOUND.value());
				result.setErrorMessage("No Result Found");
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setSuccessMessage("Fetching all invoice remittance details");
			}

		} catch (Exception e) {
			log.error("Error in searchinvoiceremittance :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;

	}

	@Override
	public Result searchInvoiceTrueUp(InvoiceTrueUpSearch invoiceTrueUpSearch) {
		Result result = null;
		try {
			if (invoiceTrueUpSearch.getSortBy() == null || "".equalsIgnoreCase(invoiceTrueUpSearch.getSortBy())) {
				invoiceTrueUpSearch.setSortBy(Constant.BILLING_CYCLE);
			}
			if (invoiceTrueUpSearch.getSortOrder() == null || "".equalsIgnoreCase(invoiceTrueUpSearch.getSortOrder())) {
				invoiceTrueUpSearch.setSortOrder("asc");
			}
			String billingCycle = null;
			String tfbID = null;
			Long claimId = null;
			String processedDate = null;
			String rxNumber = null;
			String rxWrittenDate = null;
			String refillNumber = null;
			String dateOfService = null;
			String bin = null;
			String pcn = null;
			String phGroupName = null;
			String store = null;
			String dispensingStoreNpi = null;
			String ndc = null;
			String drugName = null;
			String brandGenericFlag = null;
			String replenishedPercentage = null;
			String trueUpUnits = null;
			String trueUpAmount = null;
			String trueUpReason = null;
			String trueUpType = null;
			if (invoiceTrueUpSearch.getFilter() != null) {
				for (ColumnFilter columnFilter : invoiceTrueUpSearch.getFilter()) {
					if (columnFilter.getColumn().getField().equals(Constant.BILLING_CYCLE)) {
						billingCycle = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TFB_ID)) {
						tfbID = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.CLAIM_ID)) {
						claimId = Long.parseLong(columnFilter.getValue());
					} else if (columnFilter.getColumn().getField().equals(Constant.PROCESSED_DATE)) {
						processedDate = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.RX_NUMBER)) {
						rxNumber = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.RX_WRITTEN_DATE)) {
						rxWrittenDate = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.REFILL_NUMBER)) {
						refillNumber = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.DATE_OF_SERVICE)) {
						dateOfService = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.BIN)) {
						bin = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.PCN)) {
						pcn = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.PH_GROUP_NAME)) {
						phGroupName = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.STORE)) {
						store = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.DISPATCHING_STORE_NPI)) {
						dispensingStoreNpi = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.NDC)) {
						ndc = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.DRUG_NAME)) {
						drugName = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.BRAND_GENERIC_FLAG)) {
						brandGenericFlag = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.REPLENISHED_PERCENTAGE)) {
						replenishedPercentage = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TRUE_UP_UNITS)) {
						trueUpUnits = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TRUE_UP_AMOUNT)) {
						trueUpAmount = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TRUE_UP_REASON)) {
						trueUpReason = columnFilter.getValue();
					} else if (columnFilter.getColumn().getField().equals(Constant.TRUE_UP_TYPE)) {
						trueUpType = columnFilter.getValue();
					}
				}
			}
			result = new Result();
			List<InvoiceTrueUp> invoiceTrueUps = invoiceTrueUpDAO.getInvoiceTrueUpDetails(invoiceTrueUpSearch.getCeid(),
					invoiceTrueUpSearch.getStartPeriod(), invoiceTrueUpSearch.getEndPeriod(),
					invoiceTrueUpSearch.getPhGroupid(), invoiceTrueUpSearch.getPhid(), invoiceTrueUpSearch.getSortBy(),
					invoiceTrueUpSearch.getSortOrder(), invoiceTrueUpSearch.getPageNumber(),
					invoiceTrueUpSearch.getPageSize(), invoiceTrueUpSearch.isExport() ? 1 : 0, billingCycle, tfbID,
					claimId, processedDate, rxNumber, rxWrittenDate, refillNumber, dateOfService, pcn, bin, phGroupName,
					store, dispensingStoreNpi, ndc, drugName, brandGenericFlag, replenishedPercentage, trueUpUnits,
					trueUpAmount, trueUpReason, trueUpType);
			List<InvoiceTrueUpDTO> invoiceTrueUpDTOS = MAPPER.fromInvoiceTrueUpModel(invoiceTrueUps);
			SearchResult<InvoiceTrueUpDTO> searchResult = new SearchResult<>();
			searchResult.setContent(invoiceTrueUpDTOS);
			searchResult.setPageNo(invoiceTrueUpSearch.getPageNumber());
			searchResult.setPageSize(invoiceTrueUpSearch.getPageSize());
			if (invoiceTrueUpDTOS.size() > 0) {
				result.setStatusCode(HttpStatus.OK.value());
				result.setSuccessMessage("Fetching all Invoice True up records");
				searchResult.setTotalElements(invoiceTrueUps.get(0).getTotalRows());
			}
			result.setData(searchResult);
			if (invoiceTrueUpDTOS.size() == 0) {
				result.setStatusCode(HttpStatus.NOT_FOUND.value());
				result.setErrorMessage("No result found");
			}

		} catch (Exception e) {
			log.error("Error in searchinvoiceremittance :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;

	}
	/**
	 * Search CE remittance totalsdetails.
	 *
	 * @param ceRemittanceTotalsSearch the ce remittance totals search
	 * @return the result
	 */
	@Override
	public Result searchCERemittanceTotalsdetails(CERemittanceTotalsSearch ceRemittanceTotalsSearch) {
		Result result = null;
		try {
			result = new Result();

			List<CERemittanceTotals> ceRemittanceTotals = this.ceRemittanceTotalsDAO.getCERemittanceTotalsDetails(
					ceRemittanceTotalsSearch.getCeid(), ceRemittanceTotalsSearch.getPhGroupId(),
					ceRemittanceTotalsSearch.getPhId(), ceRemittanceTotalsSearch.getStartDate(),
					ceRemittanceTotalsSearch.getEndDate());

			List<CERemittanceTotalsDTO> CERemittanceTotalsDTOs = MAPPER.fromCERemittanceTotalsModel(ceRemittanceTotals);

			SearchResult<CERemittanceTotalsDTO> searchResult = new SearchResult<>();
			searchResult.setContent(CERemittanceTotalsDTOs);

			result.setData(searchResult);
			if (ceRemittanceTotals.size() == 0) {
				result.setStatusCode(HttpStatus.NOT_FOUND.value());
				result.setErrorMessage("No Result Found");
			} else {
				result.setStatusCode(HttpStatus.OK.value());
				result.setSuccessMessage("Fetching all Invoice details based on the selected filters");
			}
		} catch (Exception e) {
			log.error("Error in searchInvoiceTrueUp :: ", e);
			throw new CustomException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}

}
			
