package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrderHistoryDTO {

  private Long poLogID;
  private Long poID;
  private String poDate;
  private String reasonDesc;
  private String poStatus;
  private String poStatusDate;
  private String invoiceNumber;
  private Integer edi855FileCount;
  private Integer edi810FileCount;
  private String createdDate;
  private Long createdByID;
}