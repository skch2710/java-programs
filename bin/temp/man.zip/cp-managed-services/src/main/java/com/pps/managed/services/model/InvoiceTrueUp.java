package com.pps.managed.services.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class InvoiceTrueUp {

	@Id
	@Column(name = "id")
	private Long id;

	@Column(name = "BillingCycle")
	private Date billingCycle;

	@Column(name = "[340BID]")
	private String tfbID;

	@Column(name = "Claimid")
	private Long claimId;

	@Column(name = "ProcessedDate")
	private Date processedDate;

	@Column(name = "RxNumber")
	private String rxNumber;

	@Column(name = "RxWrittenDate")
	private Date rxWrittenDate;

	@Column(name = "Refill#")
	private String refillNumber;

	@Column(name = "DateOfService")
	private Date dateOfService;

	@Column(name = "Bin")
	private String bin;

	@Column(name = "PCN")
	private String pcn;

	@Column(name = "PHGroupName")
	private String phGroupName;

	@Column(name = "Store")
	private String store;

	@Column(name = "DispensingStoreNPI")
	private String dispensingStoreNpi;

	@Column(name = "NDC11")
	private String ndc;

	@Column(name = "DrugName")
	private String drugName;

	@Column(name = "BrandGenericFlag")
	private String brandGenericFlag;

	@Column(name = "replenishedpercentage")
	private String replenishedPercentage;

	@Column(name = "TrueUpUnits")
	private BigDecimal trueUpUnits;

	@Column(name = "TrueUpAmount")
	private BigDecimal trueUpAmount;

	@Column(name = "TrueUpReason")
	private String trueUpReason;

	@Column(name = "TrueUpType")
	private String trueUpType;
	
	@Column(name = "totalRows")
    private Long totalRows;
}
