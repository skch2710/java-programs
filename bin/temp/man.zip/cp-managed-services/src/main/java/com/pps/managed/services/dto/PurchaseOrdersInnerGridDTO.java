package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PurchaseOrdersInnerGridDTO {
	public Long poID;
	public String ndc;
	public String drugName;
	public String itemStatus;
	public String poItemValue;
	public Long drugID;
	public Long poItemID;
	public String orderedQty;
	public String acknowledgedQty;
	public String invoicedQty;
	public String orderedPackageCost;
	public String acknowledgedPackageCost;
	public String invoicedPackageCost;
}
