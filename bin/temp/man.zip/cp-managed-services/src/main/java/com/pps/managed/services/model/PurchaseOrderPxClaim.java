package com.pps.managed.services.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.Immutable;

import lombok.Getter;

@Immutable
@Getter 
@Table(name = "Vw_Claims_Mapped_To_Purchase_Order_Item_mvp", schema = "Plus")
@Entity
public class PurchaseOrderPxClaim {
	@Column(name="PoID")
	private Long poID;

	@Column(name="FilePONumber")
	private String filePONumber;
	
	@Column(name="ItemInvoiceNumber")
	private String itemInvoiceNumber;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ItemInvoicedDate")
	private Date itemInvoicedDate;

	@Column(name="CEID")
	private Long ceID;

	@Column(name="Store")
	private String store;

	@Column(name="ClaimID")
	private Long claimID;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="InvoiceDate340BDirect")
	private Date invoiceDate340BDirect;

	@Column(name="ReFillNo")
	private String reFillNo;

	@Column(name="WholesalerAccountDivisionCode")
	private String wholesalerAccountDivisionCode;

	@Column(name="CentralClientID")
	private Long centralClientID;

	@Column(name="POItemID")
	private Long poItemID;
	
	@Column(name="InvOrderID")
	private Long invOrderID;

	@Column(name="ClaimTypeID")
	private Long claimTypeID;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="PODate")
	private Date poDate;

	@Column(name="DrugID")
	private Long drugID;

	@Column(name="NDC")
	private String ndc;

	@Column(name="DrugName")
	private String drugName;

	@Column(name="ItemPkgs")
	private Integer itemPkgs;

	@Column(name="PkgSize")
	private Integer pkgSize;

	@Column(name="POItemStatus")
	private String poItemStatus;

	@Column(name="NoClaimReason")
	private String noClaimReason;

	@Column(name="claimsMappingFlag")
	private String claimsMappingFlag;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DateOfService")
	private Date dateOfService;

	@Column(name="RxNumber")
	private String rxNumber;

	@Column(name="[Replenished Units]")
	private Integer replenishedUnits;;

	
	@Column(name="Manufacturer")
	private String manufacturere;
	
	@Column(name="[Dispensed Units]")
	private Integer dispensedUnits;
	
	@Column(name="SourceType")
	private String sourceType;

	@Id
	@Column(name="InventoryItemID")
	private Long inventoryItemID;

	@Column(name="ReceivingStore")
	private String receivingStore;

	@Column(name="PHID")
	private Long phID;

	@Column(name="DispensingStore")
	private String dispensingStore;

	@Column(name="TfbId")
	private String tfbId;
	
	@Column(name = "[TfbAdmin]")
	private String admin340b;

	@Column(name="MemberFirstName")
	private String memberFirstName;

	@Column(name="MemberLastName")
	private String memberLastName;

	@Column(name="MemberID")
	private String memberID;

	@Column(name="PhysicianFirstName")
	private String physicianFirstName;

	@Column(name="PhysicianLastName")
	private String physicianLastName;

	@Column(name="PrescriberID")
	private Long prescriberID;

	@Column(name="ClientID")
	private Long clientID;

	@Column(name="TotalQuantity")
	private Integer totalQuantity;


}

