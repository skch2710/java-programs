package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryInnerGridDTO {

	private Long id;
	private String actionDate;
	private String action;
	private String capturedDate;
	private String refNo;
	private Long qty;
	private String replInv;
	private String totalPrice;
	private String wholesaler;
	private String status;
	private Long claimID;
	private String ndc;
	private String npi;
	private Long drugID;
	private Long phID;
	private Long ceID;
	private Long wholesalerID;
	private String rxNumber;
	private Integer dispensedQty;
	private Integer replenishedQty;
	private Integer returnedQty;
	private String trueUpQty;
	private String replenishedPerc;

}
