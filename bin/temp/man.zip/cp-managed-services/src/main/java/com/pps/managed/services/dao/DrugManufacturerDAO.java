package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.DrugManufacture;

@Repository
public interface DrugManufacturerDAO extends JpaRepository<DrugManufacture, Long>{
	@Query(value = "select DrugManufacturerID,DrugManufacturername from plus.VwInventory where ceid=:ceid and phid=:phid and WholesalerID=:wholesalerId and DrugManufacturername LIKE :drugManufacturerName%"
			+ " group by ceid,phid,DrugManufacturerID,DrugManufacturerName,WholesalerID order by DrugManufacturername", nativeQuery = true)
	List<DrugManufacture> getDrugManufacturer(@Param("ceid") Long ceid, @Param("phid") Long phid,@Param("wholesalerId") Long wholesalerId,@Param("drugManufacturerName") String drugManufacturerName);
}
