package com.pps.managed.services.service;

import com.pps.managed.services.dto.PurchaseOrderPXClaimSearch;
import com.pps.managed.services.dto.PurchaseOrdersInnerGridSearch;
import com.pps.managed.services.dto.PurchaseOrderSearch;
import com.pps.managed.services.dto.PurchaseOrdersItemHistorySearch;
import com.pps.managed.services.dto.Result;

public interface PurchaseOrderService {

	Result getPurchseOrderStatus();
	
	Result getPOorderCriteria();
	
	Result getPurchaseOrderPXClaims(PurchaseOrderPXClaimSearch purchaseOrderPXClaimSearch);

	Result searchPurchaseOrdersItemHistory(PurchaseOrdersItemHistorySearch purchaseOrdersItemHistorySearch);
	
	Result searchPurchaseOrdersInnerGrid(PurchaseOrdersInnerGridSearch purchaseOrdersInnerGridSearch);

	Result searchPurchaseOrder(PurchaseOrderSearch purchaseOrderSearch);

	Result getPurchseOrderHistory(PurchaseOrdersInnerGridSearch purchaseOrdersInnerGridSearch);
}
