package com.pps.managed.services.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.Immutable;

import lombok.Getter;
import lombok.Setter;

@Entity
@Immutable
@Getter
@Setter
@Table(name = "VwInventory", schema = "Plus")
public class Inventory {

  @Id   
  @Column(name = "InventoryID")
  private Long inventoryID;

  @Column(name = "DrugName")
  private String drugName;

  @Column(name = "OpeningUnits")
  private Integer openingUnits;

  @Column(name = "WholesalerName")
  private String wholesalerName;

  @Column(name = "ReturnedUnits")
  private Integer returnedUnits;

  @Column(name = "PackageSize")
  private BigDecimal packageSize;

  @Column(name = "UnitsDispensed")
  private Integer unitsDispensed;

  @Column(name = "NDC")
  private String ndc;

  @Column(name = "PHName")
  private String phName;
  
  @Column(name = "DrugManufacturerName")
  private String drugManufacturerName;
  
  @Column(name = "UnitsReplenished")
  private Integer unitsReplenished;
  
  @Column(name="[Px Owed Inventory]")
  private Integer pxOwedInventory;

  @Column(name="[CE Owned Inventory]")
  private Integer ceOwnedInventory;
  
  
  @Column(name = "[340BInventoryCost]")
  private BigDecimal three40BInventoryCost;
  
  @Column(name = "CEID")
  private Long ceID;

  @Column(name = "PHID")
  private Long phID;
  
  @Column(name = "DrugID")
  private Long drugID;

  @Column(name = "DrugManufacturerID")
  private Long drugManufacturerID;
  
  @Column(name = "WholesalerID")
  private Long wholesalerID;
  
  @Column(name = "DrugDEAClassID")
  private Long drugDEAClassID;
  
  @Column(name = "InventoryFilter")
  private String inventoryFilter;
  
  @Column(name = "CEOwnedDrugs")
  private Integer ceOwnedDrugs;
  
  @Column(name = "ScheduleType")
  private String scheduleType;
}