package com.pps.managed.services.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "VwClaimStatusLKP", schema = "Plus")
public class Claimsstatuslkp {

	@Id
	@Column(name = "[Id]")
	private Long id;

	@Column(name = "[ClaimStatus]")
	private String claimStatus;

}
