package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.pps.managed.services.model.PharmacyInvoiceDetails;

public interface PharmacyInvoiceDetailsDAO extends JpaRepository<PharmacyInvoiceDetails, Long> {

	Page<PharmacyInvoiceDetails> findAll(Specification<PharmacyInvoiceDetails> spec, Pageable pageable);

	List<PharmacyInvoiceDetails> findAll(Specification<PharmacyInvoiceDetails> spec, Sort sort);

	@Query(value = "EXEC [Plus].[Usp_InvoiceScreenDetailsOnPHlevelwithCLF]  @In_CoveredEntityid=:ceid,\r\n"
			+ "@In_PharmacyGroupid=:phGroupId, @In_Pharmacyid=:phId, @In_StartPeriod=:invoicePeriodStartDate, \r\n"
			+ "@In_EndPeriod=:invoicePeriodEndDate,@In_BillPeriod=:billPeriod,@In_SortColumn=:sortBy, @In_SortDirection=:sortOrder, @In_PageNumber=:pageNumber,\r\n"
			+ "@In_PageSize=:pageSize, @In_IsExport=:export,\r\n"
			+ "@In_CENAME=:ceName, @In_PHGroupName=:phGroupName, @In_PHName=:phName,  @In_BillingPeriod=:billingPeriod,@In_TotalInvoiced=:totalInvoiced,@In_DispensingFee=:dispensingFee,\r\n"
			+ "@In_Trueup=:trueUp,@In_Storefees=:storeFees,@In_CETotalReceivedAmount=:ceTotalReceivedAmount,@In_340BDirectplusFee=:direct340BTrxnFee, "
			+ "@In_EstimatedCeSavings=:estimatedCeSavings, @In_PharmacyPaymentreceived=:pharmacyPaymentRecived,@IN_TfbDirectPlusRemittance=:tfbDirectPlusRemittance,@In_Invoicestartdate=:invoiceStartDate,@In_Invoiceenddate=:invoiceEndDate", nativeQuery = true)
	List<PharmacyInvoiceDetails> getPharmacyInvoiceDetails(@Param("ceid") Long ceid, @Param("phGroupId") Long phGroupId,
			@Param("phId") Long phId, @Param("invoicePeriodStartDate") String invoicePeriodStartDate,
			@Param("invoicePeriodEndDate") String invoicePeriodEndDate, @Param("billPeriod") String billPeriod,
			@Param("pageNumber") Integer pageNumber, @Param("pageSize") Integer pageSize,
			@Param("sortBy") String sortBy, @Param("sortOrder") String sortOrder, @Param("export") Boolean export,
			@Param("ceName") String ceName, @Param("phGroupName") String phGroupName, @Param("phName") String phName,
			@Param("billingPeriod") String billingPeriod, @Param("totalInvoiced") String totalInvoiced,
			@Param("dispensingFee") String dispensingFee, @Param("trueUp") String trueUp,
			@Param("storeFees") String storeFees, @Param("ceTotalReceivedAmount") String ceTotalReceivedAmount,
			@Param("direct340BTrxnFee") String direct340BTrxnFee,
			@Param("estimatedCeSavings") String estimatedCeSavings,
			@Param("pharmacyPaymentRecived") String pharmacyPaymentRecived,
			@Param("tfbDirectPlusRemittance") String tfbDirectPlusRemittance,@Param("invoiceStartDate") String invoiceStartDate,@Param("invoiceEndDate") String invoiceEndDate);

}
