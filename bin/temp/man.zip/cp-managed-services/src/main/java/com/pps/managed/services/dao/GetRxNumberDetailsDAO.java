package com.pps.managed.services.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pps.managed.services.model.GetRxNumberDetails;


@Repository
public interface GetRxNumberDetailsDAO  extends JpaRepository<GetRxNumberDetails, String> {

	@Query(value = "EXEC [Plus].[GetRxNumberDetails] @RxNumber= :rxNumber ,@ClaimID= :claimId ,@CEID= :ceId ;", nativeQuery = true)
    GetRxNumberDetails getRxNumberDetails(@Param("rxNumber") String rxNumber,  @Param("claimId") Long claimId,@Param("ceId") Long ceId);
}
