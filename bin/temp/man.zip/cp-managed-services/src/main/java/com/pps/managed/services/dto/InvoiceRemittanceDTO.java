package com.pps.managed.services.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InvoiceRemittanceDTO {

	private Long id;
	private String ceName;
	private String phGroupName;
	private String phName;
	private String pharmacyNPI;
	private String billingCycle;
	private Long claims340;
	private Long totalInvoiced;
	private Long dispensingFee;
	private Long pharmacyConnectionFee;
	private Long direct340BFlatFee;
	private Long direct340BTrxnFee;
	private Long pharmacyMinOrMax;
	private Long adjustments;
	private Long trueUp;
	private Long ceTotalReceivedAmount;
	private Long ceThreshold;
	private Long invoiceNumber;
	private Long totalRows;
}
