package com.pps.managed.services.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import com.pps.managed.services.model.TFBDirectPlusFeesReport;

public interface TFBDirectPlusFeesReportDAO extends JpaRepository<TFBDirectPlusFeesReport, Long> {

	Page<TFBDirectPlusFeesReport> findAll(Specification<TFBDirectPlusFeesReport> spec, Pageable pageable);

	List<TFBDirectPlusFeesReport> findAll(Specification<TFBDirectPlusFeesReport> spec, Sort sort);

}
