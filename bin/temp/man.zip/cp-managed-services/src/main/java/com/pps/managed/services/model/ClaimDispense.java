package com.pps.managed.services.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "VwInventoryInnerGrid1", schema = "Plus")
public class ClaimDispense {
  @Id
  @Column(name = "[id]", nullable = false)
  private Long id;
  
  @Column(name = "[Claim (Rx)]", nullable = false)
  private String claimRx;
  
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "[Dispensed Date]", nullable = false)
  private Date dispensedDate;
  
  @Column(name = "[Dispensed Qty]", nullable = false)
  private String dispensedQty;
  
  @Column(name = "[Replenishment %]", nullable = false)
  private Long replenishmentPercentage;
  
  @Column(name = "[Latest Status]", nullable = false)
  private String latestStatus;
  
  @Column(name = "[NDC]", nullable = false)
  private String ndc;
  
  @Column(name = "[Pharmacy Name]")
  private String pharmacyName;  

  @Column(name = "[PHID]")
  private Long phID;
  
  @Column(name = "[CEID]")
  private Long ceID;
  
  @Column(name = "DrugName")
  private String drugName;  
  
  @Column(name = "WholesalerID")
  private Long wholesalerID;
}