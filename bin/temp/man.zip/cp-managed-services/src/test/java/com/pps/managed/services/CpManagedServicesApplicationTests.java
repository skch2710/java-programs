package com.pps.managed.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CpManagedServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
